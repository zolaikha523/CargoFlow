import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.aistudio.cargoflow.vxrkqm"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  // Do not remove or modify these signingConfigs. They are necessary for building, installing,
  // and updating Android apps in AI Studio.
  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  // implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.camera.camera2)
  implementation(libs.androidx.camera.core)
  implementation(libs.androidx.camera.lifecycle)
  implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  // implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  // implementation(libs.firebase.ai)
  // Uncomment to use Firestore:
  // implementation(libs.firebase.firestore)

  // Uncomment ALL FOUR of the following dependencies together to use Firebase Auth and Google
  // Sign-In via Credential Manager:
  // implementation(libs.firebase.auth)
  // implementation(libs.androidx.credentials)
  // implementation(libs.androidx.credentials.play.services)
  // implementation(libs.googleid)
  // implementation(libs.firebase.appcheck.recaptcha)
  // implementation(libs.firebase.appcheck.debug)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  "ksp"(libs.moshi.kotlin.codegen)
}

tasks.register<Copy>("exportDebugApk") {
  dependsOn("assembleDebug")
  from(layout.buildDirectory.file("outputs/apk/debug/app-debug.apk"))
  into(rootProject.layout.projectDirectory.dir("apk"))
  rename { "CargoFlow-debug.apk" }
}

tasks.register("exportSourceCodePdf") {
  val rootDirFile = rootProject.layout.projectDirectory.asFile
  val outPdfFile = rootProject.layout.projectDirectory.file("docs/CargoFlow_Backend_and_Frontend_Code.pdf").asFile
  doLast {
    val backendPaths = listOf(
      "app/src/main/AndroidManifest.xml",
      "app/src/main/res/xml/file_paths.xml",
      "app/src/main/java/com/example/domain/CargoModels.kt",
      "app/src/main/java/com/example/domain/CargoStateMachine.kt",
      "app/src/main/java/com/example/domain/RbacPolicyEngine.kt",
      "app/src/main/java/com/example/domain/SecurityHasher.kt",
      "app/src/main/java/com/example/domain/ValidationEngine.kt",
      "app/src/main/java/com/example/domain/BarcodeEngine.kt",
      "app/src/main/java/com/example/domain/ShipmentManifestPdfGenerator.kt",
      "app/src/main/java/com/example/data/local/CargoFlowEntities.kt",
      "app/src/main/java/com/example/data/local/CargoFlowDao.kt",
      "app/src/main/java/com/example/data/local/CargoFlowDatabase.kt",
      "app/src/main/java/com/example/data/remote/CargoFlowApiService.kt",
      "app/src/main/java/com/example/data/repository/CargoFlowRepository.kt",
      "app/src/main/java/com/example/data/seed/SyntheticDataSeeder.kt",
      "app/src/main/java/com/example/scanner/Code128LuminanceDecoder.kt",
      "app/src/main/java/com/example/scanner/CargoBarcodeFrameAnalyzer.kt"
    )
    val frontendPaths = listOf(
      "app/src/main/java/com/example/MainActivity.kt",
      "app/src/main/java/com/example/ui/viewmodel/CargoFlowViewModel.kt",
      "app/src/main/java/com/example/ui/theme/Color.kt",
      "app/src/main/java/com/example/ui/theme/Type.kt",
      "app/src/main/java/com/example/ui/theme/Theme.kt",
      "app/src/main/java/com/example/ui/components/CargoFlowLaunchSplash.kt",
      "app/src/main/java/com/example/ui/components/LogisticsComponents.kt",
      "app/src/main/java/com/example/ui/components/CargoCameraScanner.kt",
      "app/src/main/java/com/example/ui/components/ScannedManifestPdfCard.kt",
      "app/src/main/java/com/example/ui/auth/OperationsAuthScreen.kt",
      "app/src/main/java/com/example/ui/publicportal/PublicPortalScreen.kt",
      "app/src/main/java/com/example/ui/operations/OperationsShell.kt",
      "app/src/main/java/com/example/ui/operations/DashboardScreen.kt",
      "app/src/main/java/com/example/ui/operations/ShipmentsScreen.kt",
      "app/src/main/java/com/example/ui/operations/InventoryScreen.kt",
      "app/src/main/java/com/example/ui/operations/WorkforceAndAuditScreen.kt",
      "app/src/main/java/com/example/ui/operations/ScannerScreen.kt",
      "app/src/main/res/values/strings.xml",
      "app/src/main/res/values/themes.xml"
    )

    fun esc(s: String): String = s
      .replace("\\", "\\\\")
      .replace("(", "\\(")
      .replace(")", "\\)")
      .replace(Regex("[^\\x20-\\x7E]"), " ")

    fun wrapCodeLine(lineNum: Int, raw: String, maxChars: Int = 96): List<String> {
      val clean = raw.replace("\t", "    ")
      val prefix = String.format(Locale.US, "%4d | ", lineNum)
      val contPrefix = "     | "
      if (clean.length <= maxChars) return listOf(prefix + clean)
      val out = mutableListOf<String>()
      var idx = 0
      var first = true
      while (idx < clean.length) {
        val end = minOf(idx + maxChars, clean.length)
        out.add((if (first) prefix else contPrefix) + clean.substring(idx, end))
        first = false
        idx = end
      }
      return out
    }

    data class CodePage(val section: String, val filePath: String, val lines: List<String>)
    val codePages = mutableListOf<CodePage>()
    val tocEntries = mutableListOf<Triple<String, String, Int>>() // section, path, 1-based page number
    val linesPerPage = 74
    var totalLinesOfCode = 0

    // Reserve page 1 for Cover + Table of Contents
    fun addSectionFiles(sectionName: String, paths: List<String>) {
      for (rel in paths) {
        val f = File(rootDirFile, rel)
        if (!f.exists()) continue
        val rawLines = f.readLines(Charsets.UTF_8)
        totalLinesOfCode += rawLines.size
        val formatted = mutableListOf<String>()
        rawLines.forEachIndexed { idx, line ->
          formatted.addAll(wrapCodeLine(idx + 1, line))
        }
        val startPageNum = 2 + codePages.size
        tocEntries.add(Triple(sectionName, rel, startPageNum))
        if (formatted.isEmpty()) {
          codePages.add(CodePage(sectionName, rel, listOf("   1 | (empty file)")))
        } else {
          formatted.chunked(linesPerPage).forEach { chunk ->
            codePages.add(CodePage(sectionName, rel, chunk))
          }
        }
      }
    }

    addSectionFiles("PART 1: BACKEND (DATA, DOMAIN, RBAC & SCANNER)", backendPaths)
    addSectionFiles("PART 2: FRONTEND (JETPACK COMPOSE UI & THEME)", frontendPaths)

    val totalPages = 1 + codePages.size
    val pageStreams = mutableListOf<String>()

    // Cover + Table of Contents Page (Page 1)
    val coverStream = buildString {
      // Maritime Navy header banner + Amber accent bar
      appendLine("0.043 0.090 0.165 rg 0 742 595 100 re f")
      appendLine("0.961 0.620 0.043 rg 0 738 595 4 re f")
      appendLine("BT /F2 22 Tf 1 1 1 rg 36 802 Td (CargoFlow - Complete Source Code) Tj ET")
      appendLine("BT /F2 10 Tf 0.961 0.620 0.043 rg 36 782 Td (BACKEND DATA/DOMAIN LAYER & FRONTEND JETPACK COMPOSE UI) Tj ET")
      appendLine("BT /F1 9 Tf 0.80 0.85 0.92 rg 36 760 Td (${esc("Files: ${tocEntries.size} (${backendPaths.size} Backend, ${frontendPaths.size} Frontend) | Total Lines: $totalLinesOfCode | Total Pages: $totalPages")}) Tj ET")

      var y = 716f
      var lastSection = ""
      for ((section, path, pageNum) in tocEntries) {
        if (section != lastSection) {
          y -= 10f
          appendLine("BT /F2 9.5 Tf 0.043 0.090 0.165 rg 36 $y Td (${esc(section)}) Tj ET")
          y -= 4f
          appendLine("0.961 0.620 0.043 RG 0.8 w 36 $y m 559 $y l S")
          y -= 12f
          lastSection = section
        }
        val shortPath = path.removePrefix("app/src/main/java/com/example/").removePrefix("app/src/main/")
        val lineStr = String.format(Locale.US, "%-72s  p.%3d", shortPath, pageNum)
        appendLine("BT /F1 8 Tf 0.15 0.20 0.28 rg 42 $y Td (${esc(lineStr)}) Tj ET")
        y -= 11.8f
      }
      appendLine("0.80 0.84 0.88 RG 0.6 w 36 36 m 559 36 l S")
      appendLine("BT /F1 7.5 Tf 0.40 0.45 0.52 rg 36 22 Td (CargoFlow Android Application Source Code Reference | Page 1 of $totalPages) Tj ET")
    }
    pageStreams.add(coverStream)

    // Code Pages (Pages 2..N)
    codePages.forEachIndexed { idx, cp ->
      val pageNum = idx + 2
      val stream = buildString {
        // Slim Navy Header Bar
        appendLine("0.043 0.090 0.165 rg 0 802 595 40 re f")
        appendLine("0.961 0.620 0.043 rg 0 800 595 2 re f")
        appendLine("BT /F2 8.5 Tf 0.961 0.620 0.043 rg 28 825 Td (${esc(cp.section)}) Tj ET")
        appendLine("BT /F1 8.5 Tf 1 1 1 rg 28 810 Td (${esc(cp.filePath)}) Tj ET")

        // Code block lines
        appendLine("BT /F1 7.3 Tf 0.08 0.11 0.16 rg 26 785 Td 10.0 TL")
        cp.lines.forEach { codeLine ->
          appendLine("(${esc(codeLine)}) Tj T*")
        }
        appendLine("ET")

        // Footer
        appendLine("0.82 0.86 0.90 RG 0.5 w 26 32 m 569 32 l S")
        appendLine("BT /F1 7.5 Tf 0.40 0.45 0.52 rg 26 18 Td (${esc("CargoFlow Source Code | ${cp.filePath} | Page $pageNum of $totalPages")}) Tj ET")
      }
      pageStreams.add(stream)
    }

    // Assemble standards-compliant PDF 1.4 with byte-accurate xref offsets
    val objects = mutableListOf<ByteArray>()
    objects.add(ByteArray(0)) // 1: Catalog
    objects.add(ByteArray(0)) // 2: Pages
    objects.add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>".toByteArray(Charsets.ISO_8859_1))      // 3: F1
    objects.add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>".toByteArray(Charsets.ISO_8859_1)) // 4: F2

    val pageObjIds = mutableListOf<Int>()
    for (content in pageStreams) {
      val contentBytes = content.toByteArray(Charsets.ISO_8859_1)
      val contentObjId = objects.size + 1
      val streamObj = ByteArrayOutputStream().apply {
        write("<< /Length ${contentBytes.size} >>\nstream\n".toByteArray(Charsets.ISO_8859_1))
        write(contentBytes)
        write("\nendstream".toByteArray(Charsets.ISO_8859_1))
      }.toByteArray()
      objects.add(streamObj)

      val pageObjId = objects.size + 1
      pageObjIds.add(pageObjId)
      val pageDict = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents $contentObjId 0 R >>"
      objects.add(pageDict.toByteArray(Charsets.ISO_8859_1))
    }

    objects[0] = "<< /Type /Catalog /Pages 2 0 R >>".toByteArray(Charsets.ISO_8859_1)
    objects[1] = "<< /Type /Pages /Kids [${pageObjIds.joinToString(" ") { "$it 0 R" }}] /Count ${pageObjIds.size} >>".toByteArray(Charsets.ISO_8859_1)

    outPdfFile.parentFile?.mkdirs()
    val outBytes = ByteArrayOutputStream()
    outBytes.write("%PDF-1.4\n".toByteArray(Charsets.ISO_8859_1))
    val offsets = IntArray(objects.size + 1)
    objects.forEachIndexed { idx, body ->
      offsets[idx + 1] = outBytes.size()
      outBytes.write("${idx + 1} 0 obj\n".toByteArray(Charsets.ISO_8859_1))
      outBytes.write(body)
      outBytes.write("\nendobj\n".toByteArray(Charsets.ISO_8859_1))
    }
    val xrefOffset = outBytes.size()
    outBytes.write("xref\n0 ${objects.size + 1}\n".toByteArray(Charsets.ISO_8859_1))
    outBytes.write("0000000000 65535 f \n".toByteArray(Charsets.ISO_8859_1))
    for (i in 1..objects.size) {
      outBytes.write(String.format(Locale.US, "%010d 00000 n \n", offsets[i]).toByteArray(Charsets.ISO_8859_1))
    }
    outBytes.write("trailer\n<< /Size ${objects.size + 1} /Root 1 0 R >>\nstartxref\n$xrefOffset\n%%EOF\n".toByteArray(Charsets.ISO_8859_1))

    outPdfFile.writeBytes(outBytes.toByteArray())
    println("Generated ${outPdfFile.name}: $totalPages pages, ${tocEntries.size} source files, $totalLinesOfCode lines (${outPdfFile.length() / 1024} KB)")
  }
}

tasks.register("exportSourceCodeZip") {
  val rootDirFile = rootProject.layout.projectDirectory.asFile
  val outZipFile = rootProject.layout.projectDirectory.file("docs/CargoFlow_Backend_and_Frontend_Code.zip").asFile
  doLast {
    val backendPaths = listOf(
      "app/src/main/AndroidManifest.xml",
      "app/src/main/res/xml/file_paths.xml",
      "app/src/main/java/com/example/domain/CargoModels.kt",
      "app/src/main/java/com/example/domain/CargoStateMachine.kt",
      "app/src/main/java/com/example/domain/RbacPolicyEngine.kt",
      "app/src/main/java/com/example/domain/SecurityHasher.kt",
      "app/src/main/java/com/example/domain/ValidationEngine.kt",
      "app/src/main/java/com/example/domain/BarcodeEngine.kt",
      "app/src/main/java/com/example/domain/ShipmentManifestPdfGenerator.kt",
      "app/src/main/java/com/example/data/local/CargoFlowEntities.kt",
      "app/src/main/java/com/example/data/local/CargoFlowDao.kt",
      "app/src/main/java/com/example/data/local/CargoFlowDatabase.kt",
      "app/src/main/java/com/example/data/remote/CargoFlowApiService.kt",
      "app/src/main/java/com/example/data/repository/CargoFlowRepository.kt",
      "app/src/main/java/com/example/data/seed/SyntheticDataSeeder.kt",
      "app/src/main/java/com/example/scanner/Code128LuminanceDecoder.kt",
      "app/src/main/java/com/example/scanner/CargoBarcodeFrameAnalyzer.kt"
    )
    val frontendPaths = listOf(
      "app/src/main/java/com/example/MainActivity.kt",
      "app/src/main/java/com/example/ui/viewmodel/CargoFlowViewModel.kt",
      "app/src/main/java/com/example/ui/theme/Color.kt",
      "app/src/main/java/com/example/ui/theme/Type.kt",
      "app/src/main/java/com/example/ui/theme/Theme.kt",
      "app/src/main/java/com/example/ui/components/CargoFlowLaunchSplash.kt",
      "app/src/main/java/com/example/ui/components/LogisticsComponents.kt",
      "app/src/main/java/com/example/ui/components/CargoCameraScanner.kt",
      "app/src/main/java/com/example/ui/components/ScannedManifestPdfCard.kt",
      "app/src/main/java/com/example/ui/auth/OperationsAuthScreen.kt",
      "app/src/main/java/com/example/ui/publicportal/PublicPortalScreen.kt",
      "app/src/main/java/com/example/ui/operations/OperationsShell.kt",
      "app/src/main/java/com/example/ui/operations/DashboardScreen.kt",
      "app/src/main/java/com/example/ui/operations/ShipmentsScreen.kt",
      "app/src/main/java/com/example/ui/operations/InventoryScreen.kt",
      "app/src/main/java/com/example/ui/operations/WorkforceAndAuditScreen.kt",
      "app/src/main/java/com/example/ui/operations/ScannerScreen.kt",
      "app/src/main/res/values/strings.xml",
      "app/src/main/res/values/colors.xml",
      "app/src/main/res/values/themes.xml"
    )
    val buildConfigPaths = listOf(
      "settings.gradle.kts",
      "build.gradle.kts",
      "app/build.gradle.kts",
      "gradle/libs.versions.toml"
    )

    outZipFile.parentFile?.mkdirs()
    val manifestEntries = mutableListOf<String>()
    var fileCount = 0

    ZipOutputStream(outZipFile.outputStream().buffered()).use { zos ->
      fun addGroup(groupFolder: String, paths: List<String>, stripPrefixes: List<String>) {
        manifestEntries.add("[$groupFolder]")
        for (rel in paths) {
          val src = File(rootDirFile, rel)
          if (!src.exists()) continue
          var innerPath = rel
          for (prefix in stripPrefixes) {
            if (innerPath.startsWith(prefix)) {
              innerPath = innerPath.removePrefix(prefix)
              break
            }
          }
          val entryName = "$groupFolder/$innerPath"
          zos.putNextEntry(ZipEntry(entryName))
          zos.write(src.readBytes())
          zos.closeEntry()
          manifestEntries.add("  - $entryName")
          fileCount++
        }
        manifestEntries.add("")
      }

      addGroup(
        "Backend",
        backendPaths,
        listOf("app/src/main/java/com/example/", "app/src/main/")
      )
      addGroup(
        "Frontend",
        frontendPaths,
        listOf("app/src/main/java/com/example/", "app/src/main/")
      )
      addGroup(
        "BuildConfig",
        buildConfigPaths,
        emptyList()
      )

      val readme = buildString {
        appendLine("CargoFlow Android Application - Backend & Frontend Source Code Archive")
        appendLine("======================================================================")
        appendLine("Language: Kotlin (Jetpack Compose, Room SQLite, CameraX, Material 3)")
        appendLine("Total Source & Config Files: $fileCount")
        appendLine()
        manifestEntries.forEach { appendLine(it) }
      }
      zos.putNextEntry(ZipEntry("README.txt"))
      zos.write(readme.toByteArray(Charsets.UTF_8))
      zos.closeEntry()
    }

    println("Generated ${outZipFile.name}: $fileCount files + README.txt (${outZipFile.length() / 1024} KB)")
  }
}
