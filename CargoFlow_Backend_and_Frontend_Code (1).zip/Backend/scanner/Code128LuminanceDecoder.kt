package com.example.scanner

import com.example.domain.BarcodeEngine
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Pure-Kotlin, zero-dependency Code-128B linear barcode decoder operating directly on
 * 8-bit grayscale luminance scanlines extracted from CameraX ImageProxy (YUV_420_888 Y-plane).
 *
 * Enforces strict Start-B (104), Mod-103 checksum, and Stop (106) verification to prevent
 * false-positive decodes from arbitrary warehouse edges or noise.
 */
object Code128LuminanceDecoder {

    private const val START_CODE_B = 104
    private const val STOP_CODE = 106
    private const val MIN_CONTRAST_RANGE = 36

    // Precomputed 6-bar/space pattern widths for codes 0..105 (each sums to 11 modules)
    private val symbolPatterns: Array<IntArray> by lazy {
        Array(106) { idx ->
            val p = BarcodeEngine.code128Patterns[idx]
            IntArray(6) { p[it].digitToInt() }
        }
    }

    // Stop pattern (106) has 7 elements summing to 13 modules: 2,3,3,1,1,1,2
    private val stopPattern = intArrayOf(2, 3, 3, 1, 1, 1, 2)

    /**
     * Attempts to decode a Code-128B barcode from a grayscale luminance row (0..255).
     * Automatically checks both left-to-right and right-to-left (upside-down label) orientations.
     */
    fun decodeScanline(luminance: IntArray): String? {
        if (luminance.size < 64) return null

        var minLuma = 255
        var maxLuma = 0
        for (v in luminance) {
            if (v < minLuma) minLuma = v
            if (v > maxLuma) maxLuma = v
        }
        if (maxLuma - minLuma < MIN_CONTRAST_RANGE) return null

        // Try standard threshold and two slight bias thresholds to handle uneven warehouse lighting
        val mid = (minLuma + maxLuma) / 2
        val thresholds = intArrayOf(mid, (minLuma * 0.42 + maxLuma * 0.58).roundToInt(), (minLuma * 0.58 + maxLuma * 0.42).roundToInt())

        for (threshold in thresholds) {
            val runs = extractRunLengths(luminance, threshold)
            if (runs.size >= 20) {
                decodeFromRuns(runs)?.let { return it }
                // Try reversed orientation (180-degree rotated barcode)
                val reversed = runs.reversed()
                decodeFromRuns(reversed)?.let { return it }
            }
        }
        return null
    }

    /**
     * Extracts alternating dark/light run lengths. Even indices represent dark bars,
     * odd indices represent light spaces (leading white quiet zone is skipped).
     */
    private fun extractRunLengths(luminance: IntArray, threshold: Int): List<Int> {
        var idx = 0
        val n = luminance.size
        // Skip leading light quiet zone until first dark pixel
        while (idx < n && luminance[idx] >= threshold) {
            idx++
        }
        if (idx >= n) return emptyList()

        val runs = ArrayList<Int>(128)
        var currentlyDark = true
        var count = 0
        while (idx < n) {
            val isDark = luminance[idx] < threshold
            if (isDark == currentlyDark) {
                count++
            } else {
                runs.add(count)
                currentlyDark = isDark
                count = 1
            }
            idx++
        }
        if (count > 0) runs.add(count)
        return runs
    }

    private fun decodeFromRuns(runs: List<Int>): String? {
        // Every symbol starts on a dark bar (even index in `runs`), except if reversed where
        // start might be on odd index — handle both by searching dark-start offsets
        val maxStartOffset = runs.size - 19 // Start(6) + >=1 char(6) + Checksum(6) + Stop(7) - tolerance
        for (startIdx in 0..maxStartOffset) {
            val startCode = matchSymbol(runs, startIdx)
            if (startCode != START_CODE_B) continue

            val decodedCodes = mutableListOf(START_CODE_B)
            var cursor = startIdx + 6
            var foundStop = false

            while (cursor + 6 <= runs.size) {
                // Check for 7-run Stop symbol first
                if (cursor + 7 <= runs.size && isStopPattern(runs, cursor)) {
                    foundStop = true
                    break
                }
                val sym = matchSymbol(runs, cursor)
                if (sym < 0 || sym >= 103) {
                    break
                }
                decodedCodes.add(sym)
                cursor += 6
                // Guard against runaway decodes
                if (decodedCodes.size > 48) break
            }

            if (!foundStop || decodedCodes.size < 3) continue

            // Verify Mod-103 checksum:
            // decodedCodes = [START_B, c1, c2, ..., cK, CHECKSUM]
            val expectedChecksum = decodedCodes.last()
            var weightedSum = decodedCodes[0]
            for (i in 1 until decodedCodes.lastIndex) {
                weightedSum += decodedCodes[i] * i
            }
            if ((weightedSum % 103) != expectedChecksum) continue

            // Convert Code-128B values (0..94 -> ASCII 32..126)
            val text = buildString(decodedCodes.size - 2) {
                for (i in 1 until decodedCodes.lastIndex) {
                    val c = decodedCodes[i]
                    if (c in 0..94) {
                        append((c + 32).toChar())
                    }
                }
            }.trim()

            if (text.length >= 4) {
                return text
            }
        }
        return null
    }

    private fun matchSymbol(runs: List<Int>, offset: Int): Int {
        if (offset + 6 > runs.size) return -1
        var totalWidth = 0
        for (i in 0 until 6) totalWidth += runs[offset + i]
        if (totalWidth < 6) return -1

        val moduleSize = totalWidth / 11.0
        var bestCode = -1
        var bestError = Double.MAX_VALUE

        for (code in symbolPatterns.indices) {
            val pattern = symbolPatterns[code]
            var totalErr = 0.0
            var valid = true
            for (i in 0 until 6) {
                val normalized = runs[offset + i] / moduleSize
                val diff = abs(normalized - pattern[i])
                if (diff > 0.62) {
                    valid = false
                    break
                }
                totalErr += diff
            }
            if (valid && totalErr < bestError && totalErr < 1.95) {
                bestError = totalErr
                bestCode = code
            }
        }
        return bestCode
    }

    private fun isStopPattern(runs: List<Int>, offset: Int): Boolean {
        if (offset + 7 > runs.size) return false
        var totalWidth = 0
        for (i in 0 until 7) totalWidth += runs[offset + i]
        if (totalWidth < 7) return false
        val moduleSize = totalWidth / 13.0
        var totalErr = 0.0
        for (i in 0 until 7) {
            val diff = abs((runs[offset + i] / moduleSize) - stopPattern[i])
            if (diff > 0.65) return false
            totalErr += diff
        }
        return totalErr < 2.2
    }
}
