package com.example.scanner

import android.graphics.ImageFormat
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.domain.BarcodeEngine

/**
 * CameraX ImageAnalysis.Analyzer that samples multiple scanlines across the central
 * targeting reticle from YUV_420_888 luminance frames, handles 90/270-degree sensor
 * rotation, decodes Code-128B shipment/package barcodes, and debounces duplicate reads.
 */
class CargoBarcodeFrameAnalyzer(
    private val isEnabledProvider: () -> Boolean,
    private val onIdentifierDetected: (String) -> Unit,
    private val onFrameTelemetry: (fps: Int, contrastReady: Boolean) -> Unit = { _, _ -> },
    private val sameCodeCooldownMs: Long = 2_500L,
    private val globalCooldownMs: Long = 600L
) : ImageAnalysis.Analyzer {

    private var lastDecodedCode: String? = null
    private var lastDecodedTimeMs: Long = 0L
    private var frameCounter = 0
    private var fpsWindowStartMs = System.currentTimeMillis()
    private var currentFps = 0

    override fun analyze(imageProxy: ImageProxy) {
        try {
            if (!isEnabledProvider()) return
            if (imageProxy.format != ImageFormat.YUV_420_888 || imageProxy.planes.isEmpty()) return

            val now = System.currentTimeMillis()
            frameCounter++
            val elapsed = now - fpsWindowStartMs
            if (elapsed >= 1_000L) {
                currentFps = ((frameCounter * 1000L) / elapsed).toInt()
                frameCounter = 0
                fpsWindowStartMs = now
            }

            if (now - lastDecodedTimeMs < globalCooldownMs) return

            val yPlane = imageProxy.planes[0]
            val buffer = yPlane.buffer
            val rowStride = yPlane.rowStride
            val pixelStride = yPlane.pixelStride
            val width = imageProxy.width
            val height = imageProxy.height
            val rotation = imageProxy.imageInfo.rotationDegrees

            // Copy Y-plane once into a contiguous byte array for fast multi-line sampling
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)

            val sampleRatios = floatArrayOf(0.50f, 0.43f, 0.57f, 0.36f, 0.64f, 0.30f, 0.70f)
            var highContrastSeen = false

            // On portrait devices the sensor is rotated 90/270 degrees, so a horizontal barcode
            // in the viewfinder aligns along columns in sensor space; sample both axes if rotated.
            val sampleColumnsFirst = (rotation == 90 || rotation == 270)

            val decoded = if (sampleColumnsFirst) {
                scanVerticalLines(bytes, width, height, rowStride, pixelStride, sampleRatios) { highContrastSeen = true }
                    ?: scanHorizontalLines(bytes, width, height, rowStride, pixelStride, sampleRatios) { highContrastSeen = true }
            } else {
                scanHorizontalLines(bytes, width, height, rowStride, pixelStride, sampleRatios) { highContrastSeen = true }
                    ?: scanVerticalLines(bytes, width, height, rowStride, pixelStride, sampleRatios) { highContrastSeen = true }
            }

            onFrameTelemetry(currentFps, highContrastSeen)

            if (decoded != null) {
                val normalized = BarcodeEngine.extractCodeFromScannedPayload(decoded)
                val isDuplicateInCooldown =
                    normalized == lastDecodedCode && (now - lastDecodedTimeMs) < sameCodeCooldownMs
                if (!isDuplicateInCooldown) {
                    lastDecodedCode = normalized
                    lastDecodedTimeMs = now
                    onIdentifierDetected(normalized)
                }
            }
        } finally {
            imageProxy.close()
        }
    }

    private fun scanHorizontalLines(
        bytes: ByteArray,
        width: Int,
        height: Int,
        rowStride: Int,
        pixelStride: Int,
        ratios: FloatArray,
        onContrast: () -> Unit
    ): String? {
        val line = IntArray(width)
        for (ratio in ratios) {
            val y = (height * ratio).toInt().coerceIn(0, height - 1)
            val rowOffset = y * rowStride
            var minV = 255
            var maxV = 0
            for (x in 0 until width) {
                val idx = rowOffset + x * pixelStride
                val v = if (idx in bytes.indices) bytes[idx].toInt() and 0xFF else 128
                line[x] = v
                if (v < minV) minV = v
                if (v > maxV) maxV = v
            }
            if (maxV - minV >= 40) onContrast()
            val decoded = Code128LuminanceDecoder.decodeScanline(line)
            if (decoded != null) return decoded
        }
        return null
    }

    private fun scanVerticalLines(
        bytes: ByteArray,
        width: Int,
        height: Int,
        rowStride: Int,
        pixelStride: Int,
        ratios: FloatArray,
        onContrast: () -> Unit
    ): String? {
        val line = IntArray(height)
        for (ratio in ratios) {
            val x = (width * ratio).toInt().coerceIn(0, width - 1)
            val colOffset = x * pixelStride
            var minV = 255
            var maxV = 0
            for (y in 0 until height) {
                val idx = y * rowStride + colOffset
                val v = if (idx in bytes.indices) bytes[idx].toInt() and 0xFF else 128
                line[y] = v
                if (v < minV) minV = v
                if (v > maxV) maxV = v
            }
            if (maxV - minV >= 40) onContrast()
            val decoded = Code128LuminanceDecoder.decodeScanline(line)
            if (decoded != null) return decoded
        }
        return null
    }
}
