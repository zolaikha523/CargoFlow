package com.example.data.seed

import androidx.room.withTransaction
import com.example.data.local.AuditLogEntity
import com.example.data.local.CargoFlowDatabase
import com.example.data.local.CustomerEntity
import com.example.data.local.EmployeeEntity
import com.example.data.local.PackageEntity
import com.example.data.local.ShipmentEntity
import com.example.data.local.StatusHistoryEntity
import com.example.data.local.TaskEntity
import com.example.domain.AuditOutcome
import com.example.domain.BarcodeEngine
import com.example.domain.BenchmarkReport
import com.example.domain.CargoStatus
import com.example.domain.CustomerTier
import com.example.domain.SecurityHasher
import com.example.domain.ServiceTier
import com.example.domain.TaskPriority
import com.example.domain.TaskStatus
import com.example.domain.UserRole
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Deterministic high-throughput synthetic dataset seeder & query performance evaluator.
 * - Boot seed: ~900 realistic records (< 150ms) including 5 verifiable RBAC demo operator accounts.
 * - Full-scale benchmark seed: 10,500+ synthetic records across all 7 tables + latency benchmarks.
 */
object SyntheticDataSeeder {

    data class DemoAccountSpec(
        val id: String,
        val code: String,
        val fullName: String,
        val email: String,
        val plainPassword: String,
        val role: UserRole,
        val hub: String
    )

    val demoAccounts: List<DemoAccountSpec> = listOf(
        DemoAccountSpec("emp-admin-01", "EMP-0001", "Noorulhuda Popal", "admin@cargoflow.io", "Admin@2026!", UserRole.ADMIN, "Kabul, Afghanistan"),
        DemoAccountSpec("emp-mgr-01", "EMP-0002", "Omid Moqadas", "ops@cargoflow.io", "OpsMgr@2026!", UserRole.OPS_MANAGER, "Kandahar, Afghanistan"),
        DemoAccountSpec("emp-dsp-01", "EMP-0003", "Sharafat Gul", "dispatch@cargoflow.io", "Dispatch@2026!", UserRole.DISPATCHER, "Mazar, Afghanistan"),
        DemoAccountSpec("emp-whs-01", "EMP-0004", "Kaaba", "warehouse@cargoflow.io", "Warehouse@2026!", UserRole.WAREHOUSE_STAFF, "Kabul, Afghanistan"),
        DemoAccountSpec("emp-drv-01", "EMP-0005", "Fawzia", "driver@cargoflow.io", "Driver@2026!", UserRole.DRIVER, "Mazar, Afghanistan")
    )

    private val hubs = listOf(
        "Rotterdam MegaHub" to "Rotterdam, NL",
        "Memphis AirHub" to "Memphis, US",
        "Frankfurt Gateway" to "Frankfurt, DE",
        "Singapore Port Terminal" to "Singapore, SG",
        "Dubai Logistics City" to "Dubai, AE",
        "Chicago Corridor" to "Chicago, US"
    )

    private val destinations = listOf(
        "Berlin" to "Germany",
        "Austin" to "United States",
        "Tokyo" to "Japan",
        "Zurich" to "Switzerland",
        "Toronto" to "Canada",
        "London" to "United Kingdom",
        "Seoul" to "South Korea",
        "Milan" to "Italy",
        "Sydney" to "Australia",
        "Amsterdam" to "Netherlands"
    )

    private val zones = listOf("ZONE-A", "ZONE-B", "ZONE-C", "ZONE-COLD", "ZONE-HAZMAT", "ZONE-EXPRESS")

    private val cargoDescriptions = listOf(
        "Precision Optical Sensors",
        "Lithium Industrial Battery Array",
        "Pharmaceutical Cold-Pack Vials",
        "CNC Aerospace Titanium Housing",
        "Autonomous Robotics Actuator Kit",
        "High-Density Server Blade Chassis",
        "Diagnostic Imaging Transducers",
        "Solar Inverter Control Module"
    )

    private val companyPrefixes = listOf(
        "Nordic", "Apex", "Helios", "Vanguard", "Meridian", "Kestrel",
        "Aether", "Stratos", "Cobalt", "Orion", "Solstice", "Vertex"
    )
    private val companySuffixes = listOf(
        "Industries", "MedTech", "Semiconductors", "BioLabs", "Freight Co.",
        "Dynamics", "Systems", "Robotics", "Supply Group", "Manufacturing"
    )

    suspend fun ensureInitialDataset(db: CargoFlowDatabase) {
        val dao = db.cargoFlowDao()
        if (dao.countActiveEmployees() > 0 && dao.countShipments() > 0) {
            db.withTransaction {
                for (spec in demoAccounts) {
                    dao.updateEmployeeProfile(spec.id, spec.fullName, spec.hub)
                    dao.updateStatusHistoryActorName(spec.id, spec.fullName)
                }
                dao.reassignTasksFromSyntheticEmployees("emp-whs-01")
                dao.reassignShipmentsFromSyntheticEmployees("emp-dsp-01")
                dao.deleteSyntheticEmployees()
                dao.sanitizeLegacyCustomerContacts()
            }
            return
        }
        seedDataset(
            db = db,
            customerCount = 40,
            extraEmployeeCount = 0,
            shipmentCount = 140,
            packagesPerShipmentAvg = 2,
            taskCount = 65
        )
    }

    /**
     * Seeds at least 10,500+ synthetic records in batched Room transactions and evaluates
     * indexed query performance across critical operational workloads.
     */
    suspend fun seedTenThousandAndBenchmark(db: CargoFlowDatabase): BenchmarkReport {
        val seedStartNs = System.nanoTime()
        seedDataset(
            db = db,
            customerCount = 300,
            extraEmployeeCount = 0,
            shipmentCount = 2_400,
            packagesPerShipmentAvg = 2,
            taskCount = 950
        )
        val seedDurationMs = (System.nanoTime() - seedStartNs) / 1_000_000L

        val dao = db.cargoFlowDao()
        val now = System.currentTimeMillis()
        val totalRecords = dao.countTotalRecordsAcrossSystem()

        // 1. Indexed tracking number point lookup (average of 10 lookups)
        val trackingStartNs = System.nanoTime()
        repeat(10) { idx ->
            val targetNum = BarcodeEngine.generateTrackingNumber((idx * 200 + 1).toLong())
            dao.getShipmentByTrackingNumber(targetNum)
        }
        val trackingMs = ((System.nanoTime() - trackingStartNs) / 1_000_000.0) / 10.0

        // 2. Full Dashboard multi-table aggregation
        val dashStartNs = System.nanoTime()
        dao.getShipmentStatusBreakdown()
        dao.getWarehouseZoneSummary()
        dao.getStaffWorkloadSummary()
        dao.countPendingSlaBreaches(now)
        val dashMs = (System.nanoTime() - dashStartNs) / 1_000_000.0

        // 3. Delayed & SLA-breach composite index query
        val delayedStartNs = System.nanoTime()
        dao.getDelayedOrAtRiskShipments(now, limit = 100)
        val delayedMs = (System.nanoTime() - delayedStartNs) / 1_000_000.0

        // 4. Paginated search query
        val searchStartNs = System.nanoTime()
        dao.searchShipmentsPaginated(statusFilter = CargoStatus.IN_TRANSIT.name, query = "CF-2026", limit = 50, offset = 0)
        val searchMs = (System.nanoTime() - searchStartNs) / 1_000_000.0

        return BenchmarkReport(
            totalSeededRecords = totalRecords,
            seedDurationMs = seedDurationMs,
            indexedTrackingLookupMs = (trackingMs * 100.0).roundToInt() / 100.0,
            dashboardAggregationMs = (dashMs * 100.0).roundToInt() / 100.0,
            delayedQueryMs = (delayedMs * 100.0).roundToInt() / 100.0,
            paginatedSearchMs = (searchMs * 100.0).roundToInt() / 100.0,
            evaluatedAtEpochMs = now
        )
    }

    suspend fun seedDataset(
        db: CargoFlowDatabase,
        customerCount: Int,
        extraEmployeeCount: Int,
        shipmentCount: Int,
        packagesPerShipmentAvg: Int,
        taskCount: Int
    ) {
        val dao = db.cargoFlowDao()
        val rng = Random(20261120)
        val now = System.currentTimeMillis()
        val hourMs = 3_600_000L

        // 1. Employees (5 deterministic demo operators + extra synthetic workforce)
        val employees = mutableListOf<EmployeeEntity>()
        for (spec in demoAccounts) {
            val salt = "salt_${spec.id}"
            employees.add(
                EmployeeEntity(
                    id = spec.id,
                    employeeCode = spec.code,
                    fullName = spec.fullName,
                    email = spec.email,
                    passwordHash = SecurityHasher.hashPassword(spec.plainPassword, salt),
                    passwordSalt = salt,
                    role = spec.role.name,
                    hubLocation = spec.hub,
                    active = true,
                    createdAt = now - 90L * 24 * hourMs
                )
            )
        }
        val firstNames = listOf("Arif", "Zainab", "Farid", "Samira", "Jawad", "Leila", "Hamed", "Mariam", "Bilal", "Soraya")
        val lastNames = listOf("Rahimi", "Karimi", "Okafor", "Moreau", "Sato", "Bauer", "Silva", "Novak", "Kim", "Haddad")
        val synthRoles = listOf(UserRole.WAREHOUSE_STAFF, UserRole.DRIVER, UserRole.DISPATCHER, UserRole.OPS_MANAGER)
        // Reuse precomputed password hash for synthetic non-demo workers so 50 employees seed in <5ms
        val synthSalt = "salt_synthetic_worker"
        val synthHash = SecurityHasher.hashPassword("CargoWorker@2026!", synthSalt)
        for (i in 1..extraEmployeeCount) {
            val fn = firstNames[i % firstNames.size]
            val ln = lastNames[(i / firstNames.size) % lastNames.size]
            val role = synthRoles[i % synthRoles.size]
            val empId = "emp-synth-${i.toString().padStart(3, '0')}"
            employees.add(
                EmployeeEntity(
                    id = empId,
                    employeeCode = "EMP-${(1000 + i)}",
                    fullName = "$fn $ln",
                    email = "${fn.lowercase()}.${ln.lowercase()}.$i@cargoflow.io",
                    passwordHash = synthHash,
                    passwordSalt = synthSalt,
                    role = role.name,
                    hubLocation = hubs[i % hubs.size].first,
                    active = true,
                    createdAt = now - (30L + i) * 24 * hourMs
                )
            )
        }

        // 2. Customers
        val customers = List(customerCount) { idx ->
            val num = idx + 1
            val prefix = companyPrefixes[idx % companyPrefixes.size]
            val suffix = companySuffixes[(idx / companyPrefixes.size) % companySuffixes.size]
            val dest = destinations[idx % destinations.size]
            val tier = CustomerTier.entries[idx % CustomerTier.entries.size]
            CustomerEntity(
                id = "cust-${num.toString().padStart(4, '0')}",
                accountCode = "ACC-${(10_000 + num)}",
                companyName = "$prefix $suffix #$num",
                contactName = "${firstNames[idx % firstNames.size]} ${lastNames[(idx + 3) % lastNames.size]}",
                email = "logistics$num@${prefix.lowercase()}${num}.com",
                phone = "+1-555-${(200 + (num % 700)).toString().padStart(3, '0')}-${(1000 + (num * 17) % 8999)}",
                tier = tier.name,
                city = dest.first,
                country = dest.second,
                createdAt = now - (120L - (idx % 90)) * 24 * hourMs
            )
        }

        // 3. Shipments, Packages, Status History, Tasks
        val shipments = ArrayList<ShipmentEntity>(shipmentCount)
        val packages = ArrayList<PackageEntity>(shipmentCount * packagesPerShipmentAvg)
        val histories = ArrayList<StatusHistoryEntity>(shipmentCount * 3)
        val tasks = ArrayList<TaskEntity>(taskCount)

        val weightedStatuses = listOf(
            CargoStatus.RECEIVED,
            CargoStatus.WAREHOUSE, CargoStatus.WAREHOUSE,
            CargoStatus.DISPATCHED, CargoStatus.DISPATCHED,
            CargoStatus.IN_TRANSIT, CargoStatus.IN_TRANSIT, CargoStatus.IN_TRANSIT,
            CargoStatus.OUT_FOR_DELIVERY,
            CargoStatus.DELAYED,
            CargoStatus.ON_HOLD,
            CargoStatus.DELIVERED, CargoStatus.DELIVERED, CargoStatus.DELIVERED
        )

        for (i in 1..shipmentCount) {
            val tracking = BarcodeEngine.generateTrackingNumber(i.toLong(), 2026)
            val customer = customers[(i - 1) % customers.size]
            val hubPair = hubs[i % hubs.size]
            val destPair = destinations[(i + 2) % destinations.size]
            val tier = ServiceTier.entries[i % ServiceTier.entries.size]
            val status = when (i) {
                1 -> CargoStatus.IN_TRANSIT // Guaranteed flagship demo shipment CF-2026-000001
                2 -> CargoStatus.DELAYED    // Guaranteed delayed alert CF-2026-000002
                3 -> CargoStatus.WAREHOUSE  // Guaranteed warehouse ready for dispatch CF-2026-000003
                4 -> CargoStatus.RECEIVED   // Guaranteed intake shipment CF-2026-000004
                5 -> CargoStatus.DELIVERED  // Guaranteed delivered timeline CF-2026-000005
                else -> weightedStatuses[rng.nextInt(weightedStatuses.size)]
            }
            val createdAt = now - rng.nextLong(6L, 220L) * hourMs
            val slaDeadline = if (status == CargoStatus.DELAYED || (i % 13 == 0 && !status.isTerminal)) {
                now - rng.nextLong(2L, 36L) * hourMs // Past SLA deadline
            } else {
                createdAt + tier.slaHours * hourMs + 24L * hourMs
            }
            val updatedAt = (createdAt + rng.nextLong(2L, 48L) * hourMs).coerceAtMost(now)
            val assignedEmp = employees[i % employees.size]
            val shipmentId = "shp-${i.toString().padStart(6, '0')}"

            val pkgCount = if (i % 3 == 0) packagesPerShipmentAvg + 1 else packagesPerShipmentAvg
            var totalWeight = 0.0
            for (p in 1..pkgCount) {
                val pkgWeight = ((rng.nextDouble(2.5, 48.0)) * 10.0).roundToInt() / 10.0
                totalWeight += pkgWeight
                val pkgCode = BarcodeEngine.generatePackageCode(tracking, p)
                val zone = zones[(i + p) % zones.size]
                val bin = "${zone.removePrefix("ZONE-")}-R${(i % 18) + 1}-B${(p * 3) + (i % 9)}"
                packages.add(
                    PackageEntity(
                        id = "pkg-$i-$p",
                        packageCode = pkgCode,
                        barcodeValue = pkgCode,
                        qrPayload = BarcodeEngine.buildPackageQrPayload(pkgCode, tracking, zone),
                        shipmentId = shipmentId,
                        sku = "SKU-${(10000 + (i * 7 + p) % 89999)}",
                        description = cargoDescriptions[(i + p) % cargoDescriptions.size],
                        weightKg = pkgWeight,
                        dimensionsCm = "${30 + (p * 10)}x${25 + (i % 20)}x${20 + (p * 5)}",
                        warehouseZone = zone,
                        binLocation = bin,
                        status = status.name,
                        fragile = (i + p) % 4 == 0,
                        createdAt = createdAt
                    )
                )
            }
            totalWeight = (totalWeight * 10.0).roundToInt() / 10.0

            shipments.add(
                ShipmentEntity(
                    id = shipmentId,
                    trackingNumber = tracking,
                    barcodeValue = tracking,
                    qrPayload = BarcodeEngine.buildShipmentQrPayload(tracking, hubPair.first, destPair.first),
                    customerId = customer.id,
                    originHub = hubPair.first,
                    destinationCity = destPair.first,
                    destinationCountry = destPair.second,
                    serviceTier = tier.name,
                    status = status.name,
                    totalWeightKg = totalWeight,
                    declaredValueUsd = ((totalWeight * 145.0 + rng.nextInt(250, 4500)) * 100).roundToInt() / 100.0,
                    internalNotes = "INTERNAL: Contract rate tier ${customer.tier}; dock security seal #SL-${4000 + i}; margin code M-${i % 9}.",
                    assignedEmployeeId = assignedEmp.id,
                    slaDeadlineEpoch = slaDeadline,
                    createdAt = createdAt,
                    updatedAt = updatedAt
                )
            )

            // Realistic chronological status history trail for every shipment
            val trail = buildLifecycleTrail(status)
            var stepTime = createdAt
            for (stepIdx in trail.indices) {
                val toState = trail[stepIdx]
                val fromState = if (stepIdx == 0) CargoStatus.CREATED else trail[stepIdx - 1]
                val actor = employees[(i + stepIdx) % demoAccounts.size]
                val facility = if (stepIdx < 3) hubPair.first else "${destPair.first} Regional Terminal"
                val publicLoc = if (stepIdx < 3) hubPair.second else "${destPair.first}, ${destPair.second}"
                histories.add(
                    StatusHistoryEntity(
                        shipmentId = shipmentId,
                        fromStatus = fromState.name,
                        toStatus = toState.name,
                        actorId = actor.id,
                        actorName = actor.fullName,
                        actorRole = actor.role,
                        facilityLocation = facility,
                        publicLocationLabel = publicLoc,
                        notes = "Verified checkpoint scan for ${toState.displayLabel}",
                        timestamp = stepTime
                    )
                )
                stepTime = (stepTime + rng.nextLong(2L, 12L) * hourMs).coerceAtMost(now)
            }
        }

        // 4. Tasks
        val taskTemplates = listOf(
            "Verify Receiving Dock Manifest & Weight",
            "Stow Pallets in Assigned Warehouse Bin",
            "Inspect Fragile Seal & Customs Clearance",
            "Load Outbound Carrier & Scan Barcode",
            "Confirm Final-Mile Proof of Delivery",
            "Resolve SLA Delay & Reroute Freight"
        )
        val taskStatuses = listOf(TaskStatus.PENDING, TaskStatus.IN_PROGRESS, TaskStatus.COMPLETED, TaskStatus.BLOCKED)
        for (t in 1..taskCount) {
            val shp = shipments[(t - 1) % shipments.size]
            val assignee = when (t) {
                1, 2, 3 -> employees.first { it.id == "emp-whs-01" }
                4, 5, 6 -> employees.first { it.id == "emp-drv-01" }
                else -> employees[t % employees.size]
            }
            val assigner = employees[t % 3] // Admin, OpsMgr, or Dispatcher
            val tStatus = when (t) {
                1, 4 -> TaskStatus.PENDING
                2, 5 -> TaskStatus.IN_PROGRESS
                3, 6 -> TaskStatus.PENDING
                else -> taskStatuses[t % taskStatuses.size]
            }
            val priority = when (t) {
                1, 4 -> TaskPriority.CRITICAL
                2, 5 -> TaskPriority.HIGH
                else -> TaskPriority.entries[t % TaskPriority.entries.size]
            }
            val title = when (t) {
                1 -> "Verify Receiving Dock Manifest & Weight"
                2 -> "Stow Pallets in Assigned Warehouse Bin"
                3 -> "Load Outbound Carrier & Scan Barcode"
                4 -> "Confirm Final-Mile Proof of Delivery"
                5 -> "Deliver Priority Corridor Freight & Scan POD"
                6 -> "Report Transit Checkpoint at Destination Hub"
                else -> taskTemplates[t % taskTemplates.size]
            }
            tasks.add(
                TaskEntity(
                    id = "tsk-${t.toString().padStart(5, '0')}",
                    shipmentId = shp.id,
                    assignedToId = assignee.id,
                    assignedById = assigner.id,
                    title = title,
                    instructions = "Execute SOP checklist for ${shp.trackingNumber} at ${assignee.hubLocation}.",
                    status = tStatus.name,
                    priority = priority.name,
                    dueAt = now + rng.nextLong(-12L, 72L) * hourMs,
                    createdAt = shp.createdAt,
                    updatedAt = now - rng.nextLong(0L, 12L) * hourMs
                )
            )
        }

        // 5. Commit all entities in batched transactions for high throughput
        db.withTransaction {
            dao.insertEmployees(employees)
            customers.chunked(500).forEach { dao.insertCustomers(it) }
            shipments.chunked(500).forEach { dao.insertShipments(it) }
            packages.chunked(1000).forEach { dao.insertPackages(it) }
            if (dao.countStatusHistory() < histories.size) {
                histories.chunked(1000).forEach { dao.insertStatusHistoryBatch(it) }
            }
            tasks.chunked(500).forEach { dao.insertTasks(it) }

            val prevHash = dao.getLatestAuditHash() ?: SecurityHasher.GENESIS_HASH
            val details = "Seeded synthetic dataset: ${customers.size} customers, ${shipments.size} shipments, ${packages.size} packages, ${tasks.size} tasks."
            val entryHash = SecurityHasher.computeAuditHash(
                prevHash = prevHash,
                timestamp = now,
                actorId = "system-seeder",
                actorRole = UserRole.ADMIN.name,
                action = "DATASET_SEED",
                entityType = "SYSTEM",
                entityId = "cargoflow-db",
                outcome = AuditOutcome.ALLOWED.name,
                details = details
            )
            dao.insertAuditLog(
                AuditLogEntity(
                    timestamp = now,
                    actorId = "system-seeder",
                    actorRole = UserRole.ADMIN.name,
                    action = "DATASET_SEED",
                    entityType = "SYSTEM",
                    entityId = "cargoflow-db",
                    outcome = AuditOutcome.ALLOWED.name,
                    details = details,
                    prevHash = prevHash,
                    entryHash = entryHash
                )
            )
        }
    }

    private fun buildLifecycleTrail(finalStatus: CargoStatus): List<CargoStatus> {
        return when (finalStatus) {
            CargoStatus.CREATED -> listOf(CargoStatus.CREATED)
            CargoStatus.RECEIVED -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED)
            CargoStatus.WAREHOUSE -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED, CargoStatus.WAREHOUSE)
            CargoStatus.ON_HOLD -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED, CargoStatus.ON_HOLD)
            CargoStatus.DISPATCHED -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED, CargoStatus.WAREHOUSE, CargoStatus.DISPATCHED)
            CargoStatus.IN_TRANSIT -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED, CargoStatus.WAREHOUSE, CargoStatus.DISPATCHED, CargoStatus.IN_TRANSIT)
            CargoStatus.DELAYED -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED, CargoStatus.WAREHOUSE, CargoStatus.DISPATCHED, CargoStatus.IN_TRANSIT, CargoStatus.DELAYED)
            CargoStatus.OUT_FOR_DELIVERY -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED, CargoStatus.WAREHOUSE, CargoStatus.DISPATCHED, CargoStatus.IN_TRANSIT, CargoStatus.OUT_FOR_DELIVERY)
            CargoStatus.DELIVERED -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED, CargoStatus.WAREHOUSE, CargoStatus.DISPATCHED, CargoStatus.IN_TRANSIT, CargoStatus.OUT_FOR_DELIVERY, CargoStatus.DELIVERED)
            CargoStatus.RETURNED -> listOf(CargoStatus.CREATED, CargoStatus.RECEIVED, CargoStatus.WAREHOUSE, CargoStatus.RETURNED)
            CargoStatus.CANCELLED -> listOf(CargoStatus.CREATED, CargoStatus.CANCELLED)
        }
    }
}
