package com.example.data.remote

import com.example.domain.OperatorSession
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

/**
 * Production Retrofit REST API contract & RBAC header interceptor for connecting CargoFlow
 * to a remote CargoFlow Operations API server (e.g., Dockerized backend service).
 */
interface CargoFlowApiService {

    @GET("api/v1/public/track/{trackingNumber}")
    suspend fun getPublicTracking(@Path("trackingNumber") trackingNumber: String): PublicTrackingApiDto

    @POST("api/v1/ops/shipments")
    suspend fun createShipment(@Body request: CreateShipmentApiRequest): ShipmentApiResponse

    @POST("api/v1/ops/shipments/{shipmentId}/transition")
    suspend fun transitionShipment(
        @Path("shipmentId") shipmentId: String,
        @Body request: TransitionApiRequest
    ): ShipmentApiResponse

    @GET("api/v1/ops/audit")
    suspend fun fetchAuditLogs(): List<AuditLogApiDto>
}

@JsonClass(generateAdapter = true)
data class PublicTrackingApiDto(
    val trackingNumber: String,
    val status: String,
    val originRegion: String,
    val destinationCity: String,
    val destinationCountry: String,
    val packageCount: Int,
    val estimatedDeliveryEpochMs: Long
)

@JsonClass(generateAdapter = true)
data class CreateShipmentApiRequest(
    val customerId: String,
    val originHub: String,
    val destinationCity: String,
    val destinationCountry: String,
    val serviceTier: String,
    val totalWeightKg: Double,
    val declaredValueUsd: Double
)

@JsonClass(generateAdapter = true)
data class TransitionApiRequest(
    val targetStatus: String,
    val facilityLocation: String,
    val notes: String
)

@JsonClass(generateAdapter = true)
data class ShipmentApiResponse(
    val id: String,
    val trackingNumber: String,
    val status: String,
    val updatedAtEpochMs: Long
)

@JsonClass(generateAdapter = true)
data class AuditLogApiDto(
    val id: Long,
    val timestamp: Long,
    val actorId: String,
    val actorRole: String,
    val action: String,
    val outcome: String,
    val entryHash: String
)

class RbacAuthInterceptor(
    private val sessionProvider: () -> OperatorSession?
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val builder = original.newBuilder()
            .header("Accept", "application/json")
            .header("X-CargoFlow-Client", "android-v1")

        // Never attach operator credentials to unauthenticated public tracking routes
        val isPublicRoute = original.url.encodedPath.contains("/public/")
        if (!isPublicRoute) {
            sessionProvider()?.let { session ->
                builder.header("Authorization", "Bearer ${session.sessionToken}")
                builder.header("X-CargoFlow-Actor", session.employeeId)
                builder.header("X-CargoFlow-Role", session.role.name)
            }
        }
        return chain.proceed(builder.build())
    }
}

object CargoFlowApiFactory {
    fun create(
        baseUrl: String = "https://api.cargoflow.internal/",
        sessionProvider: () -> OperatorSession?
    ): CargoFlowApiService {
        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()

        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .addInterceptor(RbacAuthInterceptor(sessionProvider))
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(CargoFlowApiService::class.java)
    }
}
