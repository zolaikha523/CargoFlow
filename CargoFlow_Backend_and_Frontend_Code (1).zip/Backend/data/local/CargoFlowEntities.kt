package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "customers",
    indices = [
        Index(value = ["account_code"], unique = true),
        Index(value = ["company_name"])
    ]
)
data class CustomerEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "account_code") val accountCode: String,
    @ColumnInfo(name = "company_name") val companyName: String,
    @ColumnInfo(name = "contact_name") val contactName: String,
    val email: String,
    val phone: String,
    val tier: String,
    val city: String,
    val country: String,
    @ColumnInfo(name = "created_at") val createdAt: Long
)

@Entity(
    tableName = "employees",
    indices = [
        Index(value = ["employee_code"], unique = true),
        Index(value = ["email"], unique = true),
        Index(value = ["role"])
    ]
)
data class EmployeeEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "employee_code") val employeeCode: String,
    @ColumnInfo(name = "full_name") val fullName: String,
    val email: String,
    @ColumnInfo(name = "password_hash") val passwordHash: String,
    @ColumnInfo(name = "password_salt") val passwordSalt: String,
    val role: String,
    @ColumnInfo(name = "hub_location") val hubLocation: String,
    val active: Boolean,
    @ColumnInfo(name = "created_at") val createdAt: Long
)

@Entity(
    tableName = "shipments",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customer_id"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["tracking_number"], unique = true),
        Index(value = ["barcode_value"], unique = true),
        Index(value = ["customer_id"]),
        Index(value = ["status"]),
        Index(value = ["status", "sla_deadline_epoch"]),
        Index(value = ["assigned_employee_id"]),
        Index(value = ["created_at"])
    ]
)
data class ShipmentEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "tracking_number") val trackingNumber: String,
    @ColumnInfo(name = "barcode_value") val barcodeValue: String,
    @ColumnInfo(name = "qr_payload") val qrPayload: String,
    @ColumnInfo(name = "customer_id") val customerId: String,
    @ColumnInfo(name = "origin_hub") val originHub: String,
    @ColumnInfo(name = "destination_city") val destinationCity: String,
    @ColumnInfo(name = "destination_country") val destinationCountry: String,
    @ColumnInfo(name = "service_tier") val serviceTier: String,
    val status: String,
    @ColumnInfo(name = "total_weight_kg") val totalWeightKg: Double,
    @ColumnInfo(name = "declared_value_usd") val declaredValueUsd: Double,
    @ColumnInfo(name = "internal_notes") val internalNotes: String,
    @ColumnInfo(name = "assigned_employee_id") val assignedEmployeeId: String?,
    @ColumnInfo(name = "sla_deadline_epoch") val slaDeadlineEpoch: Long,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long
)

@Entity(
    tableName = "packages",
    foreignKeys = [
        ForeignKey(
            entity = ShipmentEntity::class,
            parentColumns = ["id"],
            childColumns = ["shipment_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["package_code"], unique = true),
        Index(value = ["barcode_value"], unique = true),
        Index(value = ["shipment_id"]),
        Index(value = ["warehouse_zone"]),
        Index(value = ["status"])
    ]
)
data class PackageEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "package_code") val packageCode: String,
    @ColumnInfo(name = "barcode_value") val barcodeValue: String,
    @ColumnInfo(name = "qr_payload") val qrPayload: String,
    @ColumnInfo(name = "shipment_id") val shipmentId: String,
    val sku: String,
    val description: String,
    @ColumnInfo(name = "weight_kg") val weightKg: Double,
    @ColumnInfo(name = "dimensions_cm") val dimensionsCm: String,
    @ColumnInfo(name = "warehouse_zone") val warehouseZone: String,
    @ColumnInfo(name = "bin_location") val binLocation: String,
    val status: String,
    val fragile: Boolean,
    @ColumnInfo(name = "created_at") val createdAt: Long
)

@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(
            entity = ShipmentEntity::class,
            parentColumns = ["id"],
            childColumns = ["shipment_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["assigned_to_id"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["shipment_id"]),
        Index(value = ["assigned_to_id"]),
        Index(value = ["status"])
    ]
)
data class TaskEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "shipment_id") val shipmentId: String,
    @ColumnInfo(name = "assigned_to_id") val assignedToId: String,
    @ColumnInfo(name = "assigned_by_id") val assignedById: String,
    val title: String,
    val instructions: String,
    val status: String,
    val priority: String,
    @ColumnInfo(name = "due_at") val dueAt: Long,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long
)

@Entity(
    tableName = "status_history",
    foreignKeys = [
        ForeignKey(
            entity = ShipmentEntity::class,
            parentColumns = ["id"],
            childColumns = ["shipment_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["shipment_id"]),
        Index(value = ["timestamp"])
    ]
)
data class StatusHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    @ColumnInfo(name = "shipment_id") val shipmentId: String,
    @ColumnInfo(name = "from_status") val fromStatus: String,
    @ColumnInfo(name = "to_status") val toStatus: String,
    @ColumnInfo(name = "actor_id") val actorId: String,
    @ColumnInfo(name = "actor_name") val actorName: String,
    @ColumnInfo(name = "actor_role") val actorRole: String,
    @ColumnInfo(name = "facility_location") val facilityLocation: String,
    @ColumnInfo(name = "public_location_label") val publicLocationLabel: String,
    val notes: String,
    val timestamp: Long
)

@Entity(
    tableName = "audit_logs",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["actor_id"]),
        Index(value = ["action"]),
        Index(value = ["outcome"])
    ]
)
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestamp: Long,
    @ColumnInfo(name = "actor_id") val actorId: String,
    @ColumnInfo(name = "actor_role") val actorRole: String,
    val action: String,
    @ColumnInfo(name = "entity_type") val entityType: String,
    @ColumnInfo(name = "entity_id") val entityId: String,
    val outcome: String,
    val details: String,
    @ColumnInfo(name = "prev_hash") val prevHash: String,
    @ColumnInfo(name = "entry_hash") val entryHash: String
)

// Query projection tuples
data class StatusCountTuple(
    val status: String,
    val count: Int
)

data class ZoneSummaryTuple(
    @ColumnInfo(name = "warehouse_zone") val warehouseZone: String,
    val packageCount: Int,
    val totalWeightKg: Double
)

data class StaffWorkloadTuple(
    val employeeId: String,
    val employeeName: String,
    val role: String,
    val hubLocation: String,
    val pendingTasks: Int,
    val inProgressTasks: Int,
    val completedTasks: Int
)

data class ShipmentSummaryRow(
    val id: String,
    @ColumnInfo(name = "tracking_number") val trackingNumber: String,
    @ColumnInfo(name = "barcode_value") val barcodeValue: String,
    @ColumnInfo(name = "qr_payload") val qrPayload: String,
    @ColumnInfo(name = "customer_id") val customerId: String,
    @ColumnInfo(name = "customer_name") val customerName: String,
    @ColumnInfo(name = "origin_hub") val originHub: String,
    @ColumnInfo(name = "destination_city") val destinationCity: String,
    @ColumnInfo(name = "destination_country") val destinationCountry: String,
    @ColumnInfo(name = "service_tier") val serviceTier: String,
    val status: String,
    @ColumnInfo(name = "total_weight_kg") val totalWeightKg: Double,
    @ColumnInfo(name = "declared_value_usd") val declaredValueUsd: Double,
    @ColumnInfo(name = "internal_notes") val internalNotes: String,
    @ColumnInfo(name = "sla_deadline_epoch") val slaDeadlineEpoch: Long,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
    val packageCount: Int
)

data class TaskDetailRow(
    val id: String,
    @ColumnInfo(name = "shipment_id") val shipmentId: String,
    @ColumnInfo(name = "tracking_number") val trackingNumber: String,
    @ColumnInfo(name = "assigned_to_id") val assignedToId: String,
    @ColumnInfo(name = "assignee_name") val assigneeName: String,
    @ColumnInfo(name = "assignee_role") val assigneeRole: String,
    val title: String,
    val instructions: String,
    val status: String,
    val priority: String,
    @ColumnInfo(name = "due_at") val dueAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long
)
