package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CustomerEntity::class,
        EmployeeEntity::class,
        ShipmentEntity::class,
        PackageEntity::class,
        TaskEntity::class,
        StatusHistoryEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CargoFlowDatabase : RoomDatabase() {

    abstract fun cargoFlowDao(): CargoFlowDao

    companion object {
        @Volatile
        private var INSTANCE: CargoFlowDatabase? = null

        fun getInstance(context: Context): CargoFlowDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CargoFlowDatabase::class.java,
                    "cargoflow_logistics.db"
                )
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
