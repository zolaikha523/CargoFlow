package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CargoFlowDao {

    // ---- Customers ----
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCustomer(customer: CustomerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(customers: List<CustomerEntity>)

    @Query("SELECT * FROM customers ORDER BY company_name ASC LIMIT :limit")
    fun observeCustomers(limit: Int = 200): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: String): CustomerEntity?

    @Query("SELECT COUNT(*) FROM customers")
    suspend fun countCustomers(): Int

    // ---- Employees ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployees(employees: List<EmployeeEntity>)

    @Query("SELECT * FROM employees WHERE active = 1 ORDER BY role ASC, full_name ASC")
    fun observeActiveEmployees(): Flow<List<EmployeeEntity>>

    @Query("SELECT * FROM employees WHERE LOWER(email) = LOWER(:email) AND active = 1 LIMIT 1")
    suspend fun findEmployeeByEmail(email: String): EmployeeEntity?

    @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
    suspend fun getEmployeeById(id: String): EmployeeEntity?

    @Query("SELECT COUNT(*) FROM employees WHERE active = 1")
    suspend fun countActiveEmployees(): Int

    @Query("UPDATE employees SET full_name = :fullName, hub_location = :hubLocation WHERE id = :id")
    suspend fun updateEmployeeProfile(id: String, fullName: String, hubLocation: String)

    @Query("UPDATE tasks SET assigned_to_id = :fallbackEmployeeId WHERE assigned_to_id LIKE 'emp-synth-%'")
    suspend fun reassignTasksFromSyntheticEmployees(fallbackEmployeeId: String)

    @Query("UPDATE shipments SET assigned_employee_id = :fallbackEmployeeId WHERE assigned_employee_id LIKE 'emp-synth-%'")
    suspend fun reassignShipmentsFromSyntheticEmployees(fallbackEmployeeId: String)

    @Query("DELETE FROM employees WHERE id LIKE 'emp-synth-%'")
    suspend fun deleteSyntheticEmployees()

    @Query("UPDATE customers SET contact_name = 'Logistics Coordinator' WHERE contact_name LIKE '%Patel%' OR contact_name LIKE '%Lindqvist%'")
    suspend fun sanitizeLegacyCustomerContacts()

    // ---- Shipments ----
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertShipment(shipment: ShipmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipments(shipments: List<ShipmentEntity>)

    @Update
    suspend fun updateShipment(shipment: ShipmentEntity)

    @Query("SELECT * FROM shipments WHERE id = :id LIMIT 1")
    suspend fun getShipmentById(id: String): ShipmentEntity?

    @Query("SELECT * FROM shipments WHERE tracking_number = :trackingNumber LIMIT 1")
    suspend fun getShipmentByTrackingNumber(trackingNumber: String): ShipmentEntity?

    @Query("SELECT * FROM shipments WHERE barcode_value = :code OR tracking_number = :code LIMIT 1")
    suspend fun getShipmentByCode(code: String): ShipmentEntity?

    @Query(
        """
        SELECT s.id, s.tracking_number, s.barcode_value, s.qr_payload,
               s.customer_id, c.company_name AS customer_name,
               s.origin_hub, s.destination_city, s.destination_country,
               s.service_tier, s.status, s.total_weight_kg, s.declared_value_usd,
               s.internal_notes, s.sla_deadline_epoch, s.created_at, s.updated_at,
               (SELECT COUNT(*) FROM packages p WHERE p.shipment_id = s.id) AS packageCount
        FROM shipments s
        INNER JOIN customers c ON c.id = s.customer_id
        WHERE (:statusFilter = '' OR s.status = :statusFilter)
          AND (:query = '' OR s.tracking_number LIKE '%' || :query || '%'
               OR s.destination_city LIKE '%' || :query || '%'
               OR c.company_name LIKE '%' || :query || '%')
        ORDER BY s.updated_at DESC
        LIMIT :limit OFFSET :offset
        """
    )
    fun observeShipmentsFiltered(
        statusFilter: String,
        query: String,
        limit: Int = 100,
        offset: Int = 0
    ): Flow<List<ShipmentSummaryRow>>

    @Query(
        """
        SELECT s.id, s.tracking_number, s.barcode_value, s.qr_payload,
               s.customer_id, c.company_name AS customer_name,
               s.origin_hub, s.destination_city, s.destination_country,
               s.service_tier, s.status, s.total_weight_kg, s.declared_value_usd,
               s.internal_notes, s.sla_deadline_epoch, s.created_at, s.updated_at,
               (SELECT COUNT(*) FROM packages p WHERE p.shipment_id = s.id) AS packageCount
        FROM shipments s
        INNER JOIN customers c ON c.id = s.customer_id
        WHERE (:statusFilter = '' OR s.status = :statusFilter)
          AND (:query = '' OR s.tracking_number LIKE '%' || :query || '%'
               OR s.destination_city LIKE '%' || :query || '%'
               OR c.company_name LIKE '%' || :query || '%')
        ORDER BY s.updated_at DESC
        LIMIT :limit OFFSET :offset
        """
    )
    suspend fun searchShipmentsPaginated(
        statusFilter: String,
        query: String,
        limit: Int,
        offset: Int
    ): List<ShipmentSummaryRow>

    @Query(
        """
        SELECT * FROM shipments
        WHERE status = 'DELAYED' OR (status NOT IN ('DELIVERED', 'CANCELLED') AND sla_deadline_epoch < :nowEpoch)
        ORDER BY sla_deadline_epoch ASC
        LIMIT :limit
        """
    )
    suspend fun getDelayedOrAtRiskShipments(nowEpoch: Long, limit: Int = 100): List<ShipmentEntity>

    @Query("SELECT status, COUNT(*) AS count FROM shipments GROUP BY status")
    suspend fun getShipmentStatusBreakdown(): List<StatusCountTuple>

    @Query("SELECT COUNT(*) FROM shipments WHERE status NOT IN ('DELIVERED', 'CANCELLED') AND sla_deadline_epoch < :nowEpoch")
    suspend fun countPendingSlaBreaches(nowEpoch: Long): Int

    @Query("SELECT COUNT(*) FROM shipments")
    suspend fun countShipments(): Int

    // ---- Packages / Inventory ----
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPackage(pkg: PackageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(packages: List<PackageEntity>)

    @Query("SELECT * FROM packages WHERE shipment_id = :shipmentId ORDER BY package_code ASC")
    fun observePackagesForShipment(shipmentId: String): Flow<List<PackageEntity>>

    @Query("SELECT * FROM packages WHERE shipment_id = :shipmentId ORDER BY package_code ASC")
    suspend fun getPackagesForShipment(shipmentId: String): List<PackageEntity>

    @Query("SELECT * FROM packages WHERE package_code = :code OR barcode_value = :code LIMIT 1")
    suspend fun getPackageByCode(code: String): PackageEntity?

    @Query(
        """
        SELECT * FROM packages
        WHERE (:zone = '' OR warehouse_zone = :zone)
          AND (:query = '' OR package_code LIKE '%' || :query || '%'
               OR sku LIKE '%' || :query || '%'
               OR description LIKE '%' || :query || '%')
        ORDER BY created_at DESC
        LIMIT :limit
        """
    )
    fun observeInventoryPackages(zone: String, query: String, limit: Int = 120): Flow<List<PackageEntity>>

    @Query("UPDATE packages SET status = :newStatus WHERE shipment_id = :shipmentId")
    suspend fun syncPackagesStatusForShipment(shipmentId: String, newStatus: String)

    @Query(
        """
        SELECT warehouse_zone, COUNT(*) AS packageCount, COALESCE(SUM(weight_kg), 0.0) AS totalWeightKg
        FROM packages
        GROUP BY warehouse_zone
        ORDER BY warehouse_zone ASC
        """
    )
    suspend fun getWarehouseZoneSummary(): List<ZoneSummaryTuple>

    @Query("SELECT COUNT(*) FROM packages")
    suspend fun countPackages(): Int

    @Query("SELECT COUNT(*) FROM packages WHERE status IN ('RECEIVED', 'WAREHOUSE', 'ON_HOLD')")
    suspend fun countWarehousePackages(): Int

    // ---- Tasks ----
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertTask(task: TaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<TaskEntity>)

    @Query("UPDATE tasks SET status = :status, updated_at = :updatedAt WHERE id = :taskId")
    suspend fun updateTaskStatus(taskId: String, status: String, updatedAt: Long)

    @Query("SELECT * FROM tasks WHERE id = :taskId LIMIT 1")
    suspend fun getTaskById(taskId: String): TaskEntity?

    @Query(
        """
        SELECT t.id, t.shipment_id, s.tracking_number, t.assigned_to_id,
               e.full_name AS assignee_name, e.role AS assignee_role,
               t.title, t.instructions, t.status, t.priority, t.due_at, t.updated_at
        FROM tasks t
        INNER JOIN shipments s ON s.id = t.shipment_id
        INNER JOIN employees e ON e.id = t.assigned_to_id
        ORDER BY CASE t.priority
            WHEN 'CRITICAL' THEN 0
            WHEN 'HIGH' THEN 1
            WHEN 'MEDIUM' THEN 2
            ELSE 3
        END, t.due_at ASC
        LIMIT :limit
        """
    )
    fun observeTaskDetails(limit: Int = 120): Flow<List<TaskDetailRow>>

    @Query(
        """
        SELECT t.id, t.shipment_id, s.tracking_number, t.assigned_to_id,
               e.full_name AS assignee_name, e.role AS assignee_role,
               t.title, t.instructions, t.status, t.priority, t.due_at, t.updated_at
        FROM tasks t
        INNER JOIN shipments s ON s.id = t.shipment_id
        INNER JOIN employees e ON e.id = t.assigned_to_id
        WHERE t.assigned_to_id = :assigneeId
        ORDER BY CASE t.priority
            WHEN 'CRITICAL' THEN 0
            WHEN 'HIGH' THEN 1
            WHEN 'MEDIUM' THEN 2
            ELSE 3
        END, t.due_at ASC
        LIMIT :limit
        """
    )
    fun observeTaskDetailsForAssignee(assigneeId: String, limit: Int = 120): Flow<List<TaskDetailRow>>

    @Query(
        """
        SELECT e.id AS employeeId, e.full_name AS employeeName, e.role AS role, e.hub_location AS hubLocation,
               SUM(CASE WHEN t.status = 'PENDING' THEN 1 ELSE 0 END) AS pendingTasks,
               SUM(CASE WHEN t.status = 'IN_PROGRESS' THEN 1 ELSE 0 END) AS inProgressTasks,
               SUM(CASE WHEN t.status = 'COMPLETED' THEN 1 ELSE 0 END) AS completedTasks
        FROM employees e
        LEFT JOIN tasks t ON t.assigned_to_id = e.id
        WHERE e.active = 1
        GROUP BY e.id
        ORDER BY (pendingTasks + inProgressTasks) DESC, e.full_name ASC
        LIMIT 25
        """
    )
    suspend fun getStaffWorkloadSummary(): List<StaffWorkloadTuple>

    @Query("SELECT COUNT(*) FROM tasks WHERE status IN ('PENDING', 'IN_PROGRESS', 'BLOCKED')")
    suspend fun countOpenTasks(): Int

    @Query("SELECT COUNT(*) FROM tasks")
    suspend fun countTasks(): Int

    // ---- Status History ----
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertStatusHistory(history: StatusHistoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStatusHistoryBatch(history: List<StatusHistoryEntity>)

    @Query("SELECT * FROM status_history WHERE shipment_id = :shipmentId ORDER BY timestamp DESC, id DESC")
    fun observeStatusHistory(shipmentId: String): Flow<List<StatusHistoryEntity>>

    @Query("SELECT * FROM status_history WHERE shipment_id = :shipmentId ORDER BY timestamp ASC, id ASC")
    suspend fun getStatusHistoryChronological(shipmentId: String): List<StatusHistoryEntity>

    @Query("SELECT COUNT(*) FROM status_history")
    suspend fun countStatusHistory(): Int

    @Query("UPDATE status_history SET actor_name = :actorName WHERE actor_id = :actorId")
    suspend fun updateStatusHistoryActorName(actorId: String, actorName: String)

    // ---- Audit Logs ----
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAuditLog(log: AuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLogs(logs: List<AuditLogEntity>)

    @Query("SELECT entry_hash FROM audit_logs ORDER BY id DESC LIMIT 1")
    suspend fun getLatestAuditHash(): String?

    @Query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT :limit")
    fun observeRecentAuditLogs(limit: Int = 150): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs ORDER BY id ASC")
    suspend fun getAllAuditLogsAsc(): List<AuditLogEntity>

    @Query("SELECT COUNT(*) FROM audit_logs")
    suspend fun countAuditLogs(): Int

    // ---- Total Records & Maintenance ----
    @Query(
        """
        SELECT (SELECT COUNT(*) FROM customers)
             + (SELECT COUNT(*) FROM employees)
             + (SELECT COUNT(*) FROM shipments)
             + (SELECT COUNT(*) FROM packages)
             + (SELECT COUNT(*) FROM tasks)
             + (SELECT COUNT(*) FROM status_history)
             + (SELECT COUNT(*) FROM audit_logs)
        """
    )
    suspend fun countTotalRecordsAcrossSystem(): Int
}
