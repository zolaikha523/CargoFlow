package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AuditLogEntity
import com.example.data.local.CargoFlowDatabase
import com.example.data.local.CustomerEntity
import com.example.data.local.EmployeeEntity
import com.example.data.local.PackageEntity
import com.example.data.local.ShipmentEntity
import com.example.data.local.ShipmentSummaryRow
import com.example.data.local.StatusHistoryEntity
import com.example.data.local.TaskDetailRow
import com.example.data.local.TaskEntity
import com.example.data.seed.SyntheticDataSeeder
import com.example.domain.AuditOutcome
import com.example.domain.BarcodeEngine
import com.example.domain.BenchmarkReport
import com.example.domain.CargoStateMachine
import com.example.domain.CargoStatus
import com.example.domain.CustomerTier
import com.example.domain.DashboardMetrics
import com.example.domain.DomainResult
import com.example.domain.ErrorCode
import com.example.domain.OperatorSession
import com.example.domain.Permission
import com.example.domain.PublicMilestone
import com.example.domain.PublicTrackingSnapshot
import com.example.domain.RbacPolicyEngine
import com.example.domain.SecurityHasher
import com.example.domain.ServiceTier
import com.example.domain.StaffWorkloadMetric
import com.example.domain.TaskPriority
import com.example.domain.TaskStatus
import com.example.domain.UserRole
import com.example.domain.ValidationEngine
import com.example.domain.WarehouseZoneMetric
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Unified Operations & Public Tracking Repository.
 * Enforces RBAC, strict FSM transitions, input validation, ACID SQLite transactions,
 * zero-leak public DTO redaction, and tamper-evident SHA-256 audit logging on every action.
 */
class CargoFlowRepository(private val db: CargoFlowDatabase) {

    private val dao = db.cargoFlowDao()

    suspend fun initializeIfEmpty() = withContext(Dispatchers.IO) {
        SyntheticDataSeeder.ensureInitialDataset(db)
    }

    // =========================================================================
    // 1. PUBLIC PORTAL API (UNAUTHENTICATED, STRICTLY REDACTED DTO)
    // =========================================================================

    suspend fun trackShipmentPublic(rawQuery: String): DomainResult<PublicTrackingSnapshot> =
        withContext(Dispatchers.IO) {
            val extracted = BarcodeEngine.extractCodeFromScannedPayload(rawQuery)
            val validated = ValidationEngine.validateTrackingQuery(extracted)
            if (validated is DomainResult.Failure) return@withContext validated

            val normalizedCode = (validated as DomainResult.Success).data
            val shipment = dao.getShipmentByCode(normalizedCode)
                ?: dao.getPackageByCode(normalizedCode)?.let { pkg -> dao.getShipmentById(pkg.shipmentId) }
                ?: return@withContext DomainResult.Failure(
                    ErrorCode.NOT_FOUND,
                    "No shipment found for tracking number '$normalizedCode'."
                )

            val packages = dao.getPackagesForShipment(shipment.id)
            val history = dao.getStatusHistoryChronological(shipment.id)
            val currentStatus = CargoStatus.fromNameSafe(shipment.status)
            val serviceTier = ServiceTier.fromNameSafe(shipment.serviceTier)

            // Redact origin hub name to region only; strip all internal notes, cost, PII, employee IDs, bin codes
            val sanitizedOrigin = shipment.originHub.substringBefore(" ") + " Logistics Corridor"
            val publicMilestones = history.map { event ->
                val state = CargoStatus.fromNameSafe(event.toStatus)
                PublicMilestone(
                    status = state,
                    publicLabel = state.publicCustomerLabel,
                    publicLocation = event.publicLocationLabel,
                    timestampEpochMs = event.timestamp
                )
            }

            DomainResult.Success(
                PublicTrackingSnapshot(
                    trackingNumber = shipment.trackingNumber,
                    serviceTierLabel = serviceTier.label,
                    currentStatus = currentStatus,
                    publicStatusLabel = currentStatus.publicCustomerLabel,
                    originRegion = sanitizedOrigin,
                    destinationCity = shipment.destinationCity,
                    destinationCountry = shipment.destinationCountry,
                    packageCount = packages.size.coerceAtLeast(1),
                    totalWeightKg = shipment.totalWeightKg,
                    estimatedDeliveryEpochMs = shipment.slaDeadlineEpoch,
                    lastUpdatedEpochMs = shipment.updatedAt,
                    milestones = publicMilestones
                )
            )
        }

    // =========================================================================
    // 2. OPERATOR AUTHENTICATION (SALTED SHA-256 VERIFICATION + AUDIT TRAIL)
    // =========================================================================

    suspend fun authenticateOperator(email: String, password: String): DomainResult<OperatorSession> =
        withContext(Dispatchers.IO) {
            val cleanEmail = email.trim().lowercase()
            val employee = dao.findEmployeeByEmail(cleanEmail)
            if (employee == null || !SecurityHasher.verifyPassword(password, employee.passwordSalt, employee.passwordHash)) {
                appendAuditLog(
                    actorId = cleanEmail.ifBlank { "anonymous" },
                    actorRole = "UNAUTHENTICATED",
                    action = "OPERATOR_LOGIN",
                    entityType = "SESSION",
                    entityId = cleanEmail,
                    outcome = AuditOutcome.DENIED,
                    details = "Invalid credentials or inactive operator account."
                )
                return@withContext DomainResult.Failure(
                    ErrorCode.UNAUTHORIZED,
                    "Invalid operator email or password."
                )
            }

            val role = UserRole.fromNameSafe(employee.role)
            val session = OperatorSession(
                employeeId = employee.id,
                employeeCode = employee.employeeCode,
                fullName = employee.fullName,
                email = employee.email,
                role = role,
                hubLocation = employee.hubLocation,
                sessionToken = SecurityHasher.generateSessionToken(employee.id, role),
                authenticatedAtEpochMs = System.currentTimeMillis()
            )
            appendAuditLog(
                actorId = employee.id,
                actorRole = role.name,
                action = "OPERATOR_LOGIN",
                entityType = "SESSION",
                entityId = employee.employeeCode,
                outcome = AuditOutcome.ALLOWED,
                details = "Authenticated ${employee.fullName} (${role.displayName}) at ${employee.hubLocation}."
            )
            DomainResult.Success(session)
        }

    suspend fun recordSignOut(session: OperatorSession) = withContext(Dispatchers.IO) {
        appendAuditLog(
            actorId = session.employeeId,
            actorRole = session.role.name,
            action = "OPERATOR_LOGOUT",
            entityType = "SESSION",
            entityId = session.employeeCode,
            outcome = AuditOutcome.ALLOWED,
            details = "Operator session terminated cleanly."
        )
    }

    suspend fun recordManifestPdfExport(
        session: OperatorSession?,
        manifestNumber: String,
        itemCount: Int,
        totalWeightKg: Double,
        recipientEmail: String
    ) = withContext(Dispatchers.IO) {
        val recipientPart = if (recipientEmail.isNotBlank()) " for recipient ${recipientEmail.trim()}" else ""
        appendAuditLog(
            actorId = session?.employeeId ?: "ops_scanner",
            actorRole = session?.role?.name ?: "OPERATOR",
            action = "EXPORT_MANIFEST_PDF",
            entityType = "MANIFEST",
            entityId = manifestNumber,
            outcome = AuditOutcome.ALLOWED,
            details = "Generated digital manifest PDF ($itemCount scanned items, ${String.format(java.util.Locale.US, "%.1f", totalWeightKg)} kg)$recipientPart."
        )
    }

    // =========================================================================
    // 3. DASHBOARD METRICS & 10,000+ BENCHMARK EVALUATOR
    // =========================================================================

    suspend fun loadDashboardMetrics(session: OperatorSession?): DomainResult<DashboardMetrics> =
        withContext(Dispatchers.IO) {
            val auth = RbacPolicyEngine.requireAuthorized(session, Permission.VIEW_OPERATIONS_DASHBOARD)
            if (auth is DomainResult.Failure) return@withContext auth

            val now = System.currentTimeMillis()
            val breakdownRaw = dao.getShipmentStatusBreakdown()
            val breakdownMap = breakdownRaw.associate { CargoStatus.fromNameSafe(it.status) to it.count }
            val totalShipments = breakdownMap.values.sum()
            val delivered = breakdownMap[CargoStatus.DELIVERED] ?: 0
            val cancelled = breakdownMap[CargoStatus.CANCELLED] ?: 0
            val delayed = breakdownMap[CargoStatus.DELAYED] ?: 0
            val onHold = breakdownMap[CargoStatus.ON_HOLD] ?: 0
            val active = (totalShipments - delivered - cancelled).coerceAtLeast(0)

            val zoneCapacities = mapOf(
                "ZONE-A" to 1200,
                "ZONE-B" to 1200,
                "ZONE-C" to 1000,
                "ZONE-COLD" to 800,
                "ZONE-HAZMAT" to 600,
                "ZONE-EXPRESS" to 900
            )
            val operator = (auth as DomainResult.Success).data
            val canViewInventory = RbacPolicyEngine.hasPermission(operator.role, Permission.VIEW_INVENTORY)
            val zones = if (canViewInventory) {
                dao.getWarehouseZoneSummary().map {
                    WarehouseZoneMetric(
                        zone = it.warehouseZone,
                        packageCount = it.packageCount,
                        totalWeightKg = it.totalWeightKg,
                        capacityLimit = zoneCapacities[it.warehouseZone] ?: 1000
                    )
                }
            } else {
                emptyList()
            }
            val staff = dao.getStaffWorkloadSummary().map {
                StaffWorkloadMetric(
                    employeeId = it.employeeId,
                    employeeName = it.employeeName,
                    role = UserRole.fromNameSafe(it.role),
                    hubLocation = it.hubLocation,
                    pendingTasks = it.pendingTasks,
                    inProgressTasks = it.inProgressTasks,
                    completedTasks = it.completedTasks
                )
            }

            DomainResult.Success(
                DashboardMetrics(
                    totalShipments = totalShipments,
                    activeShipments = active,
                    deliveredShipments = delivered,
                    delayedShipments = delayed,
                    pendingSlaBreachCount = dao.countPendingSlaBreaches(now),
                    onHoldShipments = onHold,
                    totalPackages = dao.countPackages(),
                    warehousePackages = dao.countWarehousePackages(),
                    totalCustomers = dao.countCustomers(),
                    activeEmployees = dao.countActiveEmployees(),
                    openTasks = dao.countOpenTasks(),
                    totalRecordsAcrossTables = dao.countTotalRecordsAcrossSystem(),
                    statusBreakdown = breakdownMap,
                    warehouseZones = zones,
                    staffWorkload = staff
                )
            )
        }

    suspend fun runLargeScaleSeedAndBenchmark(session: OperatorSession?): DomainResult<BenchmarkReport> =
        withContext(Dispatchers.IO) {
            val auth = RbacPolicyEngine.requireAuthorized(session, Permission.RUN_SEED_AND_BENCHMARK)
            if (auth is DomainResult.Failure) {
                logDenied(session, "RUN_BENCHMARK", "SYSTEM", "cargoflow-db", auth.message)
                return@withContext auth
            }
            val operator = (auth as DomainResult.Success).data
            val report = SyntheticDataSeeder.seedTenThousandAndBenchmark(db)
            appendAuditLog(
                actorId = operator.employeeId,
                actorRole = operator.role.name,
                action = "RUN_BENCHMARK",
                entityType = "SYSTEM",
                entityId = "10k-benchmark",
                outcome = AuditOutcome.ALLOWED,
                details = "Evaluated ${report.totalSeededRecords} records (seed=${report.seedDurationMs}ms, track=${report.indexedTrackingLookupMs}ms, dash=${report.dashboardAggregationMs}ms)."
            )
            DomainResult.Success(report)
        }

    // =========================================================================
    // 4. SHIPMENTS & CONTROLLED LIFECYCLE STATE TRANSITIONS
    // =========================================================================

    fun observeShipments(statusFilter: CargoStatus?, query: String): Flow<List<ShipmentSummaryRow>> =
        dao.observeShipmentsFiltered(
            statusFilter = statusFilter?.name ?: "",
            query = query.trim(),
            limit = 100
        )

    fun observeStatusHistory(shipmentId: String): Flow<List<StatusHistoryEntity>> =
        dao.observeStatusHistory(shipmentId)

    fun observePackagesForShipment(shipmentId: String): Flow<List<PackageEntity>> =
        dao.observePackagesForShipment(shipmentId)

    suspend fun getShipmentById(shipmentId: String): ShipmentEntity? =
        withContext(Dispatchers.IO) { dao.getShipmentById(shipmentId) }

    suspend fun lookupByScannedCode(code: String): Pair<ShipmentEntity?, PackageEntity?> =
        withContext(Dispatchers.IO) {
            val normalized = BarcodeEngine.extractCodeFromScannedPayload(code)
            val directShipment = dao.getShipmentByCode(normalized)
            if (directShipment != null) return@withContext directShipment to null
            val pkg = dao.getPackageByCode(normalized)
            if (pkg != null) {
                return@withContext dao.getShipmentById(pkg.shipmentId) to pkg
            }
            null to null
        }

    suspend fun lookupByScannedCodeForSession(
        session: OperatorSession?,
        code: String
    ): DomainResult<Pair<ShipmentEntity?, PackageEntity?>> = withContext(Dispatchers.IO) {
        val auth = RbacPolicyEngine.requireAuthorized(session, Permission.USE_SCANNER)
        if (auth is DomainResult.Failure) {
            logDenied(session, "SCAN_BARCODE", "SCANNER", code.take(40), auth.message)
            return@withContext auth
        }
        DomainResult.Success(lookupByScannedCode(code))
    }

    suspend fun createShipment(
        session: OperatorSession?,
        customerId: String,
        originHub: String,
        destinationCity: String,
        destinationCountry: String,
        serviceTier: ServiceTier,
        weightKg: Double,
        declaredValueUsd: Double,
        internalNotes: String,
        initialPackageDescription: String,
        initialWarehouseZone: String
    ): DomainResult<ShipmentEntity> = withContext(Dispatchers.IO) {
        val auth = RbacPolicyEngine.requireAuthorized(session, Permission.CREATE_SHIPMENT)
        if (auth is DomainResult.Failure) {
            logDenied(session, "CREATE_SHIPMENT", "SHIPMENT", customerId, auth.message)
            return@withContext auth
        }
        val operator = (auth as DomainResult.Success).data

        val validation = ValidationEngine.validateShipmentInput(
            customerId, originHub, destinationCity, destinationCountry, weightKg, declaredValueUsd
        )
        if (validation is DomainResult.Failure) {
            appendAuditLog(
                operator.employeeId, operator.role.name, "CREATE_SHIPMENT", "SHIPMENT", "new",
                AuditOutcome.VALIDATION_FAILED, validation.message
            )
            return@withContext validation
        }

        val customer = dao.getCustomerById(customerId)
            ?: return@withContext DomainResult.Failure(ErrorCode.NOT_FOUND, "Selected customer account does not exist.")

        val now = System.currentTimeMillis()
        val seq = dao.countShipments().toLong() + 10_001L + (now % 997L)
        val tracking = BarcodeEngine.generateTrackingNumber(seq, 2026)
        val shipmentId = "shp-${UUID.randomUUID().toString().take(8)}"
        val cleanHub = ValidationEngine.sanitizeText(originHub, 80)
        val cleanCity = ValidationEngine.sanitizeText(destinationCity, 60)
        val cleanCountry = ValidationEngine.sanitizeText(destinationCountry, 60)
        val cleanNotes = ValidationEngine.sanitizeText(internalNotes, 240)

        val shipment = ShipmentEntity(
            id = shipmentId,
            trackingNumber = tracking,
            barcodeValue = tracking,
            qrPayload = BarcodeEngine.buildShipmentQrPayload(tracking, cleanHub, cleanCity),
            customerId = customer.id,
            originHub = cleanHub,
            destinationCity = cleanCity,
            destinationCountry = cleanCountry,
            serviceTier = serviceTier.name,
            status = CargoStatus.CREATED.name,
            totalWeightKg = weightKg,
            declaredValueUsd = declaredValueUsd,
            internalNotes = cleanNotes,
            assignedEmployeeId = operator.employeeId,
            slaDeadlineEpoch = now + serviceTier.slaHours * 3_600_000L,
            createdAt = now,
            updatedAt = now
        )

        val pkgCode = BarcodeEngine.generatePackageCode(tracking, 1)
        val zone = initialWarehouseZone.ifBlank { "ZONE-A" }
        val initialPkg = PackageEntity(
            id = "pkg-${UUID.randomUUID().toString().take(8)}",
            packageCode = pkgCode,
            barcodeValue = pkgCode,
            qrPayload = BarcodeEngine.buildPackageQrPayload(pkgCode, tracking, zone),
            shipmentId = shipmentId,
            sku = "SKU-${(10000 + (seq % 89999))}",
            description = ValidationEngine.sanitizeText(initialPackageDescription.ifBlank { "General Freight Unit" }, 120),
            weightKg = weightKg,
            dimensionsCm = "45x35x30",
            warehouseZone = zone,
            binLocation = "${zone.removePrefix("ZONE-")}-R1-B1",
            status = CargoStatus.CREATED.name,
            fragile = false,
            createdAt = now
        )

        db.withTransaction {
            dao.insertShipment(shipment)
            dao.insertPackage(initialPkg)
            dao.insertStatusHistory(
                StatusHistoryEntity(
                    shipmentId = shipmentId,
                    fromStatus = CargoStatus.CREATED.name,
                    toStatus = CargoStatus.CREATED.name,
                    actorId = operator.employeeId,
                    actorName = operator.fullName,
                    actorRole = operator.role.name,
                    facilityLocation = cleanHub,
                    publicLocationLabel = cleanHub.substringBefore(" ") + " Hub",
                    notes = "Shipment registered for ${customer.companyName}",
                    timestamp = now
                )
            )
            appendAuditLogInternal(
                actorId = operator.employeeId,
                actorRole = operator.role.name,
                action = "CREATE_SHIPMENT",
                entityType = "SHIPMENT",
                entityId = tracking,
                outcome = AuditOutcome.ALLOWED,
                details = "Created shipment $tracking (${serviceTier.label}, ${weightKg}kg) -> $cleanCity, $cleanCountry"
            )
        }
        DomainResult.Success(shipment)
    }

    suspend fun transitionShipmentStatus(
        session: OperatorSession?,
        shipmentId: String,
        targetStatus: CargoStatus,
        facilityLocation: String,
        notes: String
    ): DomainResult<ShipmentEntity> = withContext(Dispatchers.IO) {
        if (session == null || session.sessionToken.isBlank()) {
            logDenied(null, "TRANSITION_STATUS", "SHIPMENT", shipmentId, "Unauthenticated transition attempt.")
            return@withContext DomainResult.Failure(ErrorCode.UNAUTHORIZED, "Operator authentication required.")
        }

        val current = dao.getShipmentById(shipmentId)
            ?: return@withContext DomainResult.Failure(ErrorCode.NOT_FOUND, "Shipment '$shipmentId' not found.")

        val currentStatus = CargoStatus.fromNameSafe(current.status)
        val check = CargoStateMachine.validateTransition(currentStatus, targetStatus, session.role)
        if (check is DomainResult.Failure) {
            appendAuditLog(
                actorId = session.employeeId,
                actorRole = session.role.name,
                action = "TRANSITION_STATUS",
                entityType = "SHIPMENT",
                entityId = current.trackingNumber,
                outcome = AuditOutcome.DENIED,
                details = "Blocked ${currentStatus.name} -> ${targetStatus.name}: ${check.message}"
            )
            return@withContext check
        }

        val now = System.currentTimeMillis()
        val cleanFacility = ValidationEngine.sanitizeText(facilityLocation.ifBlank { session.hubLocation }, 90)
        val cleanNotes = ValidationEngine.sanitizeText(notes.ifBlank { "Status advanced to ${targetStatus.displayLabel}" }, 220)
        val publicLoc = if (targetStatus == CargoStatus.DELIVERED || targetStatus == CargoStatus.OUT_FOR_DELIVERY) {
            "${current.destinationCity}, ${current.destinationCountry}"
        } else {
            cleanFacility.substringBefore(" ") + " Hub"
        }

        val updated = current.copy(
            status = targetStatus.name,
            updatedAt = now
        )

        db.withTransaction {
            dao.updateShipment(updated)
            dao.syncPackagesStatusForShipment(current.id, targetStatus.name)
            dao.insertStatusHistory(
                StatusHistoryEntity(
                    shipmentId = current.id,
                    fromStatus = currentStatus.name,
                    toStatus = targetStatus.name,
                    actorId = session.employeeId,
                    actorName = session.fullName,
                    actorRole = session.role.name,
                    facilityLocation = cleanFacility,
                    publicLocationLabel = publicLoc,
                    notes = cleanNotes,
                    timestamp = now
                )
            )
            appendAuditLogInternal(
                actorId = session.employeeId,
                actorRole = session.role.name,
                action = "TRANSITION_STATUS",
                entityType = "SHIPMENT",
                entityId = current.trackingNumber,
                outcome = AuditOutcome.ALLOWED,
                details = "Transitioned ${current.trackingNumber}: ${currentStatus.name} -> ${targetStatus.name} at $cleanFacility"
            )
        }

        DomainResult.Success(updated)
    }

    // =========================================================================
    // 5. PACKAGES / WAREHOUSE INVENTORY
    // =========================================================================

    fun observeInventory(zone: String, query: String): Flow<List<PackageEntity>> =
        dao.observeInventoryPackages(zone = zone, query = query.trim(), limit = 120)

    fun observeInventoryForSession(
        session: OperatorSession?,
        zone: String,
        query: String
    ): Flow<List<PackageEntity>> {
        if (session == null || !RbacPolicyEngine.hasPermission(session.role, Permission.VIEW_INVENTORY)) {
            return flowOf(emptyList())
        }
        return dao.observeInventoryPackages(zone = zone, query = query.trim(), limit = 120)
    }

    suspend fun addPackageToShipment(
        session: OperatorSession?,
        shipmentId: String,
        sku: String,
        description: String,
        weightKg: Double,
        dimensionsCm: String,
        warehouseZone: String,
        binLocation: String,
        fragile: Boolean
    ): DomainResult<PackageEntity> = withContext(Dispatchers.IO) {
        val auth = RbacPolicyEngine.requireAuthorized(session, Permission.MANAGE_PACKAGES_INVENTORY)
        if (auth is DomainResult.Failure) {
            logDenied(session, "ADD_PACKAGE", "PACKAGE", shipmentId, auth.message)
            return@withContext auth
        }
        val operator = (auth as DomainResult.Success).data

        val validation = ValidationEngine.validatePackageInput(
            shipmentId, sku, description, weightKg, warehouseZone, binLocation
        )
        if (validation is DomainResult.Failure) return@withContext validation

        val shipment = dao.getShipmentById(shipmentId)
            ?: return@withContext DomainResult.Failure(ErrorCode.NOT_FOUND, "Parent shipment not found.")

        val existingCount = dao.getPackagesForShipment(shipmentId).size
        val pkgCode = BarcodeEngine.generatePackageCode(shipment.trackingNumber, existingCount + 1)
        val cleanZone = warehouseZone.trim().uppercase()
        val now = System.currentTimeMillis()
        val pkg = PackageEntity(
            id = "pkg-${UUID.randomUUID().toString().take(8)}",
            packageCode = pkgCode,
            barcodeValue = pkgCode,
            qrPayload = BarcodeEngine.buildPackageQrPayload(pkgCode, shipment.trackingNumber, cleanZone),
            shipmentId = shipmentId,
            sku = ValidationEngine.sanitizeText(sku.uppercase(), 40),
            description = ValidationEngine.sanitizeText(description, 120),
            weightKg = weightKg,
            dimensionsCm = ValidationEngine.sanitizeText(dimensionsCm.ifBlank { "40x30x25" }, 30),
            warehouseZone = cleanZone,
            binLocation = ValidationEngine.sanitizeText(binLocation.uppercase(), 30),
            status = shipment.status,
            fragile = fragile,
            createdAt = now
        )

        db.withTransaction {
            dao.insertPackage(pkg)
            dao.updateShipment(
                shipment.copy(
                    totalWeightKg = shipment.totalWeightKg + weightKg,
                    updatedAt = now
                )
            )
            appendAuditLogInternal(
                actorId = operator.employeeId,
                actorRole = operator.role.name,
                action = "ADD_PACKAGE",
                entityType = "PACKAGE",
                entityId = pkgCode,
                outcome = AuditOutcome.ALLOWED,
                details = "Added package $pkgCode (${pkg.sku}, ${weightKg}kg) to ${shipment.trackingNumber} in $cleanZone/${pkg.binLocation}"
            )
        }
        DomainResult.Success(pkg)
    }

    // =========================================================================
    // 6. CUSTOMERS, EMPLOYEES & TASK ASSIGNMENTS
    // =========================================================================

    fun observeCustomers(): Flow<List<CustomerEntity>> = dao.observeCustomers(200)

    fun observeCustomersForSession(session: OperatorSession?): Flow<List<CustomerEntity>> {
        if (session == null || !RbacPolicyEngine.hasPermission(session.role, Permission.VIEW_CUSTOMERS)) {
            return flowOf(emptyList())
        }
        return dao.observeCustomers(200)
    }

    fun observeEmployees(): Flow<List<EmployeeEntity>> = dao.observeActiveEmployees()

    fun observeEmployeesForSession(session: OperatorSession?): Flow<List<EmployeeEntity>> {
        if (session == null || !RbacPolicyEngine.hasPermission(session.role, Permission.VIEW_EMPLOYEES)) {
            return flowOf(emptyList())
        }
        return dao.observeActiveEmployees()
    }

    fun observeTasks(): Flow<List<TaskDetailRow>> = dao.observeTaskDetails(150)

    fun observeTasksForSession(session: OperatorSession?): Flow<List<TaskDetailRow>> {
        if (session == null) return flowOf(emptyList())
        return when {
            RbacPolicyEngine.hasPermission(session.role, Permission.ASSIGN_TASKS) ->
                dao.observeTaskDetails(150)
            RbacPolicyEngine.hasPermission(session.role, Permission.UPDATE_OWN_TASKS) ->
                dao.observeTaskDetailsForAssignee(session.employeeId, 150)
            else -> flowOf(emptyList())
        }
    }

    fun observeAuditLogs(): Flow<List<AuditLogEntity>> = dao.observeRecentAuditLogs(150)

    fun observeAuditLogsForSession(session: OperatorSession?): Flow<List<AuditLogEntity>> {
        if (session == null || !RbacPolicyEngine.hasPermission(session.role, Permission.VIEW_AUDIT_LOGS)) {
            return flowOf(emptyList())
        }
        return dao.observeRecentAuditLogs(150)
    }

    suspend fun createCustomer(
        session: OperatorSession?,
        companyName: String,
        contactName: String,
        email: String,
        phone: String,
        tier: CustomerTier,
        city: String,
        country: String
    ): DomainResult<CustomerEntity> = withContext(Dispatchers.IO) {
        val auth = RbacPolicyEngine.requireAuthorized(session, Permission.MANAGE_CUSTOMERS)
        if (auth is DomainResult.Failure) {
            logDenied(session, "CREATE_CUSTOMER", "CUSTOMER", companyName, auth.message)
            return@withContext auth
        }
        val operator = (auth as DomainResult.Success).data

        val validation = ValidationEngine.validateCustomerInput(
            companyName, contactName, email, phone, city, country
        )
        if (validation is DomainResult.Failure) return@withContext validation

        val now = System.currentTimeMillis()
        val num = dao.countCustomers() + 10_001
        val customer = CustomerEntity(
            id = "cust-${UUID.randomUUID().toString().take(8)}",
            accountCode = "ACC-$num",
            companyName = ValidationEngine.sanitizeText(companyName, 100),
            contactName = ValidationEngine.sanitizeText(contactName, 80),
            email = email.trim().lowercase(),
            phone = ValidationEngine.sanitizeText(phone, 30),
            tier = tier.name,
            city = ValidationEngine.sanitizeText(city, 60),
            country = ValidationEngine.sanitizeText(country, 60),
            createdAt = now
        )
        db.withTransaction {
            dao.insertCustomer(customer)
            appendAuditLogInternal(
                actorId = operator.employeeId,
                actorRole = operator.role.name,
                action = "CREATE_CUSTOMER",
                entityType = "CUSTOMER",
                entityId = customer.accountCode,
                outcome = AuditOutcome.ALLOWED,
                details = "Registered corporate customer ${customer.companyName} (${tier.label})"
            )
        }
        DomainResult.Success(customer)
    }

    suspend fun assignTask(
        session: OperatorSession?,
        shipmentId: String,
        assigneeId: String,
        title: String,
        instructions: String,
        priority: TaskPriority
    ): DomainResult<TaskEntity> = withContext(Dispatchers.IO) {
        val auth = RbacPolicyEngine.requireAuthorized(session, Permission.ASSIGN_TASKS)
        if (auth is DomainResult.Failure) {
            logDenied(session, "ASSIGN_TASK", "TASK", shipmentId, auth.message)
            return@withContext auth
        }
        val operator = (auth as DomainResult.Success).data

        val validation = ValidationEngine.validateTaskInput(shipmentId, assigneeId, title)
        if (validation is DomainResult.Failure) return@withContext validation

        val shipment = dao.getShipmentById(shipmentId)
            ?: return@withContext DomainResult.Failure(ErrorCode.NOT_FOUND, "Referenced shipment not found.")
        val assignee = dao.getEmployeeById(assigneeId)
            ?: return@withContext DomainResult.Failure(ErrorCode.NOT_FOUND, "Selected employee not found.")

        val now = System.currentTimeMillis()
        val task = TaskEntity(
            id = "tsk-${UUID.randomUUID().toString().take(8)}",
            shipmentId = shipment.id,
            assignedToId = assignee.id,
            assignedById = operator.employeeId,
            title = ValidationEngine.sanitizeText(title, 100),
            instructions = ValidationEngine.sanitizeText(instructions.ifBlank { "Complete SOP for ${shipment.trackingNumber}" }, 220),
            status = TaskStatus.PENDING.name,
            priority = priority.name,
            dueAt = now + 24L * 3_600_000L,
            createdAt = now,
            updatedAt = now
        )

        db.withTransaction {
            dao.insertTask(task)
            appendAuditLogInternal(
                actorId = operator.employeeId,
                actorRole = operator.role.name,
                action = "ASSIGN_TASK",
                entityType = "TASK",
                entityId = task.id,
                outcome = AuditOutcome.ALLOWED,
                details = "Assigned '${task.title}' (${priority.label}) for ${shipment.trackingNumber} to ${assignee.fullName}"
            )
        }
        DomainResult.Success(task)
    }

    suspend fun updateTaskStatus(
        session: OperatorSession?,
        taskId: String,
        newStatus: TaskStatus
    ): DomainResult<Unit> = withContext(Dispatchers.IO) {
        val auth = RbacPolicyEngine.requireAuthorized(session, Permission.UPDATE_OWN_TASKS)
        if (auth is DomainResult.Failure) {
            logDenied(session, "UPDATE_TASK", "TASK", taskId, auth.message)
            return@withContext auth
        }
        val operator = (auth as DomainResult.Success).data

        val existing = dao.getTaskById(taskId)
            ?: return@withContext DomainResult.Failure(ErrorCode.NOT_FOUND, "Task not found.")

        val canManageAny = RbacPolicyEngine.hasPermission(operator.role, Permission.ASSIGN_TASKS)
        if (!canManageAny && existing.assignedToId != operator.employeeId) {
            val msg = "RBAC Policy Denied: ${operator.role.displayName} can only update tasks assigned to themselves."
            logDenied(operator, "UPDATE_TASK", "TASK", taskId, msg)
            return@withContext DomainResult.Failure(ErrorCode.PERMISSION_DENIED, msg)
        }

        val now = System.currentTimeMillis()
        db.withTransaction {
            dao.updateTaskStatus(taskId, newStatus.name, now)
            appendAuditLogInternal(
                actorId = operator.employeeId,
                actorRole = operator.role.name,
                action = "UPDATE_TASK",
                entityType = "TASK",
                entityId = taskId,
                outcome = AuditOutcome.ALLOWED,
                details = "Updated task '${existing.title}' status to ${newStatus.label}"
            )
        }
        DomainResult.Success(Unit)
    }

    // =========================================================================
    // 7. TAMPER-EVIDENT AUDIT LOGGING & INTEGRITY VERIFICATION
    // =========================================================================

    suspend fun verifyAuditChainIntegrityForSession(session: OperatorSession?): DomainResult<Boolean> =
        withContext(Dispatchers.IO) {
            val auth = RbacPolicyEngine.requireAuthorized(session, Permission.VIEW_AUDIT_LOGS)
            if (auth is DomainResult.Failure) {
                logDenied(session, "VERIFY_AUDIT_CHAIN", "AUDIT_LOG", "chain", auth.message)
                return@withContext auth
            }
            DomainResult.Success(verifyAuditChainIntegrity())
        }

    suspend fun verifyAuditChainIntegrity(): Boolean = withContext(Dispatchers.IO) {
        val logs = dao.getAllAuditLogsAsc()
        var expectedPrev = SecurityHasher.GENESIS_HASH
        for (log in logs) {
            if (log.prevHash != expectedPrev) return@withContext false
            val recomputed = SecurityHasher.computeAuditHash(
                prevHash = log.prevHash,
                timestamp = log.timestamp,
                actorId = log.actorId,
                actorRole = log.actorRole,
                action = log.action,
                entityType = log.entityType,
                entityId = log.entityId,
                outcome = log.outcome,
                details = log.details
            )
            if (recomputed != log.entryHash) return@withContext false
            expectedPrev = log.entryHash
        }
        true
    }

    private suspend fun logDenied(
        session: OperatorSession?,
        action: String,
        entityType: String,
        entityId: String,
        details: String
    ) {
        appendAuditLog(
            actorId = session?.employeeId ?: "unauthenticated",
            actorRole = session?.role?.name ?: "PUBLIC",
            action = action,
            entityType = entityType,
            entityId = entityId,
            outcome = AuditOutcome.DENIED,
            details = details
        )
    }

    private suspend fun appendAuditLog(
        actorId: String,
        actorRole: String,
        action: String,
        entityType: String,
        entityId: String,
        outcome: AuditOutcome,
        details: String
    ) {
        db.withTransaction {
            appendAuditLogInternal(actorId, actorRole, action, entityType, entityId, outcome, details)
        }
    }

    private suspend fun appendAuditLogInternal(
        actorId: String,
        actorRole: String,
        action: String,
        entityType: String,
        entityId: String,
        outcome: AuditOutcome,
        details: String
    ) {
        val now = System.currentTimeMillis()
        val prevHash = dao.getLatestAuditHash() ?: SecurityHasher.GENESIS_HASH
        val entryHash = SecurityHasher.computeAuditHash(
            prevHash = prevHash,
            timestamp = now,
            actorId = actorId,
            actorRole = actorRole,
            action = action,
            entityType = entityType,
            entityId = entityId,
            outcome = outcome.name,
            details = details
        )
        dao.insertAuditLog(
            AuditLogEntity(
                timestamp = now,
                actorId = actorId,
                actorRole = actorRole,
                action = action,
                entityType = entityType,
                entityId = entityId,
                outcome = outcome.name,
                details = details,
                prevHash = prevHash,
                entryHash = entryHash
            )
        )
    }
}
