package com.example.domain

/**
 * Enforces the strict CargoFlow Finite State Machine (FSM) and role-level transition gates.
 * Invalid transitions are rejected deterministically before any persistence write occurs.
 */
object CargoStateMachine {

    private val allowedTransitions: Map<CargoStatus, Set<CargoStatus>> = mapOf(
        CargoStatus.CREATED to setOf(CargoStatus.RECEIVED, CargoStatus.CANCELLED),
        CargoStatus.RECEIVED to setOf(CargoStatus.WAREHOUSE, CargoStatus.ON_HOLD, CargoStatus.CANCELLED),
        CargoStatus.WAREHOUSE to setOf(CargoStatus.DISPATCHED, CargoStatus.ON_HOLD, CargoStatus.RETURNED),
        CargoStatus.ON_HOLD to setOf(
            CargoStatus.WAREHOUSE,
            CargoStatus.DISPATCHED,
            CargoStatus.RETURNED,
            CargoStatus.CANCELLED
        ),
        CargoStatus.DISPATCHED to setOf(CargoStatus.IN_TRANSIT, CargoStatus.DELAYED, CargoStatus.RETURNED),
        CargoStatus.IN_TRANSIT to setOf(
            CargoStatus.OUT_FOR_DELIVERY,
            CargoStatus.DELAYED,
            CargoStatus.DELIVERED,
            CargoStatus.RETURNED
        ),
        CargoStatus.DELAYED to setOf(
            CargoStatus.IN_TRANSIT,
            CargoStatus.OUT_FOR_DELIVERY,
            CargoStatus.RETURNED
        ),
        CargoStatus.OUT_FOR_DELIVERY to setOf(
            CargoStatus.DELIVERED,
            CargoStatus.DELAYED,
            CargoStatus.RETURNED
        ),
        CargoStatus.RETURNED to setOf(CargoStatus.WAREHOUSE),
        CargoStatus.DELIVERED to emptySet(),
        CargoStatus.CANCELLED to emptySet()
    )

    fun isGraphTransitionValid(from: CargoStatus, to: CargoStatus): Boolean {
        if (from == to) return false
        return allowedTransitions[from]?.contains(to) == true
    }

    fun requiredPermissionForTransition(from: CargoStatus, to: CargoStatus): Permission {
        return when (to) {
            CargoStatus.RECEIVED, CargoStatus.WAREHOUSE -> Permission.TRANSITION_WAREHOUSE_STATES
            CargoStatus.DISPATCHED -> {
                if (from == CargoStatus.ON_HOLD) Permission.TRANSITION_HOLD_CANCEL_RETURN
                else Permission.TRANSITION_DISPATCH_STATES
            }
            CargoStatus.IN_TRANSIT, CargoStatus.OUT_FOR_DELIVERY, CargoStatus.DELIVERED, CargoStatus.DELAYED ->
                Permission.TRANSITION_TRANSIT_DELIVERY
            CargoStatus.ON_HOLD, CargoStatus.CANCELLED -> Permission.TRANSITION_HOLD_CANCEL_RETURN
            CargoStatus.RETURNED -> {
                if (from == CargoStatus.OUT_FOR_DELIVERY) Permission.TRANSITION_TRANSIT_DELIVERY
                else Permission.TRANSITION_HOLD_CANCEL_RETURN
            }
            CargoStatus.CREATED -> Permission.CREATE_SHIPMENT
        }
    }

    fun validateTransition(
        from: CargoStatus,
        to: CargoStatus,
        role: UserRole
    ): DomainResult<Unit> {
        if (from.isTerminal) {
            return DomainResult.Failure(
                code = ErrorCode.INVALID_TRANSITION,
                message = "Shipment is in terminal state '${from.displayLabel}' and cannot be modified."
            )
        }
        if (from == to) {
            return DomainResult.Failure(
                code = ErrorCode.INVALID_TRANSITION,
                message = "Shipment is already in state '${from.displayLabel}'."
            )
        }
        if (!isGraphTransitionValid(from, to)) {
            val validList = allowedTransitions[from].orEmpty().joinToString(", ") { it.displayLabel }
            return DomainResult.Failure(
                code = ErrorCode.INVALID_TRANSITION,
                message = "Invalid lifecycle transition: ${from.displayLabel} -> ${to.displayLabel}. Allowed next states: $validList."
            )
        }
        val requiredPermission = requiredPermissionForTransition(from, to)
        if (!RbacPolicyEngine.hasPermission(role, requiredPermission)) {
            return DomainResult.Failure(
                code = ErrorCode.PERMISSION_DENIED,
                message = "Role '${role.displayName}' lacks permission '$requiredPermission' for transition ${from.displayLabel} -> ${to.displayLabel}."
            )
        }
        return DomainResult.Success(Unit)
    }

    fun availableTransitionsForRole(from: CargoStatus, role: UserRole): List<CargoStatus> {
        return allowedTransitions[from]
            .orEmpty()
            .filter { target -> validateTransition(from, target, role) is DomainResult.Success }
            .sortedBy { it.ordinal }
    }

    fun allGraphTransitions(from: CargoStatus): Set<CargoStatus> =
        allowedTransitions[from].orEmpty()

    /**
     * Returns the standard forward checkpoint in the cargo lifecycle for one-scan auto-advance.
     */
    fun nextCanonicalStatus(current: CargoStatus): CargoStatus? = when (current) {
        CargoStatus.CREATED -> CargoStatus.RECEIVED
        CargoStatus.RECEIVED -> CargoStatus.WAREHOUSE
        CargoStatus.WAREHOUSE -> CargoStatus.DISPATCHED
        CargoStatus.DISPATCHED -> CargoStatus.IN_TRANSIT
        CargoStatus.IN_TRANSIT -> CargoStatus.OUT_FOR_DELIVERY
        CargoStatus.OUT_FOR_DELIVERY -> CargoStatus.DELIVERED
        CargoStatus.DELAYED -> CargoStatus.IN_TRANSIT
        CargoStatus.ON_HOLD -> CargoStatus.WAREHOUSE
        CargoStatus.RETURNED -> CargoStatus.WAREHOUSE
        CargoStatus.DELIVERED, CargoStatus.CANCELLED -> null
    }
}
