package com.example.domain

/**
 * Authoritative Role-Based Access Control (RBAC) policy engine.
 * Used identically across domain use cases, repository gates, and API request interceptors.
 */
object RbacPolicyEngine {

    private val rolePermissions: Map<UserRole, Set<Permission>> = mapOf(
        // System Admin: unrestricted full access across every operational, security, audit, and system benchmark capability.
        UserRole.ADMIN to Permission.entries.toSet(),

        // Operations Manager: end-to-end hub operations, manifests, inventory, customers, staff, holds/returns, and scanner.
        // Excluded: Admin-only governance (VIEW_AUDIT_LOGS, RUN_SEED_AND_BENCHMARK).
        UserRole.OPS_MANAGER to setOf(
            Permission.PUBLIC_TRACK_SHIPMENT,
            Permission.VIEW_OPERATIONS_DASHBOARD,
            Permission.VIEW_CUSTOMERS,
            Permission.MANAGE_CUSTOMERS,
            Permission.CREATE_SHIPMENT,
            Permission.TRANSITION_WAREHOUSE_STATES,
            Permission.TRANSITION_DISPATCH_STATES,
            Permission.TRANSITION_TRANSIT_DELIVERY,
            Permission.TRANSITION_HOLD_CANCEL_RETURN,
            Permission.VIEW_INVENTORY,
            Permission.MANAGE_PACKAGES_INVENTORY,
            Permission.VIEW_EMPLOYEES,
            Permission.ASSIGN_TASKS,
            Permission.UPDATE_OWN_TASKS,
            Permission.USE_SCANNER,
            Permission.VIEW_INTERNAL_FINANCIALS
        ),

        // Freight Dispatcher: booking, routing, dispatch coordination, clients, staff roster & task assignment.
        // Excluded: Warehouse bins/inventory, dock intake, scanner, holds/cancellations, audit logs, system benchmarks.
        UserRole.DISPATCHER to setOf(
            Permission.PUBLIC_TRACK_SHIPMENT,
            Permission.VIEW_OPERATIONS_DASHBOARD,
            Permission.VIEW_CUSTOMERS,
            Permission.MANAGE_CUSTOMERS,
            Permission.CREATE_SHIPMENT,
            Permission.TRANSITION_DISPATCH_STATES,
            Permission.TRANSITION_TRANSIT_DELIVERY,
            Permission.VIEW_EMPLOYEES,
            Permission.ASSIGN_TASKS,
            Permission.UPDATE_OWN_TASKS,
            Permission.VIEW_INTERNAL_FINANCIALS
        ),

        // Warehouse Specialist: dock intake, bin/package inventory, outbound handoff, dock scanner, and own assigned tasks.
        // Excluded: Executive dashboard, booking shipments, customer/staff directories, assigning tasks, transit/delivery, financials, audit/benchmarks.
        UserRole.WAREHOUSE_STAFF to setOf(
            Permission.PUBLIC_TRACK_SHIPMENT,
            Permission.TRANSITION_WAREHOUSE_STATES,
            Permission.TRANSITION_DISPATCH_STATES,
            Permission.VIEW_INVENTORY,
            Permission.MANAGE_PACKAGES_INVENTORY,
            Permission.UPDATE_OWN_TASKS,
            Permission.USE_SCANNER
        ),

        // Fleet Driver: road transit & final-mile delivery updates, delivery scanner, and own assigned tasks only.
        // Excluded: Executive dashboard, booking, warehouse inventory, customers, staff roster, task assignment, financials, audit/benchmarks.
        UserRole.DRIVER to setOf(
            Permission.PUBLIC_TRACK_SHIPMENT,
            Permission.TRANSITION_TRANSIT_DELIVERY,
            Permission.UPDATE_OWN_TASKS,
            Permission.USE_SCANNER
        )
    )

    fun hasPermission(role: UserRole, permission: Permission): Boolean {
        return rolePermissions[role]?.contains(permission) == true
    }

    fun permissionsFor(role: UserRole): Set<Permission> {
        return rolePermissions[role].orEmpty()
    }

    fun allowedScannerCheckpoints(role: UserRole): List<CargoStatus> {
        if (!hasPermission(role, Permission.USE_SCANNER)) return emptyList()
        val checkpoints = mutableListOf<CargoStatus>()
        if (hasPermission(role, Permission.TRANSITION_WAREHOUSE_STATES)) {
            checkpoints += listOf(CargoStatus.RECEIVED, CargoStatus.WAREHOUSE)
        }
        if (hasPermission(role, Permission.TRANSITION_DISPATCH_STATES)) {
            checkpoints += CargoStatus.DISPATCHED
        }
        if (hasPermission(role, Permission.TRANSITION_TRANSIT_DELIVERY)) {
            checkpoints += listOf(
                CargoStatus.IN_TRANSIT,
                CargoStatus.OUT_FOR_DELIVERY,
                CargoStatus.DELIVERED,
                CargoStatus.DELAYED
            )
        }
        return checkpoints.distinct()
    }

    fun roleScopeSummary(role: UserRole): String = when (role) {
        UserRole.ADMIN ->
            "Full Access: All portals, Audit Chain, 10k Benchmark Lab, Holds/Cancellations & Governance"
        UserRole.OPS_MANAGER ->
            "Ops Oversight: Dashboard, Shipments, Inventory, Clients, Staff & Holds (No Audit / Benchmark)"
        UserRole.DISPATCHER ->
            "Dispatch & Routing: Dashboard, Book/Dispatch Shipments, Clients & Task Board (No Bins / Scanner / Audit)"
        UserRole.WAREHOUSE_STAFF ->
            "Dock & Bins: Inventory, Receiving/Stowage, Dock Scanner & Own Tasks (No Dashboard / Clients / Financials)"
        UserRole.DRIVER ->
            "Final-Mile Fleet: Transit/Delivery Updates, Delivery Scanner & Own Tasks (No Dashboard / Inventory / Clients)"
    }

    fun requireAuthorized(
        session: OperatorSession?,
        permission: Permission
    ): DomainResult<OperatorSession> {
        if (session == null || session.sessionToken.isBlank()) {
            return DomainResult.Failure(
                code = ErrorCode.UNAUTHORIZED,
                message = "Authentication required for operation '$permission'."
            )
        }
        if (!hasPermission(session.role, permission)) {
            return DomainResult.Failure(
                code = ErrorCode.PERMISSION_DENIED,
                message = "RBAC Policy Denied: ${session.role.displayName} cannot execute $permission."
            )
        }
        return DomainResult.Success(session)
    }
}
