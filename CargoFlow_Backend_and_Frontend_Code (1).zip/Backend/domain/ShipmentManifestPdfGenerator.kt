package com.example.domain

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/**
 * Snapshot of a scanned shipment or package item staged for digital manifest export.
 */
data class ScannedManifestItem(
    val key: String,
    val scannedCode: String,
    val trackingNumber: String,
    val packageCode: String?,
    val sku: String?,
    val description: String,
    val originHub: String,
    val destination: String,
    val status: String,
    val serviceTier: String,
    val weightKg: Double,
    val binLocation: String?,
    val fragile: Boolean,
    val scannedAtEpochMs: Long
)

/**
 * Metadata describing a generated digital shipment manifest PDF stored in app-private cache.
 */
data class GeneratedManifestPdf(
    val manifestNumber: String,
    val filePath: String,
    val fileName: String,
    val itemCount: Int,
    val totalWeightKg: Double,
    val fragileCount: Int,
    val sha256Fingerprint: String,
    val fileSizeBytes: Long,
    val generatedAtEpochMs: Long
)

/**
 * Generates multi-page A4 digital shipment manifest PDFs using Android's native [PdfDocument] API.
 * Files are written to app-private cache (`cacheDir/manifests`) so zero storage permissions are required.
 */
object ShipmentManifestPdfGenerator {

    private const val PAGE_WIDTH = 595   // A4 width at 72 dpi
    private const val PAGE_HEIGHT = 842  // A4 height at 72 dpi
    private const val MARGIN_X = 36f
    private const val CONTENT_WIDTH = PAGE_WIDTH - (MARGIN_X * 2)
    private const val FOOTER_RESERVED_Y = 786f

    private val colorNavy = Color.parseColor("#0B172A")
    private val colorNavyLight = Color.parseColor("#13223A")
    private val colorAmber = Color.parseColor("#F59E0B")
    private val colorBlue = Color.parseColor("#1D4ED8")
    private val colorEmerald = Color.parseColor("#059669")
    private val colorCrimson = Color.parseColor("#DC2626")
    private val colorSlateBg = Color.parseColor("#F4F7FA")
    private val colorBorder = Color.parseColor("#CBD5E1")
    private val colorInkDark = Color.parseColor("#0F172A")
    private val colorInkMuted = Color.parseColor("#475569")

    fun generate(
        context: Context,
        items: List<ScannedManifestItem>,
        operator: OperatorSession?,
        recipientEmail: String = "",
        notes: String = ""
    ): GeneratedManifestPdf {
        require(items.isNotEmpty()) { "At least one scanned item is required to generate a manifest PDF." }

        val now = System.currentTimeMillis()
        val idStamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(now))
        val readableTime = SimpleDateFormat("MMM dd, yyyy · HH:mm:ss z", Locale.US).format(Date(now))
        val manifestNumber = "MAN-$idStamp"
        val fileName = "CargoFlow_Manifest_$idStamp.pdf"

        val totalWeight = items.sumOf { it.weightKg }
        val fragileCount = items.count { it.fragile }
        val fingerprint = computeFingerprint(manifestNumber, items, operator?.employeeCode ?: "OPS")

        val manifestDir = File(context.cacheDir, "manifests").apply {
            if (!exists()) mkdirs()
        }
        val outFile = File(manifestDir, fileName)

        val firstPageRowCapacity = 13
        val continuationRowCapacity = 20
        val pageChunks = buildList {
            if (items.size <= firstPageRowCapacity) {
                add(items)
            } else {
                add(items.take(firstPageRowCapacity))
                var offset = firstPageRowCapacity
                while (offset < items.size) {
                    add(items.subList(offset, minOf(offset + continuationRowCapacity, items.size)))
                    offset += continuationRowCapacity
                }
            }
        }
        val totalPages = max(1, pageChunks.size)

        val renderedNatively = renderWithNativePdfDocument(
            outFile = outFile,
            pageChunks = pageChunks,
            totalPages = totalPages,
            manifestNumber = manifestNumber,
            readableTime = readableTime,
            operator = operator,
            totalItems = items.size,
            totalWeight = totalWeight,
            fragileCount = fragileCount,
            recipientEmail = recipientEmail.trim(),
            notes = notes.trim(),
            fingerprint = fingerprint
        )

        if (!renderedNatively) {
            writeStandardPdf14Fallback(
                outFile = outFile,
                pageChunks = pageChunks,
                manifestNumber = manifestNumber,
                readableTime = readableTime,
                operator = operator,
                totalItems = items.size,
                totalWeight = totalWeight,
                fragileCount = fragileCount,
                recipientEmail = recipientEmail.trim(),
                notes = notes.trim(),
                fingerprint = fingerprint
            )
        }

        return GeneratedManifestPdf(
            manifestNumber = manifestNumber,
            filePath = outFile.absolutePath,
            fileName = fileName,
            itemCount = items.size,
            totalWeightKg = totalWeight,
            fragileCount = fragileCount,
            sha256Fingerprint = fingerprint,
            fileSizeBytes = outFile.length(),
            generatedAtEpochMs = now
        )
    }

    private fun renderWithNativePdfDocument(
        outFile: File,
        pageChunks: List<List<ScannedManifestItem>>,
        totalPages: Int,
        manifestNumber: String,
        readableTime: String,
        operator: OperatorSession?,
        totalItems: Int,
        totalWeight: Double,
        fragileCount: Int,
        recipientEmail: String,
        notes: String,
        fingerprint: String
    ): Boolean {
        val pdf = try {
            PdfDocument()
        } catch (_: Throwable) {
            return false
        }
        return try {
            var runningIndex = 1
            pageChunks.forEachIndexed { pageIndex, chunk ->
                val pageNumber = pageIndex + 1
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                val page = pdf.startPage(pageInfo)
                val canvas = page.canvas

                // White page canvas
                canvas.drawColor(Color.WHITE)

                var cursorY = drawHeaderBanner(
                    canvas = canvas,
                    manifestNumber = manifestNumber,
                    readableTime = readableTime,
                    isContinuation = pageIndex > 0
                )

                if (pageIndex == 0) {
                    cursorY = drawMetadataSummary(
                        canvas = canvas,
                        startY = cursorY + 14f,
                        operator = operator,
                        itemCount = totalItems,
                        totalWeightKg = totalWeight,
                        fragileCount = fragileCount,
                        recipientEmail = recipientEmail,
                        notes = notes
                    )
                }

                cursorY = drawTableHeader(canvas = canvas, startY = cursorY + 14f)

                chunk.forEachIndexed { rowIdx, item ->
                    cursorY = drawItemRow(
                        canvas = canvas,
                        startY = cursorY,
                        rowNumber = runningIndex++,
                        item = item,
                        shaded = rowIdx % 2 == 1
                    )
                }

                if (pageNumber == totalPages) {
                    drawTotalsAndSignOff(
                        canvas = canvas,
                        startY = (cursorY + 14f).coerceAtMost(FOOTER_RESERVED_Y - 76f),
                        itemCount = totalItems,
                        totalWeightKg = totalWeight,
                        fragileCount = fragileCount,
                        operatorName = operator?.fullName ?: "Authorized Operator"
                    )
                }

                drawPageFooter(
                    canvas = canvas,
                    pageNumber = pageNumber,
                    totalPages = totalPages,
                    manifestNumber = manifestNumber,
                    fingerprint = fingerprint
                )

                pdf.finishPage(page)
            }

            FileOutputStream(outFile).use { stream ->
                pdf.writeTo(stream)
                stream.flush()
            }
            outFile.exists() && outFile.length() > 0L
        } catch (_: IllegalStateException) {
            false
        } catch (_: UnsatisfiedLinkError) {
            false
        } finally {
            try {
                pdf.close()
            } catch (_: Throwable) {
                // Ignore native close failure on uninitialized JVM stubs
            }
        }
    }

    /**
     * Standards-compliant PDF 1.4 fallback generator used only when native Android Skia PdfDocument
     * JNI is unavailable (e.g., headless JVM / Robolectric unit tests).
     */
    private fun writeStandardPdf14Fallback(
        outFile: File,
        pageChunks: List<List<ScannedManifestItem>>,
        manifestNumber: String,
        readableTime: String,
        operator: OperatorSession?,
        totalItems: Int,
        totalWeight: Double,
        fragileCount: Int,
        recipientEmail: String,
        notes: String,
        fingerprint: String
    ) {
        val objects = mutableListOf<String>()
        // Obj 1: Catalog, Obj 2: Pages, Obj 3: Font
        objects.add("") // placeholder 1
        objects.add("") // placeholder 2
        objects.add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>")

        val pageObjectIds = mutableListOf<Int>()
        var runningIndex = 1
        val totalPages = max(1, pageChunks.size)

        pageChunks.forEachIndexed { pageIndex, chunk ->
            val streamText = buildString {
                appendLine("BT")
                appendLine("/F1 12 Tf")
                appendLine("36 800 Td")
                appendLine("(${escapePdfText("CargoFlow Digital Shipment Manifest - $manifestNumber")}) Tj")
                appendLine("/F1 9 Tf")
                appendLine("0 -16 Td (${escapePdfText("Generated: $readableTime | Page ${pageIndex + 1} of $totalPages")}) Tj")
                if (pageIndex == 0) {
                    val opInfo = operator?.let { "${it.fullName} (${it.role.displayName}) - ${it.hubLocation}" } ?: "Operations Desk"
                    appendLine("0 -14 Td (${escapePdfText("Operator: $opInfo")}) Tj")
                    appendLine("0 -14 Td (${escapePdfText("Totals: $totalItems items | ${String.format(Locale.US, "%.2f", totalWeight)} kg | Fragile: $fragileCount")}) Tj")
                    if (recipientEmail.isNotBlank()) {
                        appendLine("0 -14 Td (${escapePdfText("Recipient: $recipientEmail")}) Tj")
                    }
                    if (notes.isNotBlank()) {
                        appendLine("0 -14 Td (${escapePdfText("Notes: $notes")}) Tj")
                    }
                }
                appendLine("0 -18 Td (${escapePdfText("--------------------------------------------------------------------------------")}) Tj")
                chunk.forEach { item ->
                    val line = String.format(
                        Locale.US,
                        "%02d | %s | %s -> %s | %s | %.1f kg%s",
                        runningIndex++,
                        item.trackingNumber,
                        item.originHub,
                        item.destination,
                        CargoStatus.fromNameSafe(item.status).displayLabel,
                        item.weightKg,
                        if (item.fragile) " [FRAGILE]" else ""
                    )
                    appendLine("0 -14 Td (${escapePdfText(truncate(line, 88))}) Tj")
                }
                appendLine("0 -18 Td (${escapePdfText("SHA-256 Digest: $fingerprint")}) Tj")
                appendLine("ET")
            }

            val contentObjId = objects.size + 1
            objects.add("<< /Length ${streamText.toByteArray(Charsets.ISO_8859_1).size} >>\nstream\n$streamText\nendstream")

            val pageObjId = objects.size + 1
            pageObjectIds.add(pageObjId)
            objects.add("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $PAGE_WIDTH $PAGE_HEIGHT] /Resources << /Font << /F1 3 0 R >> >> /Contents $contentObjId 0 R >>")
        }

        objects[0] = "<< /Type /Catalog /Pages 2 0 R >>"
        objects[1] = "<< /Type /Pages /Kids [${pageObjectIds.joinToString(" ") { "$it 0 R" }}] /Count ${pageObjectIds.size} >>"

        val sb = StringBuilder()
        sb.append("%PDF-1.4\n")
        val offsets = mutableListOf(0)
        objects.forEachIndexed { idx, body ->
            offsets.add(sb.length)
            sb.append("${idx + 1} 0 obj\n$body\nendobj\n")
        }
        val xrefPos = sb.length
        sb.append("xref\n0 ${objects.size + 1}\n")
        sb.append("0000000000 65535 f \n")
        for (i in 1..objects.size) {
            sb.append(String.format(Locale.US, "%010d 00000 n \n", offsets[i]))
        }
        sb.append("trailer\n<< /Size ${objects.size + 1} /Root 1 0 R >>\n")
        sb.append("startxref\n$xrefPos\n%%EOF\n")

        outFile.writeBytes(sb.toString().toByteArray(Charsets.ISO_8859_1))
    }

    private fun escapePdfText(input: String): String {
        return input
            .replace("\\", "\\\\")
            .replace("(", "\\(")
            .replace(")", "\\)")
            .replace(Regex("[^\\x20-\\x7E]"), " ")
    }

    private fun drawHeaderBanner(
        canvas: android.graphics.Canvas,
        manifestNumber: String,
        readableTime: String,
        isContinuation: Boolean
    ): Float {
        val bannerHeight = if (isContinuation) 64f else 88f
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorNavy }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), bannerHeight, bgPaint)

        // Amber bottom accent strip
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorAmber }
        canvas.drawRect(0f, bannerHeight - 4f, PAGE_WIDTH.toFloat(), bannerHeight, accentPaint)

        // Brand badge box
        val badgeRect = RectF(MARGIN_X, 18f, MARGIN_X + 26f, 44f)
        canvas.drawRoundRect(badgeRect, 6f, 6f, accentPaint)
        val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorNavy
            textSize = 13f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("CF", badgeRect.centerX(), badgeRect.centerY() + 4.5f, badgeTextPaint)

        // Brand title
        val brandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = if (isContinuation) 15f else 18f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        canvas.drawText("CargoFlow", MARGIN_X + 34f, 36f, brandPaint)

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorAmber
            textSize = 9.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val subtitle = if (isContinuation) {
            "DIGITAL SHIPMENT MANIFEST (CONTINUED)"
        } else {
            "DIGITAL SHIPMENT MANIFEST · VERIFIED SCAN DISPATCH"
        }
        canvas.drawText(subtitle, MARGIN_X, if (isContinuation) 54f else 66f, subtitlePaint)

        // Right-aligned manifest ID & timestamp
        val rightIdPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 12f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(manifestNumber, PAGE_WIDTH - MARGIN_X, 34f, rightIdPaint)

        val rightTimePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = 8.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(readableTime, PAGE_WIDTH - MARGIN_X, 49f, rightTimePaint)

        return bannerHeight
    }

    private fun drawMetadataSummary(
        canvas: android.graphics.Canvas,
        startY: Float,
        operator: OperatorSession?,
        itemCount: Int,
        totalWeightKg: Double,
        fragileCount: Int,
        recipientEmail: String,
        notes: String
    ): Float {
        val hasExtraLine = recipientEmail.isNotBlank() || notes.isNotBlank()
        val boxHeight = if (hasExtraLine) 92f else 68f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + boxHeight)

        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorSlateBg }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorBorder
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(rect, 8f, 8f, fillPaint)
        canvas.drawRoundRect(rect, 8f, 8f, strokePaint)

        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkMuted
            textSize = 8f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkDark
            textSize = 10f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        val col1X = MARGIN_X + 12f
        val col2X = MARGIN_X + 195f
        val col3X = MARGIN_X + 370f

        // Row 1 metadata
        canvas.drawText("ISSUED BY OPERATOR", col1X, startY + 18f, labelPaint)
        val opName = operator?.let { "${it.fullName} (${it.role.displayName})" } ?: "Operations Desk"
        canvas.drawText(truncate(opName, 30), col1X, startY + 32f, valuePaint)

        canvas.drawText("ORIGIN FACILITY / HUB", col2X, startY + 18f, labelPaint)
        canvas.drawText(truncate(operator?.hubLocation ?: "Global Hub Network", 26), col2X, startY + 32f, valuePaint)

        canvas.drawText("MANIFEST TOTALS", col3X, startY + 18f, labelPaint)
        val totalsText = String.format(Locale.US, "%d Items · %.1f kg", itemCount, totalWeightKg)
        canvas.drawText(totalsText, col3X, startY + 32f, valuePaint)

        // Row 2 metadata
        canvas.drawText("OPERATOR EMAIL", col1X, startY + 49f, labelPaint)
        canvas.drawText(truncate(operator?.email ?: "ops@cargoflow.io", 28), col1X, startY + 61f, valuePaint)

        canvas.drawText("HANDLING ALERTS", col2X, startY + 49f, labelPaint)
        val fragilePaint = Paint(valuePaint).apply {
            color = if (fragileCount > 0) colorCrimson else colorEmerald
        }
        val alertText = if (fragileCount > 0) "$fragileCount Fragile Unit(s)" else "Standard Handling"
        canvas.drawText(alertText, col2X, startY + 61f, fragilePaint)

        canvas.drawText("DISPATCH RECIPIENT", col3X, startY + 49f, labelPaint)
        canvas.drawText(
            truncate(recipientEmail.ifBlank { "General Dispatch" }, 24),
            col3X,
            startY + 61f,
            valuePaint
        )

        if (hasExtraLine && notes.isNotBlank()) {
            val notePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = colorInkMuted
                textSize = 8.5f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
            }
            canvas.drawText("Notes: ${truncate(notes, 92)}", col1X, startY + 81f, notePaint)
        }

        return startY + boxHeight
    }

    private fun drawTableHeader(canvas: android.graphics.Canvas, startY: Float): Float {
        val headerHeight = 24f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + headerHeight)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorNavyLight }
        canvas.drawRoundRect(rect, 4f, 4f, bgPaint)

        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 8.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val baseline = startY + 15.5f
        canvas.drawText("#", MARGIN_X + 8f, baseline, headerPaint)
        canvas.drawText("TRACKING / PKG ID", MARGIN_X + 28f, baseline, headerPaint)
        canvas.drawText("CORRIDOR & DESCRIPTION", MARGIN_X + 166f, baseline, headerPaint)
        canvas.drawText("STATUS", MARGIN_X + 344f, baseline, headerPaint)
        canvas.drawText("WT (KG)", MARGIN_X + 422f, baseline, headerPaint)
        canvas.drawText("BIN / TAG", MARGIN_X + 468f, baseline, headerPaint)

        return startY + headerHeight
    }

    private fun drawItemRow(
        canvas: android.graphics.Canvas,
        startY: Float,
        rowNumber: Int,
        item: ScannedManifestItem,
        shaded: Boolean
    ): Float {
        val rowHeight = 32f
        if (shaded) {
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorSlateBg }
            canvas.drawRect(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + rowHeight, bgPaint)
        }

        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorBorder
            strokeWidth = 0.6f
        }
        canvas.drawLine(MARGIN_X, startY + rowHeight, PAGE_WIDTH - MARGIN_X, startY + rowHeight, dividerPaint)

        val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkMuted
            textSize = 8.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val codePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkDark
            textSize = 9f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkMuted
            textSize = 7.8f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val statusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorBlue
            textSize = 8f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val weightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkDark
            textSize = 8.8f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }

        val line1Y = startY + 13f
        val line2Y = startY + 24.5f

        canvas.drawText(String.format(Locale.US, "%02d", rowNumber), MARGIN_X + 8f, line1Y, numPaint)

        canvas.drawText(truncate(item.trackingNumber, 20), MARGIN_X + 28f, line1Y, codePaint)
        val pkgSub = item.packageCode?.let { "PKG: $it" } ?: "CODE: ${item.scannedCode}"
        canvas.drawText(truncate(pkgSub, 24), MARGIN_X + 28f, line2Y, subPaint)

        val corridor = "${item.originHub} -> ${item.destination}"
        canvas.drawText(truncate(corridor, 34), MARGIN_X + 166f, line1Y, codePaint.apply { textSize = 8.4f })
        canvas.drawText(truncate(item.description, 36), MARGIN_X + 166f, line2Y, subPaint)

        val statusLabel = CargoStatus.fromNameSafe(item.status).displayLabel
        canvas.drawText(truncate(statusLabel, 13), MARGIN_X + 344f, line1Y, statusPaint)
        canvas.drawText(truncate(item.serviceTier, 14), MARGIN_X + 344f, line2Y, subPaint)

        canvas.drawText(String.format(Locale.US, "%.1f", item.weightKg), MARGIN_X + 422f, line1Y, weightPaint)

        val binLabel = item.binLocation ?: "DOCK"
        canvas.drawText(truncate(binLabel, 10), MARGIN_X + 468f, line1Y, weightPaint)
        if (item.fragile) {
            val fragilePaint = Paint(statusPaint).apply { color = colorCrimson }
            canvas.drawText("FRAGILE", MARGIN_X + 468f, line2Y, fragilePaint)
        } else {
            canvas.drawText("STD", MARGIN_X + 468f, line2Y, subPaint)
        }

        return startY + rowHeight
    }

    private fun drawTotalsAndSignOff(
        canvas: android.graphics.Canvas,
        startY: Float,
        itemCount: Int,
        totalWeightKg: Double,
        fragileCount: Int,
        operatorName: String
    ) {
        val boxRect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + 58f)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorSlateBg }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorNavy
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, fillPaint)
        canvas.drawRoundRect(boxRect, 6f, 6f, borderPaint)

        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkDark
            textSize = 9.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val mutedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkMuted
            textSize = 8f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }

        val summary = String.format(
            Locale.US,
            "VERIFIED DISPATCH SUMMARY: %d SCANNED UNIT(S) · GROSS WEIGHT %.2f KG · FRAGILE %d",
            itemCount,
            totalWeightKg,
            fragileCount
        )
        canvas.drawText(summary, MARGIN_X + 12f, startY + 19f, boldPaint)

        // Operator & Receiver signature lines
        val lineY = startY + 44f
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkMuted
            strokeWidth = 0.8f
        }
        canvas.drawLine(MARGIN_X + 12f, lineY, MARGIN_X + 230f, lineY, linePaint)
        canvas.drawText("DISPATCHED BY: ${truncate(operatorName, 26)}", MARGIN_X + 12f, lineY + 10f, mutedPaint)

        canvas.drawLine(MARGIN_X + 280f, lineY, PAGE_WIDTH - MARGIN_X - 12f, lineY, linePaint)
        canvas.drawText("CARRIER / RECEIVER ACKNOWLEDGEMENT", MARGIN_X + 280f, lineY + 10f, mutedPaint)
    }

    private fun drawPageFooter(
        canvas: android.graphics.Canvas,
        pageNumber: Int,
        totalPages: Int,
        manifestNumber: String,
        fingerprint: String
    ) {
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorBorder
            strokeWidth = 0.8f
        }
        canvas.drawLine(MARGIN_X, FOOTER_RESERVED_Y, PAGE_WIDTH - MARGIN_X, FOOTER_RESERVED_Y, dividerPaint)

        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInkMuted
            textSize = 7.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }
        canvas.drawText(
            "CargoFlow Digital Manifest · $manifestNumber · SHA-256: ${fingerprint.take(20)}…",
            MARGIN_X,
            FOOTER_RESERVED_Y + 16f,
            footerPaint
        )

        val pagePaint = Paint(footerPaint).apply { textAlign = Paint.Align.RIGHT }
        canvas.drawText(
            "Page $pageNumber of $totalPages",
            PAGE_WIDTH - MARGIN_X,
            FOOTER_RESERVED_Y + 16f,
            pagePaint
        )
    }

    private fun computeFingerprint(
        manifestNumber: String,
        items: List<ScannedManifestItem>,
        operatorCode: String
    ): String {
        val payload = buildString {
            append(manifestNumber).append('|').append(operatorCode).append('|')
            items.forEach {
                append(it.trackingNumber).append(':')
                    .append(it.packageCode.orEmpty()).append(':')
                    .append(it.status).append(':')
                    .append(it.weightKg).append(';')
            }
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun truncate(text: String, maxChars: Int): String {
        if (text.length <= maxChars) return text
        return text.take((maxChars - 1).coerceAtLeast(1)) + "…"
    }
}

/**
 * Builds and launches secure, zero-permission Android Share / Email intents backed by [FileProvider].
 */
object ManifestShareHelper {

    fun buildEmailManifestIntent(
        context: Context,
        pdf: GeneratedManifestPdf,
        recipientEmail: String,
        operator: OperatorSession?,
        chooserTitle: String
    ): Intent {
        val file = File(pdf.filePath)
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val formattedWeight = String.format(Locale.US, "%.2f", pdf.totalWeightKg)
        val subject = "CargoFlow Digital Shipment Manifest ${pdf.manifestNumber} (${pdf.itemCount} items)"
        val body = buildString {
            appendLine("Attached is the CargoFlow Digital Shipment Manifest PDF.")
            appendLine()
            appendLine("Manifest ID: ${pdf.manifestNumber}")
            appendLine("Scanned Units: ${pdf.itemCount}")
            appendLine("Total Gross Weight: $formattedWeight kg")
            if (pdf.fragileCount > 0) {
                appendLine("Fragile Units: ${pdf.fragileCount}")
            }
            operator?.let {
                appendLine("Dispatched By: ${it.fullName} (${it.role.displayName})")
                appendLine("Facility Hub: ${it.hubLocation}")
            }
            appendLine("SHA-256 Integrity Digest: ${pdf.sha256Fingerprint.take(24)}…")
        }

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            if (recipientEmail.isNotBlank()) {
                putExtra(Intent.EXTRA_EMAIL, arrayOf(recipientEmail.trim()))
            }
            clipData = ClipData.newRawUri(pdf.fileName, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        return Intent.createChooser(sendIntent, chooserTitle).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun launchEmailManifestShare(
        context: Context,
        pdf: GeneratedManifestPdf,
        recipientEmail: String,
        operator: OperatorSession?,
        chooserTitle: String
    ): Result<Unit> {
        return try {
            val file = File(pdf.filePath)
            if (!file.exists()) {
                return Result.failure(IllegalStateException("Manifest PDF file could not be found. Please regenerate."))
            }
            val chooser = buildEmailManifestIntent(
                context = context,
                pdf = pdf,
                recipientEmail = recipientEmail,
                operator = operator,
                chooserTitle = chooserTitle
            )
            context.startActivity(chooser)
            Result.success(Unit)
        } catch (e: ActivityNotFoundException) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
