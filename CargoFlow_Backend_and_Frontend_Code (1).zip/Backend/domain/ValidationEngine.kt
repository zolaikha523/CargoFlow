package com.example.domain

/**
 * Input validation & sanitization rules applied prior to persistence or network dispatch.
 */
object ValidationEngine {

    private val emailRegex = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
    private val trackingRegex = Regex("^(CF|PKG)-\\d{4}-[A-Z0-9-]{4,18}$")

    fun sanitizeText(input: String, maxLen: Int = 180): String =
        input.trim().replace(Regex("\\s+"), " ").take(maxLen)

    fun validateTrackingQuery(query: String): DomainResult<String> {
        val cleaned = query.trim().uppercase()
        if (cleaned.length < 6) {
            return DomainResult.Failure(
                ErrorCode.VALIDATION_ERROR,
                "Enter a valid tracking number (e.g., CF-2026-000001)."
            )
        }
        if (!trackingRegex.matches(cleaned) && !cleaned.startsWith("CARGOFLOW://")) {
            return DomainResult.Failure(
                ErrorCode.VALIDATION_ERROR,
                "Invalid tracking format. Expected CF-YYYY-XXXXXX or PKG-YYYY-XXXXXX-NN."
            )
        }
        return DomainResult.Success(cleaned)
    }

    fun validateCustomerInput(
        companyName: String,
        contactName: String,
        email: String,
        phone: String,
        city: String,
        country: String
    ): DomainResult<Unit> {
        if (companyName.trim().length < 2) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Company name must be at least 2 characters.")
        }
        if (contactName.trim().length < 2) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Primary contact name is required.")
        }
        if (!emailRegex.matches(email.trim())) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Enter a valid corporate email address.")
        }
        if (phone.trim().length < 7) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Phone number must be at least 7 digits.")
        }
        if (city.trim().length < 2 || country.trim().length < 2) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "City and country are required.")
        }
        return DomainResult.Success(Unit)
    }

    fun validateShipmentInput(
        customerId: String,
        originHub: String,
        destinationCity: String,
        destinationCountry: String,
        weightKg: Double,
        declaredValueUsd: Double
    ): DomainResult<Unit> {
        if (customerId.isBlank()) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "A verified customer account must be selected.")
        }
        if (originHub.trim().length < 3) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Origin hub is required.")
        }
        if (destinationCity.trim().length < 2 || destinationCountry.trim().length < 2) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Destination city and country are required.")
        }
        if (weightKg <= 0.0 || weightKg > 50_000.0) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Shipment weight must be between 0.1 and 50,000 kg.")
        }
        if (declaredValueUsd < 0.0 || declaredValueUsd > 10_000_000.0) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Declared cargo value must be between $0 and $10,000,000.")
        }
        return DomainResult.Success(Unit)
    }

    fun validatePackageInput(
        shipmentId: String,
        sku: String,
        description: String,
        weightKg: Double,
        warehouseZone: String,
        binLocation: String
    ): DomainResult<Unit> {
        if (shipmentId.isBlank()) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Package must belong to an existing shipment.")
        }
        if (sku.trim().length < 3) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "SKU must be at least 3 characters.")
        }
        if (description.trim().length < 3) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Package description is required.")
        }
        if (weightKg <= 0.0 || weightKg > 5_000.0) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Package weight must be between 0.1 and 5,000 kg.")
        }
        if (warehouseZone.isBlank() || binLocation.isBlank()) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Warehouse zone and bin location are required.")
        }
        return DomainResult.Success(Unit)
    }

    fun validateTaskInput(
        shipmentId: String,
        assigneeId: String,
        title: String
    ): DomainResult<Unit> {
        if (shipmentId.isBlank()) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Task must reference a shipment.")
        }
        if (assigneeId.isBlank()) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "An active employee must be assigned.")
        }
        if (title.trim().length < 4) {
            return DomainResult.Failure(ErrorCode.VALIDATION_ERROR, "Task title must be at least 4 characters.")
        }
        return DomainResult.Success(Unit)
    }
}
