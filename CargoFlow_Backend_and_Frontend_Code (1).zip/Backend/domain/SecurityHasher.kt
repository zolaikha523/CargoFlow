package com.example.domain

import java.security.MessageDigest
import java.util.UUID

/**
 * Cryptographic helpers for salted operator credential verification and tamper-evident
 * SHA-256 audit log hash chaining.
 */
object SecurityHasher {

    const val GENESIS_HASH = "0000000000000000000000000000000000000000000000000000000000000000"

    fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
        return buildString(digest.size * 2) {
            for (b in digest) {
                append("%02x".format(b.toInt() and 0xFF))
            }
        }
    }

    fun hashPassword(plainPassword: String, salt: String): String {
        // Multi-round salted SHA-256 key stretching (fast in JVM tests, strong against rainbow tables)
        var current = "$salt::$plainPassword::cargoflow-v1"
        repeat(1000) {
            current = sha256Hex(current)
        }
        return current
    }

    fun verifyPassword(plainPassword: String, salt: String, expectedHash: String): Boolean {
        val computed = hashPassword(plainPassword, salt)
        return constantTimeEquals(computed, expectedHash)
    }

    fun generateSessionToken(employeeId: String, role: UserRole): String {
        return "cf_tok_${role.badgeCode.lowercase()}_${sha256Hex("$employeeId:${UUID.randomUUID()}:${System.nanoTime()}").take(24)}"
    }

    fun computeAuditHash(
        prevHash: String,
        timestamp: Long,
        actorId: String,
        actorRole: String,
        action: String,
        entityType: String,
        entityId: String,
        outcome: String,
        details: String
    ): String {
        val canonical = listOf(
            prevHash,
            timestamp.toString(),
            actorId,
            actorRole,
            action,
            entityType,
            entityId,
            outcome,
            details
        ).joinToString("|")
        return sha256Hex(canonical)
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) {
            diff = diff or (a[i].code xor b[i].code)
        }
        return diff == 0
    }
}
