package com.example.domain

enum class CargoStatus(
    val displayLabel: String,
    val publicCustomerLabel: String,
    val progressStep: Int,
    val isTerminal: Boolean = false
) {
    CREATED("Created", "Shipment Registered", 0),
    RECEIVED("Received", "Received at Origin Facility", 1),
    WAREHOUSE("Warehouse", "Processing at Sortation Hub", 2),
    ON_HOLD("On Hold", "Customs / Verification Hold", 2),
    DISPATCHED("Dispatched", "Departed Origin Hub", 3),
    IN_TRANSIT("In Transit", "In Transit to Destination", 4),
    DELAYED("Delayed", "Transit Exception — Rescheduled", 4),
    OUT_FOR_DELIVERY("Out for Delivery", "Out for Final-Mile Delivery", 5),
    DELIVERED("Delivered", "Delivered to Consignee", 6, isTerminal = true),
    RETURNED("Returned", "Returned to Origin Facility", 2),
    CANCELLED("Cancelled", "Shipment Cancelled", 0, isTerminal = true);

    companion object {
        fun fromNameSafe(raw: String): CargoStatus =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: CREATED
    }
}

enum class UserRole(val displayName: String, val badgeCode: String) {
    ADMIN("System Admin", "ADM"),
    OPS_MANAGER("Operations Manager", "MGR"),
    DISPATCHER("Freight Dispatcher", "DSP"),
    WAREHOUSE_STAFF("Warehouse Specialist", "WHS"),
    DRIVER("Fleet Driver", "DRV");

    companion object {
        fun fromNameSafe(raw: String): UserRole =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: DRIVER
    }
}

enum class Permission {
    PUBLIC_TRACK_SHIPMENT,
    VIEW_OPERATIONS_DASHBOARD,
    VIEW_CUSTOMERS,
    MANAGE_CUSTOMERS,
    CREATE_SHIPMENT,
    TRANSITION_WAREHOUSE_STATES,
    TRANSITION_DISPATCH_STATES,
    TRANSITION_TRANSIT_DELIVERY,
    TRANSITION_HOLD_CANCEL_RETURN,
    VIEW_INVENTORY,
    MANAGE_PACKAGES_INVENTORY,
    VIEW_EMPLOYEES,
    ASSIGN_TASKS,
    UPDATE_OWN_TASKS,
    USE_SCANNER,
    VIEW_INTERNAL_FINANCIALS,
    VIEW_AUDIT_LOGS,
    RUN_SEED_AND_BENCHMARK
}

enum class ServiceTier(val label: String, val slaHours: Int) {
    EXPRESS_AIR("Express Air", 24),
    PRIORITY_GROUND("Priority Ground", 72),
    OCEAN_FREIGHT("Ocean Freight", 240),
    COLD_CHAIN("Cold Chain Pharma", 36);

    companion object {
        fun fromNameSafe(raw: String): ServiceTier =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: PRIORITY_GROUND
    }
}

enum class CustomerTier(val label: String) {
    STANDARD("Standard"),
    PRIORITY("Priority"),
    ENTERPRISE("Enterprise");

    companion object {
        fun fromNameSafe(raw: String): CustomerTier =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: STANDARD
    }
}

enum class TaskStatus(val label: String) {
    PENDING("Pending"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    BLOCKED("Blocked");

    companion object {
        fun fromNameSafe(raw: String): TaskStatus =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: PENDING
    }
}

enum class TaskPriority(val label: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    CRITICAL("Critical");

    companion object {
        fun fromNameSafe(raw: String): TaskPriority =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: MEDIUM
    }
}

enum class AuditOutcome {
    ALLOWED,
    DENIED,
    VALIDATION_FAILED
}

data class OperatorSession(
    val employeeId: String,
    val employeeCode: String,
    val fullName: String,
    val email: String,
    val role: UserRole,
    val hubLocation: String,
    val sessionToken: String,
    val authenticatedAtEpochMs: Long
)

/**
 * Strictly redacted public tracking DTO.
 * Never exposes internal pricing, bin locations, employee names/IDs, customer PII,
 * internal notes, or audit trails.
 */
data class PublicTrackingSnapshot(
    val trackingNumber: String,
    val serviceTierLabel: String,
    val currentStatus: CargoStatus,
    val publicStatusLabel: String,
    val originRegion: String,
    val destinationCity: String,
    val destinationCountry: String,
    val packageCount: Int,
    val totalWeightKg: Double,
    val estimatedDeliveryEpochMs: Long,
    val lastUpdatedEpochMs: Long,
    val milestones: List<PublicMilestone>
)

data class PublicMilestone(
    val status: CargoStatus,
    val publicLabel: String,
    val publicLocation: String,
    val timestampEpochMs: Long
)

data class WarehouseZoneMetric(
    val zone: String,
    val packageCount: Int,
    val totalWeightKg: Double,
    val capacityLimit: Int
) {
    val utilizationRatio: Float
        get() = (packageCount.toFloat() / capacityLimit.coerceAtLeast(1)).coerceIn(0f, 1f)
}

data class StaffWorkloadMetric(
    val employeeId: String,
    val employeeName: String,
    val role: UserRole,
    val hubLocation: String,
    val pendingTasks: Int,
    val inProgressTasks: Int,
    val completedTasks: Int
) {
    val activeLoad: Int get() = pendingTasks + inProgressTasks
}

data class DashboardMetrics(
    val totalShipments: Int = 0,
    val activeShipments: Int = 0,
    val deliveredShipments: Int = 0,
    val delayedShipments: Int = 0,
    val pendingSlaBreachCount: Int = 0,
    val onHoldShipments: Int = 0,
    val totalPackages: Int = 0,
    val warehousePackages: Int = 0,
    val totalCustomers: Int = 0,
    val activeEmployees: Int = 0,
    val openTasks: Int = 0,
    val totalRecordsAcrossTables: Int = 0,
    val statusBreakdown: Map<CargoStatus, Int> = emptyMap(),
    val warehouseZones: List<WarehouseZoneMetric> = emptyList(),
    val staffWorkload: List<StaffWorkloadMetric> = emptyList()
)

data class BenchmarkReport(
    val totalSeededRecords: Int,
    val seedDurationMs: Long,
    val indexedTrackingLookupMs: Double,
    val dashboardAggregationMs: Double,
    val delayedQueryMs: Double,
    val paginatedSearchMs: Double,
    val evaluatedAtEpochMs: Long
)

enum class ErrorCode {
    UNAUTHORIZED,
    PERMISSION_DENIED,
    INVALID_TRANSITION,
    VALIDATION_ERROR,
    NOT_FOUND,
    CONFLICT,
    INTERNAL_ERROR
}

sealed class DomainResult<out T> {
    data class Success<T>(val data: T) : DomainResult<T>()
    data class Failure(
        val code: ErrorCode,
        val message: String
    ) : DomainResult<Nothing>()
}
