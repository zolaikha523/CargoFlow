package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.BarcodeEngine
import com.example.domain.CargoStatus
import com.example.domain.StaffWorkloadMetric
import com.example.domain.TaskPriority
import com.example.domain.UserRole
import com.example.domain.WarehouseZoneMetric
import com.example.ui.theme.AlertCrimson100
import com.example.ui.theme.AlertCrimson600
import com.example.ui.theme.ClearedEmerald100
import com.example.ui.theme.ClearedEmerald600
import com.example.ui.theme.HoldViolet100
import com.example.ui.theme.HoldViolet600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber100
import com.example.ui.theme.LogisticsAmber600
import com.example.ui.theme.MaritimeNavy900
import com.example.ui.theme.TelemetryBlue100
import com.example.ui.theme.TelemetryBlue600
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatTimestamp(epochMs: Long): String {
    val fmt = SimpleDateFormat("MMM dd, HH:mm", Locale.US)
    return fmt.format(Date(epochMs))
}

fun formatDateOnly(epochMs: Long): String {
    val fmt = SimpleDateFormat("MMM dd, yyyy", Locale.US)
    return fmt.format(Date(epochMs))
}

fun statusColors(status: CargoStatus): Pair<Color, Color> = when (status) {
    CargoStatus.CREATED -> Color(0xFFE2E8F0) to Color(0xFF334155)
    CargoStatus.RECEIVED -> TelemetryBlue100 to TelemetryBlue600
    CargoStatus.WAREHOUSE -> Color(0xFFE0F2FE) to Color(0xFF0369A1)
    CargoStatus.ON_HOLD -> HoldViolet100 to HoldViolet600
    CargoStatus.DISPATCHED -> LogisticsAmber100 to LogisticsAmber600
    CargoStatus.IN_TRANSIT -> TelemetryBlue100 to TelemetryBlue600
    CargoStatus.OUT_FOR_DELIVERY -> LogisticsAmber100 to Color(0xFFB45309)
    CargoStatus.DELAYED -> AlertCrimson100 to AlertCrimson600
    CargoStatus.DELIVERED -> ClearedEmerald100 to ClearedEmerald600
    CargoStatus.RETURNED -> HoldViolet100 to HoldViolet600
    CargoStatus.CANCELLED -> Color(0xFFF1F5F9) to Color(0xFF64748B)
}

@Composable
fun CargoStatusBadge(
    status: CargoStatus,
    modifier: Modifier = Modifier,
    usePublicLabel: Boolean = false
) {
    val (bg, fg) = statusColors(status)
    Surface(
        color = bg,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = if (usePublicLabel) status.publicCustomerLabel else status.displayLabel.uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.4.sp
                ),
                color = fg,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun RoleBadge(role: UserRole, modifier: Modifier = Modifier) {
    val (bg, fg) = when (role) {
        UserRole.ADMIN -> AlertCrimson100 to AlertCrimson600
        UserRole.OPS_MANAGER -> HoldViolet100 to HoldViolet600
        UserRole.DISPATCHER -> TelemetryBlue100 to TelemetryBlue600
        UserRole.WAREHOUSE_STAFF -> LogisticsAmber100 to LogisticsAmber600
        UserRole.DRIVER -> ClearedEmerald100 to ClearedEmerald600
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Text(
            text = "${role.badgeCode} · ${role.displayName}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = fg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ActiveRoleIndicator(role: UserRole, modifier: Modifier = Modifier) {
    val shortLabel = when (role) {
        UserRole.ADMIN -> "Admin"
        UserRole.OPS_MANAGER -> "Manager"
        UserRole.DISPATCHER -> "Dispatcher"
        UserRole.WAREHOUSE_STAFF -> "Warehouse"
        UserRole.DRIVER -> "Driver"
    }
    val isDarkSurface = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val containerColor = if (isDarkSurface) ClearedEmerald600.copy(alpha = 0.20f) else ClearedEmerald100
    val borderColor = if (isDarkSurface) Color(0xFF34D399).copy(alpha = 0.55f) else ClearedEmerald600.copy(alpha = 0.45f)
    val dotColor = if (isDarkSurface) Color(0xFF22C55E) else ClearedEmerald600
    val textColor = if (isDarkSurface) Color(0xFF34D399) else ClearedEmerald600

    Surface(
        color = containerColor,
        shape = RoundedCornerShape(100),
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier.testTag("active_role_indicator")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Text(
                text = shortLabel,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.3.sp
                ),
                color = textColor,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun PriorityBadge(priority: TaskPriority, modifier: Modifier = Modifier) {
    val (bg, fg) = when (priority) {
        TaskPriority.CRITICAL -> AlertCrimson100 to AlertCrimson600
        TaskPriority.HIGH -> LogisticsAmber100 to LogisticsAmber600
        TaskPriority.MEDIUM -> TelemetryBlue100 to TelemetryBlue600
        TaskPriority.LOW -> Color(0xFFE2E8F0) to Color(0xFF475569)
    }
    Surface(color = bg, shape = RoundedCornerShape(5.dp), modifier = modifier) {
        Text(
            text = priority.label.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = fg,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun KpiMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium.copy(fontFamily = JetBrainsMonoFamily),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun Code128BarcodeView(
    code: String,
    modifier: Modifier = Modifier
) {
    val modules = remember(code) { BarcodeEngine.encodeCode128B(code) }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) {
            if (modules.isEmpty()) return@Canvas
            val barWidth = size.width / modules.size.toFloat()
            modules.forEachIndexed { idx, isDark ->
                if (isDark) {
                    drawRect(
                        color = Color(0xFF0B172A),
                        topLeft = Offset(idx * barWidth, 0f),
                        size = Size(barWidth + 0.5f, size.height)
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = code,
            style = MaterialTheme.typography.labelMedium.copy(
                fontFamily = JetBrainsMonoFamily,
                letterSpacing = 1.6.sp,
                fontWeight = FontWeight.Bold
            ),
            color = MaritimeNavy900
        )
    }
}

@Composable
fun QrCodeMatrixView(
    payload: String,
    modifier: Modifier = Modifier
) {
    val matrix = remember(payload) { BarcodeEngine.generateQrMatrix(payload) }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp))
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(124.dp)) {
            val dim = matrix.size
            val cellSize = size.width / dim.toFloat()
            for (r in 0 until dim) {
                for (c in 0 until dim) {
                    if (matrix[r][c]) {
                        drawRect(
                            color = Color(0xFF0B172A),
                            topLeft = Offset(c * cellSize, r * cellSize),
                            size = Size(cellSize + 0.4f, cellSize + 0.4f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ShippingLabelDialog(
    title: String,
    code: String,
    qrPayload: String,
    subtitle: String,
    metadataLines: List<Pair<String, String>>,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(2.dp, MaritimeNavy900),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Shipping Label",
                            tint = MaritimeNavy900
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "CARGOFLOW MANIFEST LABEL",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = LogisticsAmber600
                            )
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaritimeNavy900
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close label", tint = MaritimeNavy900)
                    }
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF475569)
                )
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = Color(0xFFE2E8F0))
                Spacer(Modifier.height(14.dp))

                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    QrCodeMatrixView(payload = qrPayload)
                }
                Spacer(Modifier.height(12.dp))
                Code128BarcodeView(code = code, modifier = Modifier.fillMaxWidth())

                Spacer(Modifier.height(12.dp))
                metadataLines.forEach { (label, value) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(label, style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                        Text(
                            value,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = MaritimeNavy900
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WarehouseUtilizationPanel(
    zones: List<WarehouseZoneMetric>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Warehouse Zone Capacity", style = MaterialTheme.typography.titleMedium)
            Text(
                "Live pallet & package load across hub zones",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            if (zones.isEmpty()) {
                Text("No inventory telemetry available.", style = MaterialTheme.typography.bodySmall)
            } else {
                zones.forEach { zone ->
                    val barColor = when {
                        zone.utilizationRatio > 0.85f -> AlertCrimson600
                        zone.utilizationRatio > 0.65f -> LogisticsAmber600
                        else -> TelemetryBlue600
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = zone.zone,
                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily)
                        )
                        Text(
                            text = "${zone.packageCount} pkgs · ${zone.totalWeightKg.toInt()} kg (${(zone.utilizationRatio * 100).toInt()}%)",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { zone.utilizationRatio.coerceAtLeast(0.03f) },
                        color = barColor,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
fun StaffWorkloadPanel(
    staff: List<StaffWorkloadMetric>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Staff Workload Distribution", style = MaterialTheme.typography.titleMedium)
            Text(
                "Active task allocation across shift operators",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            val topStaff = staff.take(6)
            val maxLoad = (topStaff.maxOfOrNull { it.activeLoad } ?: 1).coerceAtLeast(1)
            if (topStaff.isEmpty()) {
                Text("No active task assignments.", style = MaterialTheme.typography.bodySmall)
            } else {
                topStaff.forEach { member ->
                    val ratio = (member.activeLoad.toFloat() / maxLoad.toFloat()).coerceIn(0.05f, 1f)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = member.employeeName,
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${member.role.displayName} · ${member.hubLocation}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = "${member.activeLoad} open / ${member.completedTasks} done",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { ratio },
                        color = if (member.activeLoad > 12) AlertCrimson600 else ClearedEmerald600,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
fun ActionFeedbackBanner(
    isSuccess: Boolean,
    message: String,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (isSuccess) ClearedEmerald100 else AlertCrimson100
    val fg = if (isSuccess) ClearedEmerald600 else AlertCrimson600
    Surface(
        color = bg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.4f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Icon(
                imageVector = if (isSuccess) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                contentDescription = if (isSuccess) "Success" else "Error",
                tint = fg,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = fg,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Dismiss notification", tint = fg, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun LoadingPanel(label: String = "Loading logistics telemetry...") {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(strokeWidth = 3.dp)
        Spacer(Modifier.height(12.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun EmptyStatePanel(
    title: String,
    subtitle: String,
    icon: ImageVector = Icons.Default.LocalShipping
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ErrorStatePanel(message: String) {
    Surface(
        color = AlertCrimson100,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, AlertCrimson600.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.WarningAmber,
                contentDescription = "Error",
                tint = AlertCrimson600,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = AlertCrimson600
            )
        }
    }
}

@Composable
fun InfoCallout(message: String) {
    Surface(
        color = TelemetryBlue100.copy(alpha = 0.65f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Information",
                tint = TelemetryBlue600,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = MaritimeNavy900
            )
        }
    }
}
