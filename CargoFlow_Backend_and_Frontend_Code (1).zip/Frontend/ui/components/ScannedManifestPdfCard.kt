package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.CargoStatus
import com.example.domain.GeneratedManifestPdf
import com.example.domain.ScannedManifestItem
import com.example.ui.theme.AlertCrimson100
import com.example.ui.theme.AlertCrimson600
import com.example.ui.theme.ClearedEmerald100
import com.example.ui.theme.ClearedEmerald600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber100
import com.example.ui.theme.LogisticsAmber500
import com.example.ui.theme.MaritimeNavy800
import com.example.ui.theme.MaritimeNavy900
import com.example.ui.theme.MaritimeNavy950
import com.example.ui.theme.TelemetryBlue100
import com.example.ui.theme.TelemetryBlue400
import com.example.ui.theme.TelemetryBlue600
import com.example.ui.viewmodel.UiState
import java.util.Locale

@Composable
fun ScannedManifestPdfCard(
    items: List<ScannedManifestItem>,
    pdfState: UiState<GeneratedManifestPdf>,
    onRemoveItem: (String) -> Unit,
    onClearItems: () -> Unit,
    onGeneratePdf: (recipientEmail: String, notes: String) -> Unit,
    onEmailPdf: (pdf: GeneratedManifestPdf, recipientEmail: String) -> Unit,
    onSharePdf: (pdf: GeneratedManifestPdf, recipientEmail: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var recipientEmail by rememberSaveable { mutableStateOf("") }
    var dispatchNotes by rememberSaveable { mutableStateOf("") }

    val totalWeightKg = items.sumOf { it.weightKg }
    val fragileCount = items.count { it.fragile }
    val isGenerating = pdfState is UiState.Loading

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (items.isNotEmpty()) 1.5.dp else 1.dp,
            color = if (items.isNotEmpty()) LogisticsAmber500.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outline
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("scanned_manifest_pdf_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = MaritimeNavy900,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = stringResource(R.string.manifest_pdf_icon_cd),
                                tint = LogisticsAmber500,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.manifest_pdf_title),
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (items.isNotEmpty()) {
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "%d scanned · %.1f kg%s",
                                    items.size,
                                    totalWeightKg,
                                    if (fragileCount > 0) " · $fragileCount fragile" else ""
                                ),
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                color = TelemetryBlue600
                            )
                        } else {
                            Text(
                                text = "0 items queued",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (items.isNotEmpty()) {
                    TextButton(
                        onClick = onClearItems,
                        modifier = Modifier.testTag("manifest_clear_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = stringResource(R.string.manifest_pdf_clear_btn),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.manifest_pdf_clear_btn))
                    }
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                text = if (items.isEmpty()) {
                    stringResource(R.string.manifest_pdf_empty_hint)
                } else {
                    stringResource(R.string.manifest_pdf_subtitle)
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (items.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                Spacer(Modifier.height(8.dp))

                // Scanned items manifest queue
                items.forEachIndexed { idx, item ->
                    ScannedManifestItemRow(
                        index = idx + 1,
                        item = item,
                        onRemove = { onRemoveItem(item.key) }
                    )
                    if (idx < items.lastIndex) {
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Recipient email + optional notes
                OutlinedTextField(
                    value = recipientEmail,
                    onValueChange = { recipientEmail = it },
                    label = { Text(stringResource(R.string.manifest_pdf_recipient_label)) },
                    placeholder = { Text(stringResource(R.string.manifest_pdf_recipient_placeholder)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("manifest_recipient_email_input")
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = dispatchNotes,
                    onValueChange = { dispatchNotes = it },
                    label = { Text(stringResource(R.string.manifest_pdf_notes_label)) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("manifest_notes_input")
                )

                Spacer(Modifier.height(12.dp))

                // Generate PDF CTA
                Button(
                    onClick = { onGeneratePdf(recipientEmail, dispatchNotes) },
                    enabled = !isGenerating,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("generate_manifest_pdf_button")
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(stringResource(R.string.manifest_pdf_generating))
                    } else {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("${stringResource(R.string.manifest_pdf_generate_btn)} (${items.size})")
                    }
                }
            }

            // Error state if generation failed
            if (pdfState is UiState.Error) {
                Spacer(Modifier.height(10.dp))
                ErrorStatePanel(message = pdfState.message)
            }

            // Generated PDF Ready Panel with Email & Share Intents
            if (pdfState is UiState.Success) {
                val pdf = pdfState.data
                Spacer(Modifier.height(14.dp))
                GeneratedManifestReadyPanel(
                    pdf = pdf,
                    onEmail = { onEmailPdf(pdf, recipientEmail) },
                    onShare = { onSharePdf(pdf, recipientEmail) }
                )
            }
        }
    }
}

@Composable
private fun ScannedManifestItemRow(
    index: Int,
    item: ScannedManifestItem,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            color = TelemetryBlue100,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.size(26.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = String.format(Locale.US, "%02d", index),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold
                    ),
                    color = TelemetryBlue600
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = item.trackingNumber,
                    style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (item.fragile) {
                    Surface(
                        color = AlertCrimson100,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = "Fragile",
                                tint = AlertCrimson600,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(Modifier.width(2.dp))
                            Text(
                                text = "FRAGILE",
                                style = MaterialTheme.typography.labelSmall,
                                color = AlertCrimson600
                            )
                        }
                    }
                }
            }
            Text(
                text = "${item.originHub} -> ${item.destination}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val metaLine = buildString {
                item.packageCode?.let { append("$it · ") }
                append(CargoStatus.fromNameSafe(item.status).displayLabel)
                append(" · ")
                append(String.format(Locale.US, "%.1f kg", item.weightKg))
                item.binLocation?.let { append(" · $it") }
            }
            Text(
                text = metaLine,
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(
            onClick = onRemove,
            modifier = Modifier
                .size(48.dp)
                .testTag("manifest_remove_${item.key}")
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = stringResource(R.string.manifest_pdf_remove_item_cd),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun GeneratedManifestReadyPanel(
    pdf: GeneratedManifestPdf,
    onEmail: () -> Unit,
    onShare: () -> Unit
) {
    val sizeKb = (pdf.fileSizeBytes / 1024.0).coerceAtLeast(0.1)

    Surface(
        color = MaritimeNavy900,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, LogisticsAmber500.copy(alpha = 0.7f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("manifest_pdf_ready_panel")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = ClearedEmerald600,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = pdf.manifestNumber,
                        style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = Color.White
                    )
                }
                Surface(
                    color = ClearedEmerald100,
                    shape = RoundedCornerShape(100)
                ) {
                    Text(
                        text = String.format(Locale.US, "PDF · %.1f KB", sizeKb),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = ClearedEmerald600,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                text = pdf.fileName,
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                color = TelemetryBlue400,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "SHA-256: ${pdf.sha256Fingerprint.take(24)}… · ${pdf.itemCount} unit(s) · ${
                    String.format(Locale.US, "%.1f kg", pdf.totalWeightKg)
                }",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                color = Color.White.copy(alpha = 0.72f)
            )

            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onEmail,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = LogisticsAmber500,
                        contentColor = MaritimeNavy950
                    ),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(48.dp)
                        .testTag("email_manifest_pdf_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.manifest_pdf_email_btn),
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onShare,
                    border = BorderStroke(1.dp, TelemetryBlue400.copy(alpha = 0.7f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier
                        .weight(0.9f)
                        .height(48.dp)
                        .testTag("share_manifest_pdf_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = null,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.manifest_pdf_share_btn))
                }
            }
        }
    }
}
