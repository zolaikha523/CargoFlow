package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.view.MotionEvent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.scanner.CargoBarcodeFrameAnalyzer
import com.example.ui.theme.ClearedEmerald600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber500
import com.example.ui.theme.MaritimeNavy900
import com.example.ui.theme.MaritimeNavy950
import kotlinx.coroutines.delay
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Reusable CameraX Compose QR/Barcode Scanner component.
 * Binds both CameraX Preview and ImageAnalysis with CargoBarcodeFrameAnalyzer,
 * supporting torch toggle, tap-to-focus, pause/resume, animated reticle sweep,
 * runtime CAMERA permission handling, and automatic lifecycle cleanup.
 */
@Composable
fun CargoCameraScannerView(
    onBarcodeDetected: (String) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 250.dp,
    autoStartWhenPermitted: Boolean = false
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnDetected by rememberUpdatedState(onBarcodeDetected)

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var cameraActive by remember { mutableStateOf(hasCameraPermission && autoStartWhenPermitted) }
    var isAnalyzing by remember { mutableStateOf(true) }
    var torchEnabled by remember { mutableStateOf(false) }
    var hasFlashUnit by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var liveFps by remember { mutableIntStateOf(0) }
    var contrastLocked by remember { mutableStateOf(false) }
    var lastDetectedFlashCode by remember { mutableStateOf<String?>(null) }
    var boundCamera by remember { mutableStateOf<Camera?>(null) }

    val latestAnalyzing by rememberUpdatedState(isAnalyzing)

    LaunchedEffect(lastDetectedFlashCode) {
        if (lastDetectedFlashCode != null) {
            delay(1_400L)
            lastDetectedFlashCode = null
        }
    }

    LaunchedEffect(torchEnabled, boundCamera) {
        boundCamera?.let { cam ->
            if (cam.cameraInfo.hasFlashUnit()) {
                cam.cameraControl.enableTorch(torchEnabled)
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (granted) {
            cameraError = null
            cameraActive = true
            isAnalyzing = true
        } else {
            cameraError = "Camera permission denied. Grant CAMERA permission or enter a barcode manually."
        }
    }

    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    val cameraProviderRef = remember { mutableStateOf<ProcessCameraProvider?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { cameraProviderRef.value?.unbindAll() }
            analysisExecutor.shutdown()
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaritimeNavy900),
        border = BorderStroke(
            width = if (lastDetectedFlashCode != null) 2.5.dp else 1.dp,
            color = if (lastDetectedFlashCode != null) ClearedEmerald600 else Color(0xFF2E4365)
        ),
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .testTag("camerax_scanner_view")
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (hasCameraPermission && cameraActive && cameraError == null) {
                val mainExecutor = remember(context) { ContextCompat.getMainExecutor(context) }

                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply {
                            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                        }

                        previewView.setOnTouchListener { view, event ->
                            if (event.action == MotionEvent.ACTION_UP) {
                                boundCamera?.let { cam ->
                                    val point = previewView.meteringPointFactory.createPoint(event.x, event.y)
                                    val action = FocusMeteringAction.Builder(point)
                                        .setAutoCancelDuration(3, TimeUnit.SECONDS)
                                        .build()
                                    cam.cameraControl.startFocusAndMetering(action)
                                }
                                view.performClick()
                            }
                            true
                        }

                        val providerFuture = ProcessCameraProvider.getInstance(ctx)
                        providerFuture.addListener({
                            try {
                                val provider = providerFuture.get()
                                cameraProviderRef.value = provider

                                val preview = Preview.Builder().build().also {
                                    it.surfaceProvider = previewView.surfaceProvider
                                }

                                val imageAnalysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                                    .build()
                                    .also { analysis ->
                                        analysis.setAnalyzer(
                                            analysisExecutor,
                                            CargoBarcodeFrameAnalyzer(
                                                isEnabledProvider = { latestAnalyzing },
                                                onIdentifierDetected = { code ->
                                                    mainExecutor.execute {
                                                        lastDetectedFlashCode = code
                                                        latestOnDetected(code)
                                                    }
                                                },
                                                onFrameTelemetry = { fps, contrastOk ->
                                                    mainExecutor.execute {
                                                        liveFps = fps
                                                        contrastLocked = contrastOk
                                                    }
                                                }
                                            )
                                        )
                                    }

                                val selector = when {
                                    provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) -> CameraSelector.DEFAULT_BACK_CAMERA
                                    provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) -> CameraSelector.DEFAULT_FRONT_CAMERA
                                    else -> {
                                        cameraError = "No camera hardware available on this device."
                                        return@addListener
                                    }
                                }

                                provider.unbindAll()
                                val camera = provider.bindToLifecycle(
                                    lifecycleOwner,
                                    selector,
                                    preview,
                                    imageAnalysis
                                )
                                boundCamera = camera
                                hasFlashUnit = camera.cameraInfo.hasFlashUnit()
                            } catch (e: Exception) {
                                cameraError = "Unable to initialize CameraX stream: ${e.localizedMessage ?: "Camera unavailable"}"
                            }
                        }, mainExecutor)

                        previewView
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(16.dp))
                )

                // Optical Reticle & Animated Laser Overlay
                ScannerReticleOverlay(
                    isAnalyzing = isAnalyzing,
                    detected = lastDetectedFlashCode != null,
                    modifier = Modifier.fillMaxSize()
                )

                // Top Telemetry Bar
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = MaritimeNavy950.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            lastDetectedFlashCode != null -> ClearedEmerald600
                                            !isAnalyzing -> Color(0xFF94A3B8)
                                            contrastLocked -> LogisticsAmber500
                                            else -> Color(0xFF60A5FA)
                                        }
                                    )
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = when {
                                    lastDetectedFlashCode != null -> "READ: $lastDetectedFlashCode"
                                    !isAnalyzing -> "PAUSED"
                                    else -> "LIVE ${if (liveFps > 0) "${liveFps}FPS" else "YUV"} · CODE-128"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                color = Color.White
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (hasFlashUnit) {
                            IconButton(
                                onClick = { torchEnabled = !torchEnabled },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaritimeNavy950.copy(alpha = 0.75f))
                                    .testTag("scanner_torch_toggle")
                            ) {
                                Icon(
                                    imageVector = if (torchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                    contentDescription = if (torchEnabled) "Disable flashlight" else "Enable flashlight",
                                    tint = if (torchEnabled) LogisticsAmber500 else Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = { isAnalyzing = !isAnalyzing },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaritimeNavy950.copy(alpha = 0.75f))
                                .testTag("scanner_pause_resume_toggle")
                        ) {
                            Icon(
                                imageVector = if (isAnalyzing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isAnalyzing) "Pause scanner" else "Resume scanner",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Bottom Hint
                Surface(
                    color = MaritimeNavy950.copy(alpha = 0.72f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp)
                ) {
                    Text(
                        text = "Align shipment Code-128 barcode inside frame · Tap to focus",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFE2E8F0),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(20.dp)
                ) {
                    Icon(
                        Icons.Default.QrCodeScanner,
                        contentDescription = "CameraX Optical Scanner",
                        tint = LogisticsAmber500,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "CameraX Live Barcode Analyzer",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = cameraError ?: "Streams YUV_420_888 frames to decode Code-128 shipment & package identifiers automatically.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8)
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            cameraError = null
                            if (hasCameraPermission) {
                                cameraActive = true
                                isAnalyzing = true
                            } else {
                                permissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LogisticsAmber500,
                            contentColor = MaritimeNavy950
                        ),
                        modifier = Modifier.testTag("enable_camera_scanner_button")
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (hasCameraPermission) "Start Live Camera Scanner" else "Grant Camera & Scan")
                    }
                }
            }
        }
    }
}

@Composable
private fun ScannerReticleOverlay(
    isAnalyzing: Boolean,
    detected: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "laser_sweep")
    val sweepFraction by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    Canvas(modifier = modifier) {
        val boxW = size.width * 0.78f
        val boxH = size.height * 0.48f
        val left = (size.width - boxW) / 2f
        val top = (size.height - boxH) / 2f
        val right = left + boxW
        val bottom = top + boxH
        val cornerLen = 26.dp.toPx()
        val stroke = 3.dp.toPx()
        val bracketColor = if (detected) ClearedEmerald600 else LogisticsAmber500

        // Corner brackets (Top-Left, Top-Right, Bottom-Left, Bottom-Right)
        drawLine(bracketColor, Offset(left, top), Offset(left + cornerLen, top), stroke, StrokeCap.Round)
        drawLine(bracketColor, Offset(left, top), Offset(left, top + cornerLen), stroke, StrokeCap.Round)

        drawLine(bracketColor, Offset(right, top), Offset(right - cornerLen, top), stroke, StrokeCap.Round)
        drawLine(bracketColor, Offset(right, top), Offset(right, top + cornerLen), stroke, StrokeCap.Round)

        drawLine(bracketColor, Offset(left, bottom), Offset(left + cornerLen, bottom), stroke, StrokeCap.Round)
        drawLine(bracketColor, Offset(left, bottom), Offset(left, bottom - cornerLen), stroke, StrokeCap.Round)

        drawLine(bracketColor, Offset(right, bottom), Offset(right - cornerLen, bottom), stroke, StrokeCap.Round)
        drawLine(bracketColor, Offset(right, bottom), Offset(right, bottom - cornerLen), stroke, StrokeCap.Round)

        // Sweeping scan laser line
        if (isAnalyzing) {
            val laserY = top + boxH * sweepFraction
            drawLine(
                color = if (detected) ClearedEmerald600 else LogisticsAmber500.copy(alpha = 0.85f),
                start = Offset(left + 12f, laserY),
                end = Offset(right - 12f, laserY),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

/**
 * Compact modal wrapper around CargoCameraScannerView for triggering instant barcode lookups
 * from screens like the Public Tracking Portal.
 */
@Composable
fun CargoCameraScannerDialog(
    title: String = "Scan Shipment Barcode",
    onDismiss: () -> Unit,
    onCodeScanned: (String) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close scanner")
                    }
                }
                Spacer(Modifier.height(8.dp))
                CargoCameraScannerView(
                    onBarcodeDetected = { code ->
                        onCodeScanned(code)
                        onDismiss()
                    },
                    height = 260.dp,
                    autoStartWhenPermitted = true
                )
            }
        }
    }
}
