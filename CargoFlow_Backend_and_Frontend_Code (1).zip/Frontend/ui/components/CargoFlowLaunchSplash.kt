package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ClearedEmerald600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber100
import com.example.ui.theme.LogisticsAmber500
import com.example.ui.theme.LogisticsAmber600
import com.example.ui.theme.MaritimeNavy700
import com.example.ui.theme.MaritimeNavy800
import com.example.ui.theme.MaritimeNavy900
import com.example.ui.theme.MaritimeNavy950
import com.example.ui.theme.SlateInk400
import com.example.ui.theme.SpaceGroteskFamily
import com.example.ui.theme.TelemetryBlue400
import com.example.ui.theme.TelemetryBlue600
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Animated CargoFlow brand launch overlay.
 * Choreographs a spring logo reveal, ambient freight telemetry rings, and a smooth
 * loading bar synchronized with backend/Room bootstrapping before handing off to Sign-In.
 */
@Composable
fun CargoFlowLaunchSplash(
    isBootstrapping: Boolean,
    onSplashComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val latestBootstrapping by rememberUpdatedState(isBootstrapping)
    val latestOnComplete by rememberUpdatedState(onSplashComplete)

    val logoScale = remember { Animatable(0.72f) }
    val logoAlpha = remember { Animatable(0f) }
    val titleAlpha = remember { Animatable(0f) }
    val titleTranslationY = remember { Animatable(24f) }
    val subtitleAlpha = remember { Animatable(0f) }
    val progressBarAlpha = remember { Animatable(0f) }
    val loadingProgress = remember { Animatable(0f) }
    val sheenProgress = remember { Animatable(-0.6f) }

    var stageIndex by remember { mutableIntStateOf(0) }

    val infiniteTransition = rememberInfiniteTransition(label = "cargoflow_splash_ambient")
    val radarSweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_sweep_angle"
    )
    val ringPulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_pulse"
    )
    val logoBreath by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.028f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo_breath"
    )

    LaunchedEffect(Unit) {
        // Phase 1: Logo emblem springs smoothly into focus
        launch {
            logoAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing)
            )
        }
        launch {
            logoScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = 0.66f, stiffness = 210f)
            )
        }
        // Subtle metallic light sheen glides across the logo emblem once settled
        launch {
            delay(420)
            sheenProgress.animateTo(
                targetValue = 1.6f,
                animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing)
            )
        }

        // Phase 2: Brand wordmark & tagline reveal
        launch {
            delay(180)
            launch {
                titleAlpha.animateTo(
                    targetValue = 1f,
                    animationSpec = tween(durationMillis = 480, easing = FastOutSlowInEasing)
                )
            }
            launch {
                titleTranslationY.animateTo(
                    targetValue = 0f,
                    animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing)
                )
            }
        }
        launch {
            delay(340)
            subtitleAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 460, easing = FastOutSlowInEasing)
            )
        }
        launch {
            delay(400)
            progressBarAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing)
            )
        }

        // Phase 3: Smooth loading progression synced with actual app bootstrap
        stageIndex = 0
        loadingProgress.animateTo(
            targetValue = 0.44f,
            animationSpec = tween(durationMillis = 620, easing = FastOutSlowInEasing)
        )

        stageIndex = 1
        loadingProgress.animateTo(
            targetValue = 0.84f,
            animationSpec = tween(durationMillis = 640, easing = FastOutSlowInEasing)
        )

        // Ensure Room database & profile bootstrap have fully completed before reaching 100%
        if (latestBootstrapping) {
            snapshotFlow { latestBootstrapping }.first { !it }
        }

        stageIndex = 2
        loadingProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 360, easing = FastOutSlowInEasing)
        )
        delay(220)
        latestOnComplete()
    }

    val stageLabel = when (stageIndex) {
        0 -> stringResource(R.string.splash_stage_init)
        1 -> stringResource(R.string.splash_stage_security)
        else -> stringResource(R.string.splash_stage_ready)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("launch_splash_screen")
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaritimeNavy950,
                        MaritimeNavy900,
                        MaritimeNavy950
                    )
                )
            )
    ) {
        // Ambient precision freight telemetry backdrop (radar rings, orbital arc, subtle grid)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.5f, size.height * 0.44f)
            val minDim = size.minDimension

            // Soft dual-tone atmospheric glow behind the CargoFlow emblem
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LogisticsAmber500.copy(alpha = 0.16f * logoAlpha.value),
                        TelemetryBlue600.copy(alpha = 0.08f * logoAlpha.value),
                        Color.Transparent
                    ),
                    center = center,
                    radius = minDim * 0.56f
                ),
                radius = minDim * 0.56f,
                center = center
            )

            // Subtle architectural telemetry grid
            val gridStep = 44.dp.toPx()
            val dotColor = TelemetryBlue400.copy(alpha = 0.06f)
            var y = gridStep
            while (y < size.height) {
                var x = gridStep
                while (x < size.width) {
                    drawCircle(color = dotColor, radius = 1.2.dp.toPx(), center = Offset(x, y))
                    x += gridStep
                }
                y += gridStep
            }

            // Concentric static precision orbit tracks
            val innerOrbitRadius = 92.dp.toPx()
            val outerOrbitRadius = 128.dp.toPx()
            drawCircle(
                color = MaritimeNavy700.copy(alpha = 0.55f * logoAlpha.value),
                radius = innerOrbitRadius,
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )
            drawCircle(
                color = MaritimeNavy700.copy(alpha = 0.32f * logoAlpha.value),
                radius = outerOrbitRadius,
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )

            // Expanding telemetry pulse wave
            val pulseRadius = innerOrbitRadius + (outerOrbitRadius * 0.55f) * ringPulse
            val pulseAlpha = (1f - ringPulse).coerceIn(0f, 1f) * 0.34f * logoAlpha.value
            drawCircle(
                color = LogisticsAmber500.copy(alpha = pulseAlpha),
                radius = pulseRadius,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Rotating telemetry sweep arcs around the logo
            val arcDiameter = innerOrbitRadius * 2f
            val arcTopLeft = Offset(center.x - innerOrbitRadius, center.y - innerOrbitRadius)
            drawArc(
                color = LogisticsAmber500.copy(alpha = 0.72f * logoAlpha.value),
                startAngle = radarSweepAngle,
                sweepAngle = 62f,
                useCenter = false,
                topLeft = arcTopLeft,
                size = Size(arcDiameter, arcDiameter),
                style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
            )
            drawArc(
                color = TelemetryBlue400.copy(alpha = 0.5f * logoAlpha.value),
                startAngle = radarSweepAngle + 180f,
                sweepAngle = 44f,
                useCenter = false,
                topLeft = arcTopLeft,
                size = Size(arcDiameter, arcDiameter),
                style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        // Main brand focal stack & bottom smooth loading bar
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 32.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Centered CargoFlow Logo + Wordmark lockup
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 24.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(136.dp)
                        .graphicsLayer {
                            val combinedScale = logoScale.value * logoBreath
                            scaleX = combinedScale
                            scaleY = combinedScale
                            alpha = logoAlpha.value
                        }
                        .shadow(
                            elevation = 24.dp,
                            shape = RoundedCornerShape(32.dp),
                            ambientColor = LogisticsAmber500.copy(alpha = 0.45f),
                            spotColor = LogisticsAmber500.copy(alpha = 0.55f)
                        )
                        .clip(RoundedCornerShape(32.dp))
                        .background(MaritimeNavy900)
                        .border(
                            width = 1.5.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    LogisticsAmber500.copy(alpha = 0.9f),
                                    TelemetryBlue400.copy(alpha = 0.45f),
                                    LogisticsAmber600.copy(alpha = 0.8f)
                                )
                            ),
                            shape = RoundedCornerShape(32.dp)
                        )
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.cargoflow_icon_fg_1795165391869),
                        contentDescription = stringResource(R.string.splash_logo_cd),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("launch_splash_logo")
                    )

                    // Diagonal specular sheen overlay
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val sheenX = size.width * sheenProgress.value
                        val bandWidth = size.width * 0.42f
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.22f),
                                    Color.Transparent
                                ),
                                start = Offset(sheenX - bandWidth, 0f),
                                end = Offset(sheenX + bandWidth, size.height)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                Text(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(color = Color.White)) {
                            append("Cargo")
                        }
                        withStyle(SpanStyle(color = LogisticsAmber500)) {
                            append("Flow")
                        }
                    },
                    fontFamily = SpaceGroteskFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 36.sp,
                    letterSpacing = (-0.8).sp,
                    modifier = Modifier
                        .graphicsLayer {
                            alpha = titleAlpha.value
                            translationY = titleTranslationY.value
                        }
                        .testTag("launch_splash_title")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = stringResource(R.string.splash_tagline),
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp,
                    letterSpacing = 2.6.sp,
                    color = TelemetryBlue400.copy(alpha = 0.9f),
                    modifier = Modifier.alpha(subtitleAlpha.value)
                )
            }

            // Smooth bottom telemetry loader
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 300.dp)
                    .alpha(progressBarAlpha.value)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(
                                    if (stageIndex == 2) ClearedEmerald600 else LogisticsAmber500
                                )
                        )
                        AnimatedContent(
                            targetState = stageLabel,
                            transitionSpec = {
                                fadeIn(tween(240)) togetherWith fadeOut(tween(180))
                            },
                            label = "splash_stage_text"
                        ) { label ->
                            Text(
                                text = label,
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.82f)
                            )
                        }
                    }

                    Text(
                        text = "${(loadingProgress.value * 100f).roundToInt()}%",
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = LogisticsAmber500
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Sleek gradient progress track
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(100))
                        .background(MaritimeNavy800)
                        .border(
                            width = 0.5.dp,
                            color = MaritimeNavy700,
                            shape = RoundedCornerShape(100)
                        )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(fraction = loadingProgress.value.coerceIn(0f, 1f))
                            .clip(RoundedCornerShape(100))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        LogisticsAmber600,
                                        LogisticsAmber500,
                                        LogisticsAmber100
                                    )
                                )
                            )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = stringResource(R.string.splash_footer_badge),
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 9.5.sp,
                    letterSpacing = 1.8.sp,
                    color = SlateInk400.copy(alpha = 0.65f)
                )
            }
        }
    }
}
