package com.example.ui.operations

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.CargoStatus
import com.example.domain.DashboardMetrics
import com.example.domain.Permission
import com.example.domain.RbacPolicyEngine
import com.example.ui.components.CargoStatusBadge
import com.example.ui.components.ErrorStatePanel
import com.example.ui.components.KpiMetricCard
import com.example.ui.components.LoadingPanel
import com.example.ui.components.StaffWorkloadPanel
import com.example.ui.components.WarehouseUtilizationPanel
import com.example.ui.theme.AlertCrimson600
import com.example.ui.theme.ClearedEmerald600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber600
import com.example.ui.theme.TelemetryBlue600
import com.example.ui.viewmodel.CargoFlowViewModel
import com.example.ui.viewmodel.UiState

@Composable
fun DashboardScreen(
    viewModel: CargoFlowViewModel,
    onFilterShipmentsByStatus: (CargoStatus?) -> Unit
) {
    val dashState by viewModel.dashboardState.collectAsStateWithLifecycle()
    val session by viewModel.session.collectAsStateWithLifecycle()
    val auditValid by viewModel.auditChainValid.collectAsStateWithLifecycle()

    val canViewAudit = session?.let {
        RbacPolicyEngine.hasPermission(it.role, Permission.VIEW_AUDIT_LOGS)
    } == true
    val canViewInventory = session?.let {
        RbacPolicyEngine.hasPermission(it.role, Permission.VIEW_INVENTORY)
    } == true

    when (val state = dashState) {
        UiState.Idle, UiState.Loading -> LoadingPanel("Aggregating real-time fleet & warehouse telemetry...")
        is UiState.Error -> Column(Modifier.padding(16.dp)) { ErrorStatePanel(state.message) }
        is UiState.Success -> {
            DashboardContent(
                metrics = state.data,
                canViewAudit = canViewAudit,
                canViewInventory = canViewInventory,
                auditValid = auditValid,
                onRefresh = { viewModel.refreshDashboard() },
                onFilterShipmentsByStatus = onFilterShipmentsByStatus
            )
        }
    }
}

@Composable
private fun DashboardContent(
    metrics: DashboardMetrics,
    canViewAudit: Boolean,
    canViewInventory: Boolean,
    auditValid: Boolean?,
    onRefresh: () -> Unit,
    onFilterShipmentsByStatus: (CargoStatus?) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("ops_dashboard_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Operations Command Center", style = MaterialTheme.typography.headlineSmall)
                    if (canViewAudit) {
                        Text(
                            "${metrics.totalRecordsAcrossTables} indexed records · Audit Chain: ${
                                when (auditValid) {
                                    true -> "VERIFIED (SHA-256)"
                                    false -> "TAMPER ALERT"
                                    null -> "CHECKING"
                                }
                            }",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (auditValid == false) AlertCrimson600 else ClearedEmerald600
                        )
                    } else {
                        Text(
                            "${metrics.totalShipments} active & archived manifests · Live operational telemetry",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onRefresh, modifier = Modifier.testTag("dashboard_refresh_button")) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh dashboard")
                }
            }
        }

        // Primary 2x2 KPI Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiMetricCard(
                        title = "Active Shipments",
                        value = metrics.activeShipments.toString(),
                        subtitle = "${metrics.totalShipments} total · ${metrics.deliveredShipments} delivered",
                        icon = Icons.Default.LocalShipping,
                        accentColor = TelemetryBlue600,
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        title = "Delayed / SLA Risk",
                        value = "${metrics.delayedShipments} / ${metrics.pendingSlaBreachCount}",
                        subtitle = "${metrics.onHoldShipments} on customs/hold",
                        icon = Icons.Default.WarningAmber,
                        accentColor = AlertCrimson600,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (canViewInventory) {
                        KpiMetricCard(
                            title = "Warehouse Inventory",
                            value = metrics.warehousePackages.toString(),
                            subtitle = "${metrics.totalPackages} total packages tracked",
                            icon = Icons.Default.Inventory2,
                            accentColor = LogisticsAmber600,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        KpiMetricCard(
                            title = "Corporate Clients",
                            value = metrics.totalCustomers.toString(),
                            subtitle = "${metrics.totalShipments} manifests booked",
                            icon = Icons.Default.LocalShipping,
                            accentColor = LogisticsAmber600,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    KpiMetricCard(
                        title = "Open Staff Tasks",
                        value = metrics.openTasks.toString(),
                        subtitle = "${metrics.activeEmployees} active staff · ${metrics.totalCustomers} clients",
                        icon = Icons.Default.Assignment,
                        accentColor = ClearedEmerald600,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Lifecycle Pipeline Status Breakdown
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Cargo Lifecycle Distribution", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Tap any status row to filter shipments table",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    val orderedStates = listOf(
                        CargoStatus.CREATED,
                        CargoStatus.RECEIVED,
                        CargoStatus.WAREHOUSE,
                        CargoStatus.ON_HOLD,
                        CargoStatus.DISPATCHED,
                        CargoStatus.IN_TRANSIT,
                        CargoStatus.OUT_FOR_DELIVERY,
                        CargoStatus.DELAYED,
                        CargoStatus.DELIVERED
                    )
                    orderedStates.forEach { st ->
                        val count = metrics.statusBreakdown[st] ?: 0
                        Surface(
                            onClick = { onFilterShipmentsByStatus(st) },
                            color = Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CargoStatusBadge(status = st)
                                Text(
                                    text = "$count manifests",
                                    style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Warehouse Zone Utilization Chart (Admin & Ops Manager only)
        if (canViewInventory && metrics.warehouseZones.isNotEmpty()) {
            item {
                WarehouseUtilizationPanel(zones = metrics.warehouseZones)
            }
        }

        // Staff Workload Chart
        item {
            StaffWorkloadPanel(staff = metrics.staffWorkload)
        }
    }
}
