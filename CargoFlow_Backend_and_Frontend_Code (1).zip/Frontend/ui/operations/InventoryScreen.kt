package com.example.ui.operations

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.PackageEntity
import com.example.data.local.ShipmentSummaryRow
import com.example.domain.CargoStatus
import com.example.domain.Permission
import com.example.domain.RbacPolicyEngine
import com.example.ui.components.CargoStatusBadge
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.ShippingLabelDialog
import com.example.ui.theme.AlertCrimson100
import com.example.ui.theme.AlertCrimson600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.viewmodel.CargoFlowViewModel

@Composable
fun InventoryScreen(viewModel: CargoFlowViewModel) {
    val packages by viewModel.inventoryPackages.collectAsStateWithLifecycle()
    val shipments by viewModel.shipments.collectAsStateWithLifecycle()
    val zoneFilter by viewModel.inventoryZoneFilter.collectAsStateWithLifecycle()
    val query by viewModel.inventorySearchQuery.collectAsStateWithLifecycle()
    val session by viewModel.session.collectAsStateWithLifecycle()

    val canManageInventory = session?.let {
        RbacPolicyEngine.hasPermission(it.role, Permission.MANAGE_PACKAGES_INVENTORY)
    } == true

    var selectedPackage by remember { mutableStateOf<PackageEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val zones = listOf("", "ZONE-A", "ZONE-B", "ZONE-C", "ZONE-COLD", "ZONE-HAZMAT", "ZONE-EXPRESS")

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { viewModel.setInventorySearchQuery(it) },
                    label = { Text("Search package code, SKU, or description") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search inventory") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("inventory_search_input")
                )
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(zones) { z ->
                        FilterChip(
                            selected = zoneFilter == z,
                            onClick = { viewModel.setInventoryZoneFilter(z) },
                            label = { Text(if (z.isBlank()) "All Zones" else z) }
                        )
                    }
                }
            }

            if (packages.isEmpty()) {
                Box(Modifier.padding(16.dp)) {
                    EmptyStatePanel(
                        title = "No packages found in zone",
                        subtitle = "Clear filters or register a new package into a shipment.",
                        icon = Icons.Default.Inventory2
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 84.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(packages, key = { it.id }) { pkg ->
                        PackageInventoryCard(
                            pkg = pkg,
                            onClick = { selectedPackage = pkg }
                        )
                    }
                }
            }
        }

        if (canManageInventory) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("add_package_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Package to Inventory")
            }
        }
    }

    selectedPackage?.let { pkg ->
        ShippingLabelDialog(
            title = pkg.packageCode,
            code = pkg.barcodeValue,
            qrPayload = pkg.qrPayload,
            subtitle = pkg.description,
            metadataLines = listOf(
                "SKU" to pkg.sku,
                "Warehouse Zone" to pkg.warehouseZone,
                "Bin Location" to pkg.binLocation,
                "Weight / Dims" to "${pkg.weightKg} kg · ${pkg.dimensionsCm} cm",
                "Handling" to if (pkg.fragile) "FRAGILE — HANDLE WITH CARE" else "Standard Freight"
            ),
            onDismiss = { selectedPackage = null }
        )
    }

    if (showAddDialog) {
        AddPackageDialog(
            shipments = shipments,
            onDismiss = { showAddDialog = false },
            onConfirm = { shpId, sku, desc, weight, dims, zone, bin, fragile ->
                viewModel.addPackage(
                    shipmentId = shpId,
                    sku = sku,
                    description = desc,
                    weightKg = weight,
                    dimensionsCm = dims,
                    warehouseZone = zone,
                    binLocation = bin,
                    fragile = fragile
                ) {
                    showAddDialog = false
                }
            }
        )
    }
}

@Composable
private fun PackageInventoryCard(
    pkg: PackageEntity,
    onClick: () -> Unit
) {
    val status = CargoStatus.fromNameSafe(pkg.status)
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    pkg.packageCode,
                    style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFamily)
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (pkg.fragile) {
                        Surface(color = AlertCrimson100, shape = RoundedCornerShape(5.dp)) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.WarningAmber, contentDescription = "Fragile", tint = AlertCrimson600, modifier = Modifier.height(12.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("FRAGILE", style = MaterialTheme.typography.labelSmall, color = AlertCrimson600)
                            }
                        }
                    }
                    CargoStatusBadge(status = status)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(pkg.description, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${pkg.warehouseZone} · Bin ${pkg.binLocation} · ${pkg.sku}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${pkg.weightKg} kg", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Default.QrCode2, contentDescription = "Show package label")
                }
            }
        }
    }
}

@Composable
private fun AddPackageDialog(
    shipments: List<ShipmentSummaryRow>,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, Double, String, String, String, Boolean) -> Unit
) {
    var selectedShipmentId by remember(shipments) { mutableStateOf(shipments.firstOrNull()?.id ?: "") }
    var sku by remember { mutableStateOf("SKU-48210") }
    var description by remember { mutableStateOf("Industrial Thermal Module") }
    var weightStr by remember { mutableStateOf("14.2") }
    var dims by remember { mutableStateOf("45x30x25") }
    var zone by remember { mutableStateOf("ZONE-A") }
    var bin by remember { mutableStateOf("A-R4-B2") }
    var fragile by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Package to Warehouse") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text(
                        "Parent Manifest: ${shipments.firstOrNull { it.id == selectedShipmentId }?.trackingNumber ?: "None"}",
                        style = MaterialTheme.typography.labelLarge
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(shipments.take(6)) { s ->
                            FilterChip(
                                selected = selectedShipmentId == s.id,
                                onClick = { selectedShipmentId = s.id },
                                label = { Text(s.trackingNumber) }
                            )
                        }
                    }
                }
                item {
                    OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                item {
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = weightStr, onValueChange = { weightStr = it }, label = { Text("Weight (kg)") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = dims, onValueChange = { dims = it }, label = { Text("Dims (cm)") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = zone, onValueChange = { zone = it }, label = { Text("Zone") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = bin, onValueChange = { bin = it }, label = { Text("Bin") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = fragile, onCheckedChange = { fragile = it })
                        Text("Fragile / Shock-Sensitive Cargo", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        selectedShipmentId,
                        sku,
                        description,
                        weightStr.toDoubleOrNull() ?: 0.0,
                        dims,
                        zone,
                        bin,
                        fragile
                    )
                },
                modifier = Modifier.testTag("confirm_add_package_button")
            ) {
                Text("Add Package")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
