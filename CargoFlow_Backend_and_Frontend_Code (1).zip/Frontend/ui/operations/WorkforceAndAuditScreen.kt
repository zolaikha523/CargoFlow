package com.example.ui.operations

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AuditLogEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.EmployeeEntity
import com.example.data.local.ShipmentSummaryRow
import com.example.data.local.TaskDetailRow
import com.example.domain.AuditOutcome
import com.example.domain.CustomerTier
import com.example.domain.Permission
import com.example.domain.RbacPolicyEngine
import com.example.domain.TaskPriority
import com.example.domain.TaskStatus
import com.example.domain.UserRole
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.PriorityBadge
import com.example.ui.components.RoleBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AlertCrimson100
import com.example.ui.theme.AlertCrimson600
import com.example.ui.theme.ClearedEmerald100
import com.example.ui.theme.ClearedEmerald600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber100
import com.example.ui.theme.LogisticsAmber600
import com.example.ui.viewmodel.CargoFlowViewModel

@Composable
fun WorkforceAndAuditScreen(viewModel: CargoFlowViewModel) {
    val session by viewModel.session.collectAsStateWithLifecycle()
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val employees by viewModel.employees.collectAsStateWithLifecycle()
    val shipments by viewModel.shipments.collectAsStateWithLifecycle()

    val role = session?.role ?: UserRole.DRIVER
    val canAssignTasks = RbacPolicyEngine.hasPermission(role, Permission.ASSIGN_TASKS)
    val canViewCustomers = RbacPolicyEngine.hasPermission(role, Permission.VIEW_CUSTOMERS)
    val canManageCustomers = RbacPolicyEngine.hasPermission(role, Permission.MANAGE_CUSTOMERS)
    val canViewEmployees = RbacPolicyEngine.hasPermission(role, Permission.VIEW_EMPLOYEES)

    val visibleTabs = remember(role) {
        buildList {
            add("TASKS" to if (canAssignTasks) "Tasks" else "My Tasks")
            if (canViewCustomers) add("CUSTOMERS" to "Customers")
            if (canViewEmployees) add("STAFF" to "Staff")
        }
    }

    var selectedTabKey by rememberSaveable { mutableStateOf("TASKS") }
    LaunchedEffect(session?.employeeId, visibleTabs) {
        if (visibleTabs.none { it.first == selectedTabKey }) {
            selectedTabKey = visibleTabs.first().first
        }
    }
    val activeTabIndex = visibleTabs.indexOfFirst { it.first == selectedTabKey }.coerceAtLeast(0)
    val activeTabKey = visibleTabs[activeTabIndex].first

    var showAssignTaskDialog by remember { mutableStateOf(false) }
    var showCreateCustomerDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            if (visibleTabs.size > 1) {
                ScrollableTabRow(selectedTabIndex = activeTabIndex, edgePadding = 12.dp) {
                    visibleTabs.forEach { (key, title) ->
                        Tab(
                            selected = activeTabKey == key,
                            onClick = { selectedTabKey = key },
                            text = { Text(title) },
                            modifier = Modifier.testTag("ops_subtab_${title.lowercase().replace(" ", "_")}")
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text("My Assigned Tasks", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Scoped to ${session?.fullName ?: "Operator"} (${role.displayName}) — you can only view and update tasks assigned to you.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            when (activeTabKey) {
                "TASKS" -> TasksTab(
                    tasks = tasks,
                    currentEmployeeId = session?.employeeId ?: "",
                    canManageAny = canAssignTasks,
                    onUpdateStatus = { id, status -> viewModel.updateTaskStatus(id, status) }
                )
                "CUSTOMERS" -> CustomersTab(customers = customers)
                "STAFF" -> EmployeesTab(employees = employees)
            }
        }

        if (activeTabKey == "TASKS" && canAssignTasks) {
            FloatingActionButton(
                onClick = { showAssignTaskDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("assign_task_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Assign Task")
            }
        } else if (activeTabKey == "CUSTOMERS" && canManageCustomers) {
            FloatingActionButton(
                onClick = { showCreateCustomerDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("add_customer_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Customer")
            }
        }
    }

    if (showAssignTaskDialog) {
        AssignTaskDialog(
            shipments = shipments,
            employees = employees,
            onDismiss = { showAssignTaskDialog = false },
            onConfirm = { shpId, empId, title, instructions, priority ->
                viewModel.assignTask(shpId, empId, title, instructions, priority) {
                    showAssignTaskDialog = false
                }
            }
        )
    }

    if (showCreateCustomerDialog) {
        CreateCustomerDialog(
            onDismiss = { showCreateCustomerDialog = false },
            onConfirm = { company, contact, email, phone, tier, city, country ->
                viewModel.createCustomer(company, contact, email, phone, tier, city, country) {
                    showCreateCustomerDialog = false
                }
            }
        )
    }
}

@Composable
private fun TasksTab(
    tasks: List<TaskDetailRow>,
    currentEmployeeId: String,
    canManageAny: Boolean,
    onUpdateStatus: (String, TaskStatus) -> Unit
) {
    if (tasks.isEmpty()) {
        Box(Modifier.padding(16.dp)) {
            EmptyStatePanel("No tasks assigned", "Assign shipment tasks to warehouse or fleet personnel.")
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 84.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(tasks, key = { it.id }) { task ->
            val tStatus = TaskStatus.fromNameSafe(task.status)
            val priority = TaskPriority.fromNameSafe(task.priority)
            val canAct = canManageAny || task.assignedToId == currentEmployeeId
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            task.trackingNumber,
                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily)
                        )
                        PriorityBadge(priority = priority)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(task.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        task.instructions,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Assignee: ${task.assigneeName} (${UserRole.fromNameSafe(task.assigneeRole).badgeCode})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            tStatus.label.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (tStatus == TaskStatus.COMPLETED) ClearedEmerald600 else LogisticsAmber600
                        )
                    }
                    if (canAct && tStatus != TaskStatus.COMPLETED) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (tStatus == TaskStatus.PENDING) {
                                OutlinedButton(onClick = { onUpdateStatus(task.id, TaskStatus.IN_PROGRESS) }) {
                                    Text("Start Task")
                                }
                            }
                            Button(onClick = { onUpdateStatus(task.id, TaskStatus.COMPLETED) }) {
                                Text("Mark Completed")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomersTab(customers: List<CustomerEntity>) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 84.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(customers, key = { it.id }) { cust ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Business, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(cust.companyName, style = MaterialTheme.typography.titleSmall)
                            Text(
                                cust.accountCode,
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily)
                            )
                        }
                        Text("${cust.contactName} · ${cust.email}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            "${cust.city}, ${cust.country} · ${cust.phone} · ${cust.tier}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmployeesTab(employees: List<EmployeeEntity>) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(employees, key = { it.id }) { emp ->
            val role = UserRole.fromNameSafe(emp.role)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(emp.fullName, style = MaterialTheme.typography.titleSmall)
                        Text(
                            "${emp.employeeCode} · ${emp.email}",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(emp.hubLocation, style = MaterialTheme.typography.labelSmall)
                    }
                    RoleBadge(role = role)
                }
            }
        }
    }
}

@Composable
private fun RbacRestrictedCard(message: String) {
    Box(modifier = Modifier.padding(16.dp)) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = AlertCrimson100.copy(alpha = 0.6f)),
            border = BorderStroke(1.dp, AlertCrimson600.copy(alpha = 0.4f))
        ) {
            Row(
                modifier = Modifier.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Lock, contentDescription = "Restricted", tint = AlertCrimson600, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("RBAC Access Restricted", style = MaterialTheme.typography.titleMedium, color = AlertCrimson600)
                    Spacer(Modifier.height(4.dp))
                    Text(message, style = MaterialTheme.typography.bodySmall, color = AlertCrimson600)
                }
            }
        }
    }
}

@Composable
private fun AssignTaskDialog(
    shipments: List<ShipmentSummaryRow>,
    employees: List<EmployeeEntity>,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, TaskPriority) -> Unit
) {
    var shipmentId by remember(shipments) { mutableStateOf(shipments.firstOrNull()?.id ?: "") }
    var employeeId by remember(employees) { mutableStateOf(employees.firstOrNull()?.id ?: "") }
    var title by remember { mutableStateOf("Verify Export Customs Seal") }
    var instructions by remember { mutableStateOf("Scan package labels and confirm container door seal.") }
    var priority by remember { mutableStateOf(TaskPriority.HIGH) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Assign Operational Task") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text("Manifest", style = MaterialTheme.typography.labelLarge)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(shipments.take(6)) { s ->
                            FilterChip(selected = shipmentId == s.id, onClick = { shipmentId = s.id }, label = { Text(s.trackingNumber) })
                        }
                    }
                }
                item {
                    Text("Assignee", style = MaterialTheme.typography.labelLarge)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(employees.take(6)) { e ->
                            FilterChip(selected = employeeId == e.id, onClick = { employeeId = e.id }, label = { Text(e.fullName) })
                        }
                    }
                }
                item {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                item {
                    OutlinedTextField(value = instructions, onValueChange = { instructions = it }, label = { Text("SOP Instructions") }, modifier = Modifier.fillMaxWidth())
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(TaskPriority.entries) { p ->
                            FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p.label) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(shipmentId, employeeId, title, instructions, priority) },
                modifier = Modifier.testTag("confirm_assign_task_button")
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Assign")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun CreateCustomerDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, CustomerTier, String, String) -> Unit
) {
    var company by remember { mutableStateOf("Hyperion MedTech GmbH") }
    var contact by remember { mutableStateOf("Dr. Lukas Weber") }
    var email by remember { mutableStateOf("ops@hyperion-medtech.de") }
    var phone by remember { mutableStateOf("+49-89-5550192") }
    var city by remember { mutableStateOf("Munich") }
    var country by remember { mutableStateOf("Germany") }
    var tier by remember { mutableStateOf(CustomerTier.ENTERPRISE) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Register Corporate Customer") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(value = company, onValueChange = { company = it }, label = { Text("Company Name") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("Primary Contact") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Corporate Email") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = country, onValueChange = { country = it }, label = { Text("Country") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(CustomerTier.entries) { t ->
                            FilterChip(selected = tier == t, onClick = { tier = t }, label = { Text(t.label) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(company, contact, email, phone, tier, city, country) },
                modifier = Modifier.testTag("confirm_add_customer_button")
            ) {
                Text("Save Customer")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
