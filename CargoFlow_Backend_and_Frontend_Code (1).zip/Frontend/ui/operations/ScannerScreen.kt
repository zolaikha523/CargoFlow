package com.example.ui.operations

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.CargoStateMachine
import com.example.domain.CargoStatus
import com.example.domain.ManifestShareHelper
import com.example.domain.RbacPolicyEngine
import com.example.domain.UserRole
import com.example.ui.components.CargoCameraScannerView
import com.example.ui.components.CargoStatusBadge
import com.example.ui.components.Code128BarcodeView
import com.example.ui.components.ErrorStatePanel
import com.example.ui.components.ScannedManifestPdfCard
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AlertCrimson100
import com.example.ui.theme.AlertCrimson600
import com.example.ui.theme.ClearedEmerald100
import com.example.ui.theme.ClearedEmerald600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber500
import com.example.ui.viewmodel.CargoFlowViewModel
import com.example.ui.viewmodel.ScanActionMode

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScannerScreen(
    viewModel: CargoFlowViewModel,
    onInspectShipment: (String) -> Unit
) {
    val scanResult by viewModel.scanResult.collectAsStateWithLifecycle()
    val scanMode by viewModel.scanActionMode.collectAsStateWithLifecycle()
    val targetCheckpoint by viewModel.scanTargetCheckpoint.collectAsStateWithLifecycle()
    val scanHistory by viewModel.scanHistory.collectAsStateWithLifecycle()
    val scannedManifestItems by viewModel.scannedManifestItems.collectAsStateWithLifecycle()
    val manifestPdfState by viewModel.manifestPdfState.collectAsStateWithLifecycle()
    val session by viewModel.session.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val emailChooserTitle = stringResource(R.string.manifest_pdf_chooser_email)
    val shareChooserTitle = stringResource(R.string.manifest_pdf_chooser_share)
    val noEmailAppMsg = stringResource(R.string.manifest_pdf_no_email_app)

    var barcodeInput by remember { mutableStateOf("") }

    val quickSamples = listOf(
        "CF-2026-000001",
        "CF-2026-000003",
        "CF-2026-000004",
        "PKG-2026-000001-01"
    )

    val role = session?.role ?: UserRole.DRIVER
    val checkpointChoices = remember(role) {
        RbacPolicyEngine.allowedScannerCheckpoints(role)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("scanner_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("CameraX Barcode & Checkpoint Scanner", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Reads shipment and package identifiers live via CameraX ImageAnalysis and automatically executes lookup or RBAC-validated status transitions.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Reusable CameraX Preview + ImageAnalysis Scanner Component
        item {
            CargoCameraScannerView(
                onBarcodeDetected = { detectedCode ->
                    barcodeInput = detectedCode
                    viewModel.handleBarcodeScan(detectedCode)
                },
                height = 240.dp,
                autoStartWhenPermitted = false
            )
        }

        // Automated Action Mode Selector (Lookup vs Auto-Advance vs Checkpoint)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "Scan Automation",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text("On-Scan Automated Action", style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        scanMode.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ScanActionMode.entries) { mode ->
                            FilterChip(
                                selected = scanMode == mode,
                                onClick = { viewModel.setScanActionMode(mode) },
                                label = { Text(mode.label) },
                                modifier = Modifier.testTag("scan_mode_${mode.name.lowercase()}")
                            )
                        }
                    }

                    if (scanMode == ScanActionMode.AUTO_SET_CHECKPOINT && checkpointChoices.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Authorized Checkpoints (${role.displayName}):",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(checkpointChoices) { st ->
                                FilterChip(
                                    selected = targetCheckpoint == st,
                                    onClick = { viewModel.setScanTargetCheckpoint(st) },
                                    label = { Text(st.displayLabel) },
                                    modifier = Modifier.testTag("checkpoint_${st.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }

        // Direct Barcode / Hardware Wedge Input & Emulator Quick Presets
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = barcodeInput,
                        onValueChange = { barcodeInput = it },
                        label = { Text("Manual / Hardware Scanner Input") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("scanner_manual_input")
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.handleBarcodeScan(barcodeInput) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("scanner_lookup_button")
                    ) {
                        Text(
                            when (scanMode) {
                                ScanActionMode.AUTO_LOOKUP -> "Scan & Lookup Manifest"
                                ScanActionMode.AUTO_ADVANCE_NEXT -> "Scan & Auto-Advance Status"
                                ScanActionMode.AUTO_SET_CHECKPOINT -> "Scan & Move -> ${targetCheckpoint.displayLabel}"
                            }
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Quick Dock Scan Presets:", style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(quickSamples) { sample ->
                            FilterChip(
                                selected = barcodeInput.equals(sample, ignoreCase = true),
                                onClick = {
                                    barcodeInput = sample
                                    viewModel.handleBarcodeScan(sample)
                                },
                                label = {
                                    Text(
                                        sample,
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily)
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // Decoded Scan Result Card + One-Tap Authorized Transitions
        scanResult?.let { res ->
            item {
                if (res.error != null) {
                    ErrorStatePanel(res.error)
                } else if (res.shipment != null) {
                    val shp = res.shipment
                    val status = CargoStatus.fromNameSafe(shp.status)
                    val role = session?.role ?: UserRole.DRIVER
                    val validNext = CargoStateMachine.availableTransitionsForRole(status, role)

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(
                            1.5.dp,
                            if (res.autoActionSucceeded) LogisticsAmber500 else AlertCrimson600
                        ),
                        modifier = Modifier.testTag("scanner_decoded_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            res.autoActionSummary?.let { summary ->
                                Surface(
                                    color = if (res.autoActionSucceeded) ClearedEmerald100 else AlertCrimson100,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (res.autoActionSucceeded) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                            contentDescription = null,
                                            tint = if (res.autoActionSucceeded) ClearedEmerald600 else AlertCrimson600,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = summary,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                            color = if (res.autoActionSucceeded) ClearedEmerald600 else AlertCrimson600
                                        )
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        shp.trackingNumber,
                                        style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFamily)
                                    )
                                    res.pkg?.let { pkg ->
                                        Text(
                                            "Package ${pkg.packageCode} · ${pkg.warehouseZone}/${pkg.binLocation}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                CargoStatusBadge(status = status)
                            }
                            Spacer(Modifier.height(10.dp))
                            Code128BarcodeView(
                                code = res.pkg?.barcodeValue ?: shp.barcodeValue,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "${shp.originHub} -> ${shp.destinationCity}, ${shp.destinationCountry}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (validNext.isNotEmpty()) {
                                Spacer(Modifier.height(10.dp))
                                Text("Manual Checkpoint Override:", style = MaterialTheme.typography.labelLarge)
                                Spacer(Modifier.height(6.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    validNext.forEach { target ->
                                        Button(
                                            onClick = {
                                                viewModel.transitionShipment(
                                                    shipmentId = shp.id,
                                                    targetStatus = target,
                                                    facilityLocation = session?.hubLocation ?: shp.originHub,
                                                    notes = "Checkpoint confirmed via barcode scanner"
                                                )
                                            }
                                        ) {
                                            Text("Move -> ${target.displayLabel}")
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = { onInspectShipment(shp.id) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Open Full Manifest & Timeline")
                            }
                        }
                    }
                }
            }
        }

        // Digital Shipment Manifest PDF Builder & Email Dispatch
        item {
            ScannedManifestPdfCard(
                items = scannedManifestItems,
                pdfState = manifestPdfState,
                onRemoveItem = { key -> viewModel.removeScannedManifestItem(key) },
                onClearItems = { viewModel.clearScannedManifestItems() },
                onGeneratePdf = { recipientEmail, notes ->
                    viewModel.generateScannedManifestPdf(
                        recipientEmail = recipientEmail,
                        notes = notes
                    )
                },
                onEmailPdf = { pdf, recipientEmail ->
                    ManifestShareHelper.launchEmailManifestShare(
                        context = context,
                        pdf = pdf,
                        recipientEmail = recipientEmail,
                        operator = session,
                        chooserTitle = emailChooserTitle
                    ).onFailure {
                        viewModel.showActionMessage(false, it.message ?: noEmailAppMsg)
                    }
                },
                onSharePdf = { pdf, recipientEmail ->
                    ManifestShareHelper.launchEmailManifestShare(
                        context = context,
                        pdf = pdf,
                        recipientEmail = recipientEmail,
                        operator = session,
                        chooserTitle = shareChooserTitle
                    ).onFailure {
                        viewModel.showActionMessage(false, it.message ?: noEmailAppMsg)
                    }
                }
            )
        }

        // Session Scan Log
        if (scanHistory.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Session Scan Telemetry (${scanHistory.size})", style = MaterialTheme.typography.titleSmall)
                        }
                        Spacer(Modifier.height(8.dp))
                        scanHistory.take(8).forEachIndexed { idx, entry ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${entry.scannedCode} · ${entry.mode.label}",
                                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily)
                                    )
                                    Text(
                                        entry.outcomeSummary,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (entry.succeeded) ClearedEmerald600 else AlertCrimson600
                                    )
                                }
                                Text(
                                    formatTimestamp(entry.timestampEpochMs),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (idx < scanHistory.take(8).lastIndex) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                            }
                        }
                    }
                }
            }
        }
    }
}
