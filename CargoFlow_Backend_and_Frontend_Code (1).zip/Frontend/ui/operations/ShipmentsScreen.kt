package com.example.ui.operations

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.CustomerEntity
import com.example.data.local.PackageEntity
import com.example.data.local.ShipmentEntity
import com.example.data.local.ShipmentSummaryRow
import com.example.domain.CargoStateMachine
import com.example.domain.CargoStatus
import com.example.domain.Permission
import com.example.domain.RbacPolicyEngine
import com.example.domain.ServiceTier
import com.example.domain.UserRole
import com.example.ui.components.CargoStatusBadge
import com.example.ui.components.Code128BarcodeView
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.InfoCallout
import com.example.ui.components.ShippingLabelDialog
import com.example.ui.components.formatDateOnly
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AlertCrimson600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber600
import com.example.ui.theme.TelemetryBlue600
import com.example.ui.viewmodel.CargoFlowViewModel

@Composable
fun ShipmentsScreen(viewModel: CargoFlowViewModel) {
    val selectedShipment by viewModel.selectedShipment.collectAsStateWithLifecycle()
    val session by viewModel.session.collectAsStateWithLifecycle()

    if (selectedShipment != null) {
        BackHandler { viewModel.selectShipment(null) }
        ShipmentDetailView(
            shipment = selectedShipment!!,
            role = session?.role ?: UserRole.DRIVER,
            hubLocation = session?.hubLocation ?: "Kabul, Afghanistan",
            viewModel = viewModel,
            onBack = { viewModel.selectShipment(null) }
        )
    } else {
        ShipmentsListView(viewModel = viewModel)
    }
}

@Composable
private fun ShipmentsListView(viewModel: CargoFlowViewModel) {
    val shipments by viewModel.shipments.collectAsStateWithLifecycle()
    val statusFilter by viewModel.shipmentStatusFilter.collectAsStateWithLifecycle()
    val query by viewModel.shipmentSearchQuery.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val session by viewModel.session.collectAsStateWithLifecycle()

    val canCreate = session?.let {
        RbacPolicyEngine.hasPermission(it.role, Permission.CREATE_SHIPMENT)
    } == true
    val canViewCustomers = session?.let {
        RbacPolicyEngine.hasPermission(it.role, Permission.VIEW_CUSTOMERS)
    } == true

    var showCreateDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Search & Filter Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { viewModel.setShipmentSearchQuery(it) },
                    label = {
                        Text(
                            if (canViewCustomers) "Search tracking ID, destination, or client"
                            else "Search tracking ID or destination city"
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search shipments") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("shipments_search_input")
                )
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = statusFilter == null,
                            onClick = { viewModel.setShipmentStatusFilter(null) },
                            label = { Text("All") }
                        )
                    }
                    items(
                        listOf(
                            CargoStatus.CREATED,
                            CargoStatus.RECEIVED,
                            CargoStatus.WAREHOUSE,
                            CargoStatus.DISPATCHED,
                            CargoStatus.IN_TRANSIT,
                            CargoStatus.DELAYED,
                            CargoStatus.ON_HOLD,
                            CargoStatus.DELIVERED
                        )
                    ) { status ->
                        FilterChip(
                            selected = statusFilter == status,
                            onClick = {
                                viewModel.setShipmentStatusFilter(if (statusFilter == status) null else status)
                            },
                            label = { Text(status.displayLabel) }
                        )
                    }
                }
            }

            if (shipments.isEmpty()) {
                Box(Modifier.padding(16.dp)) {
                    EmptyStatePanel(
                        title = "No matching shipments",
                        subtitle = "Adjust your status filter or register a new cargo manifest."
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 84.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shipments, key = { it.id }) { row ->
                        ShipmentTableCard(
                            row = row,
                            onClick = { viewModel.selectShipment(row.id) }
                        )
                    }
                }
            }
        }

        if (canCreate) {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("create_shipment_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Shipment")
            }
        }
    }

    if (showCreateDialog) {
        CreateShipmentDialog(
            customers = customers,
            defaultHub = session?.hubLocation ?: "Kabul, Afghanistan",
            onDismiss = { showCreateDialog = false },
            onConfirm = { custId, hub, city, country, tier, weight, value, notes, pkgDesc, zone ->
                viewModel.createShipment(
                    customerId = custId,
                    originHub = hub,
                    destinationCity = city,
                    destinationCountry = country,
                    serviceTier = tier,
                    weightKg = weight,
                    declaredValueUsd = value,
                    internalNotes = notes,
                    packageDescription = pkgDesc,
                    warehouseZone = zone
                ) { created ->
                    showCreateDialog = false
                    viewModel.selectShipment(created.id)
                }
            }
        )
    }
}

@Composable
private fun ShipmentTableCard(
    row: ShipmentSummaryRow,
    onClick: () -> Unit
) {
    val status = CargoStatus.fromNameSafe(row.status)
    val now = System.currentTimeMillis()
    val slaAtRisk = !status.isTerminal && row.slaDeadlineEpoch < now

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (slaAtRisk || status == CargoStatus.DELAYED) 1.5.dp else 1.dp,
            color = if (slaAtRisk || status == CargoStatus.DELAYED) AlertCrimson600.copy(alpha = 0.65f)
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("shipment_row_${row.trackingNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = row.trackingNumber,
                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFamily)
                )
                CargoStatusBadge(status = status)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = row.customerName,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${row.originHub} -> ${row.destinationCity}, ${row.destinationCountry}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${row.packageCount} pkgs · ${row.totalWeightKg} kg · ${ServiceTier.fromNameSafe(row.serviceTier).label}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (slaAtRisk) "SLA OVERDUE" else "SLA ${formatDateOnly(row.slaDeadlineEpoch)}",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (slaAtRisk) AlertCrimson600 else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ShipmentDetailView(
    shipment: ShipmentEntity,
    role: UserRole,
    hubLocation: String,
    viewModel: CargoFlowViewModel,
    onBack: () -> Unit
) {
    val history by viewModel.selectedShipmentHistory.collectAsStateWithLifecycle()
    val packages by viewModel.selectedShipmentPackages.collectAsStateWithLifecycle()

    val currentStatus = CargoStatus.fromNameSafe(shipment.status)
    val allowedNext = CargoStateMachine.availableTransitionsForRole(currentStatus, role)
    val blockedInvalidSample = CargoStatus.entries.firstOrNull {
        it != currentStatus && !CargoStateMachine.isGraphTransitionValid(currentStatus, it)
    }

    var transitionNotes by remember(shipment.id) { mutableStateOf("") }
    var showLabelModal by remember { mutableStateOf(false) }
    var inspectedPackage by remember { mutableStateOf<PackageEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("shipment_detail_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("shipment_detail_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to shipments")
                    }
                    Column {
                        Text(
                            shipment.trackingNumber,
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFamily)
                        )
                        Text(
                            "${shipment.originHub} -> ${shipment.destinationCity}, ${shipment.destinationCountry}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(
                    onClick = { showLabelModal = true },
                    modifier = Modifier.testTag("open_shipping_label_button")
                ) {
                    Icon(Icons.Default.QrCode2, contentDescription = "View QR and Barcode Label")
                }
            }
        }

        // Manifest Overview Card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CargoStatusBadge(status = currentStatus)
                        Text(
                            ServiceTier.fromNameSafe(shipment.serviceTier).label,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Code128BarcodeView(code = shipment.barcodeValue, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    val canViewFinancials = RbacPolicyEngine.hasPermission(role, Permission.VIEW_INTERNAL_FINANCIALS)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Weight: ${shipment.totalWeightKg} kg", style = MaterialTheme.typography.bodySmall)
                        if (canViewFinancials) {
                            Text("Value: $${shipment.declaredValueUsd.toInt()}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text("SLA: ${formatDateOnly(shipment.slaDeadlineEpoch)}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (canViewFinancials && shipment.internalNotes.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        InfoCallout("Internal Ops Notes (Hidden from Public Portal): ${shipment.internalNotes}")
                    } else if (!canViewFinancials) {
                        Spacer(Modifier.height(8.dp))
                        InfoCallout(
                            "Role Scope (${role.displayName}): Declared freight value and commercial contract notes are restricted to Admin, Ops Manager, and Dispatcher."
                        )
                    }
                }
            }
        }

        // Controlled Lifecycle State Transition Panel
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Controlled State Transition (FSM + RBAC)", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Only transitions permitted for '${currentStatus.displayLabel}' and role '${role.displayName}' are allowed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = transitionNotes,
                        onValueChange = { transitionNotes = it },
                        label = { Text("Checkpoint notes (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    if (allowedNext.isEmpty()) {
                        InfoCallout(
                            if (currentStatus.isTerminal) "Shipment is in terminal state '${currentStatus.displayLabel}'."
                            else "Your role (${role.displayName}) has no authorized transitions from '${currentStatus.displayLabel}'."
                        )
                    } else {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            allowedNext.forEach { target ->
                                Button(
                                    onClick = {
                                        viewModel.transitionShipment(
                                            shipmentId = shipment.id,
                                            targetStatus = target,
                                            facilityLocation = hubLocation,
                                            notes = transitionNotes
                                        )
                                        transitionNotes = ""
                                    },
                                    modifier = Modifier.testTag("transition_to_${target.name.lowercase()}")
                                ) {
                                    Text("Move -> ${target.displayLabel}")
                                }
                            }
                        }
                    }

                    // Verification affordance to test invalid transition blocking in real time
                    if (blockedInvalidSample != null) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                viewModel.transitionShipment(
                                    shipmentId = shipment.id,
                                    targetStatus = blockedInvalidSample,
                                    facilityLocation = hubLocation,
                                    notes = "Testing invalid FSM guard"
                                )
                            },
                            modifier = Modifier.testTag("test_invalid_transition_button")
                        ) {
                            Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Verify FSM Guard (Attempt -> ${blockedInvalidSample.displayLabel})")
                        }
                    }
                }
            }
        }

        // Linked Packages
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = LogisticsAmber600)
                        Spacer(Modifier.width(8.dp))
                        Text("Manifest Packages (${packages.size})", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    packages.forEach { pkg ->
                        Surface(
                            onClick = { inspectedPackage = pkg },
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        pkg.packageCode,
                                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily)
                                    )
                                    Text(
                                        "${pkg.description} · ${pkg.weightKg} kg",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        "${pkg.warehouseZone} / Bin ${pkg.binLocation} · SKU ${pkg.sku}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(Icons.Default.QrCode2, contentDescription = "View package barcode")
                            }
                        }
                    }
                }
            }
        }

        // Complete Status-History Timeline (with Timestamps & Responsible Operator)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null, tint = TelemetryBlue600)
                        Spacer(Modifier.width(8.dp))
                        Text("Status-History Audit Timeline", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(10.dp))
                    history.forEachIndexed { idx, event ->
                        val toState = CargoStatus.fromNameSafe(event.toStatus)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(if (idx == 0) LogisticsAmber600 else TelemetryBlue600)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        "${event.fromStatus} -> ${toState.displayLabel}",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        formatTimestamp(event.timestamp),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    "By ${event.actorName} (${event.actorRole}) @ ${event.facilityLocation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    event.notes,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        if (idx < history.lastIndex) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                        }
                    }
                }
            }
        }
    }

    if (showLabelModal) {
        ShippingLabelDialog(
            title = shipment.trackingNumber,
            code = shipment.barcodeValue,
            qrPayload = shipment.qrPayload,
            subtitle = "${shipment.originHub} -> ${shipment.destinationCity}, ${shipment.destinationCountry}",
            metadataLines = listOf(
                "Service Tier" to ServiceTier.fromNameSafe(shipment.serviceTier).label,
                "Status" to currentStatus.displayLabel,
                "Total Weight" to "${shipment.totalWeightKg} kg",
                "Package Count" to "${packages.size} units"
            ),
            onDismiss = { showLabelModal = false }
        )
    }

    inspectedPackage?.let { pkg ->
        ShippingLabelDialog(
            title = pkg.packageCode,
            code = pkg.barcodeValue,
            qrPayload = pkg.qrPayload,
            subtitle = pkg.description,
            metadataLines = listOf(
                "Parent Manifest" to shipment.trackingNumber,
                "SKU" to pkg.sku,
                "Zone / Bin" to "${pkg.warehouseZone} / ${pkg.binLocation}",
                "Weight / Dims" to "${pkg.weightKg} kg (${pkg.dimensionsCm} cm)"
            ),
            onDismiss = { inspectedPackage = null }
        )
    }
}

@Composable
private fun CreateShipmentDialog(
    customers: List<CustomerEntity>,
    defaultHub: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, ServiceTier, Double, Double, String, String, String) -> Unit
) {
    var selectedCustomerId by remember(customers) { mutableStateOf(customers.firstOrNull()?.id ?: "") }
    var originHub by remember { mutableStateOf(defaultHub) }
    var destCity by remember { mutableStateOf("Munich") }
    var destCountry by remember { mutableStateOf("Germany") }
    var tier by remember { mutableStateOf(ServiceTier.EXPRESS_AIR) }
    var weightStr by remember { mutableStateOf("28.5") }
    var valueStr by remember { mutableStateOf("4200") }
    var pkgDesc by remember { mutableStateOf("Precision Sensor Pallet") }
    var zone by remember { mutableStateOf("ZONE-A") }
    var notes by remember { mutableStateOf("Priority seal verified") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Register New Cargo Shipment") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text(
                        "Customer: ${customers.firstOrNull { it.id == selectedCustomerId }?.companyName ?: "None"}",
                        style = MaterialTheme.typography.labelLarge
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(customers.take(6)) { c ->
                            FilterChip(
                                selected = selectedCustomerId == c.id,
                                onClick = { selectedCustomerId = c.id },
                                label = { Text(c.accountCode) }
                            )
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = originHub,
                        onValueChange = { originHub = it },
                        label = { Text("Origin Hub") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = destCity,
                            onValueChange = { destCity = it },
                            label = { Text("Dest. City") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = destCountry,
                            onValueChange = { destCountry = it },
                            label = { Text("Country") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(ServiceTier.entries) { st ->
                            FilterChip(
                                selected = tier == st,
                                onClick = { tier = st },
                                label = { Text(st.label) }
                            )
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = weightStr,
                            onValueChange = { weightStr = it },
                            label = { Text("Weight (kg)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = valueStr,
                            onValueChange = { valueStr = it },
                            label = { Text("Value ($)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = pkgDesc,
                        onValueChange = { pkgDesc = it },
                        label = { Text("Primary Package Description") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Internal Ops Notes (Private)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        selectedCustomerId,
                        originHub,
                        destCity,
                        destCountry,
                        tier,
                        weightStr.toDoubleOrNull() ?: 0.0,
                        valueStr.toDoubleOrNull() ?: 0.0,
                        notes,
                        pkgDesc,
                        zone
                    )
                },
                modifier = Modifier.testTag("confirm_create_shipment_button")
            ) {
                Text("Register Manifest")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
