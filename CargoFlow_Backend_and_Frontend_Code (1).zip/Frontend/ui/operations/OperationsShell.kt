package com.example.ui.operations

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.Permission
import com.example.domain.RbacPolicyEngine
import com.example.domain.UserRole
import com.example.ui.components.ActionFeedbackBanner
import com.example.ui.components.ActiveRoleIndicator
import com.example.ui.viewmodel.CargoFlowViewModel

private enum class OpsTabId {
    DASHBOARD,
    SHIPMENTS,
    INVENTORY,
    WORKFORCE,
    SCANNER
}

private data class OpsDestination(
    val id: OpsTabId,
    val label: String,
    val icon: ImageVector,
    val tag: String
)

private fun authorizedDestinationsFor(role: UserRole): List<OpsDestination> {
    val destinations = mutableListOf<OpsDestination>()
    val canDashboard = RbacPolicyEngine.hasPermission(role, Permission.VIEW_OPERATIONS_DASHBOARD)
    val canInventory = RbacPolicyEngine.hasPermission(role, Permission.VIEW_INVENTORY)
    val canScanner = RbacPolicyEngine.hasPermission(role, Permission.USE_SCANNER)
    val canAudit = RbacPolicyEngine.hasPermission(role, Permission.VIEW_AUDIT_LOGS)
    val canAssign = RbacPolicyEngine.hasPermission(role, Permission.ASSIGN_TASKS)

    if (canDashboard) {
        destinations += OpsDestination(OpsTabId.DASHBOARD, "Dashboard", Icons.Default.Dashboard, "nav_dashboard")
    }

    if (role == UserRole.WAREHOUSE_STAFF && canInventory) {
        // Warehouse specialists start directly in Warehouse Inventory & Bins
        destinations += OpsDestination(OpsTabId.INVENTORY, "Inventory", Icons.Default.Inventory2, "nav_inventory")
        destinations += OpsDestination(OpsTabId.SHIPMENTS, "Shipments", Icons.Default.LocalShipping, "nav_shipments")
    } else {
        val shipmentLabel = if (role == UserRole.DRIVER) "Deliveries" else "Shipments"
        destinations += OpsDestination(OpsTabId.SHIPMENTS, shipmentLabel, Icons.Default.LocalShipping, "nav_shipments")
        if (canInventory) {
            destinations += OpsDestination(OpsTabId.INVENTORY, "Inventory", Icons.Default.Inventory2, "nav_inventory")
        }
    }

    val workforceLabel = when {
        canAssign -> if (role == UserRole.DISPATCHER) "Dispatch Ops" else "Ops Hub"
        else -> "My Tasks"
    }
    val workforceIcon = if (canAssign) Icons.Default.Groups else Icons.Default.Assignment
    destinations += OpsDestination(OpsTabId.WORKFORCE, workforceLabel, workforceIcon, "nav_workforce")

    if (canScanner) {
        destinations += OpsDestination(OpsTabId.SCANNER, "Scanner", Icons.Default.QrCodeScanner, "nav_scanner")
    }

    return destinations
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperationsShell(
    viewModel: CargoFlowViewModel,
    onSignedOut: () -> Unit
) {
    val session by viewModel.session.collectAsStateWithLifecycle()
    val banner by viewModel.actionBanner.collectAsStateWithLifecycle()

    val role = session?.role ?: UserRole.DRIVER
    val destinations = remember(role) { authorizedDestinationsFor(role) }
    var selectedTabName by rememberSaveable { mutableStateOf(destinations.first().id.name) }

    LaunchedEffect(session?.employeeId, destinations) {
        val currentValid = destinations.any { it.id.name == selectedTabName }
        if (!currentValid) {
            selectedTabName = destinations.first().id.name
        }
    }

    val activeTab = destinations.firstOrNull { it.id.name == selectedTabName }?.id ?: destinations.first().id

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "CargoFlow Ops",
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                session?.let { op ->
                                    Text(
                                        text = "${op.fullName} · ${op.hubLocation}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            session?.let { ActiveRoleIndicator(role = it.role) }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.signOutOperator(onSignedOut = onSignedOut) },
                            modifier = Modifier.testTag("ops_sign_out_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Sign out of Operations Portal"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar {
                        destinations.forEach { dest ->
                            NavigationBarItem(
                                selected = activeTab == dest.id,
                                onClick = {
                                    selectedTabName = dest.id.name
                                    if (dest.id == OpsTabId.DASHBOARD) viewModel.refreshDashboard()
                                },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label, maxLines = 1) },
                                modifier = Modifier.testTag(dest.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        destinations.forEach { dest ->
                            NavigationRailItem(
                                selected = activeTab == dest.id,
                                onClick = {
                                    selectedTabName = dest.id.name
                                    if (dest.id == OpsTabId.DASHBOARD) viewModel.refreshDashboard()
                                },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label) },
                                modifier = Modifier.testTag(dest.tag)
                            )
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    banner?.let { (isSuccess, msg) ->
                        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                            ActionFeedbackBanner(
                                isSuccess = isSuccess,
                                message = msg,
                                onDismiss = { viewModel.clearBanner() }
                            )
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        when (activeTab) {
                            OpsTabId.DASHBOARD -> DashboardScreen(
                                viewModel = viewModel,
                                onFilterShipmentsByStatus = { st ->
                                    viewModel.setShipmentStatusFilter(st)
                                    viewModel.selectShipment(null)
                                    selectedTabName = OpsTabId.SHIPMENTS.name
                                }
                            )
                            OpsTabId.SHIPMENTS -> ShipmentsScreen(viewModel = viewModel)
                            OpsTabId.INVENTORY -> InventoryScreen(viewModel = viewModel)
                            OpsTabId.WORKFORCE -> WorkforceAndAuditScreen(viewModel = viewModel)
                            OpsTabId.SCANNER -> ScannerScreen(
                                viewModel = viewModel,
                                onInspectShipment = { shipmentId ->
                                    viewModel.selectShipment(shipmentId)
                                    selectedTabName = OpsTabId.SHIPMENTS.name
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
