package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AuditLogEntity
import com.example.data.local.CargoFlowDatabase
import com.example.data.local.CustomerEntity
import com.example.data.local.EmployeeEntity
import com.example.data.local.PackageEntity
import com.example.data.local.ShipmentEntity
import com.example.data.local.ShipmentSummaryRow
import com.example.data.local.StatusHistoryEntity
import com.example.data.local.TaskDetailRow
import com.example.data.repository.CargoFlowRepository
import com.example.domain.BenchmarkReport
import com.example.domain.CargoStateMachine
import com.example.domain.CargoStatus
import com.example.domain.CustomerTier
import com.example.domain.DashboardMetrics
import com.example.domain.DomainResult
import com.example.domain.GeneratedManifestPdf
import com.example.domain.OperatorSession
import com.example.domain.Permission
import com.example.domain.PublicTrackingSnapshot
import com.example.domain.RbacPolicyEngine
import com.example.domain.ScannedManifestItem
import com.example.domain.ServiceTier
import com.example.domain.ShipmentManifestPdfGenerator
import com.example.domain.TaskPriority
import com.example.domain.TaskStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface UiState<out T> {
    data object Idle : UiState<Nothing>
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class ScanActionMode(val label: String, val subtitle: String) {
    AUTO_LOOKUP("Auto Lookup", "Decode identifier and display manifest"),
    AUTO_ADVANCE_NEXT("Auto Advance", "Automatically move to next valid lifecycle state"),
    AUTO_SET_CHECKPOINT("Set Checkpoint", "Transition scanned cargo to selected checkpoint")
}

data class ScanEventLog(
    val id: Long,
    val scannedCode: String,
    val resolvedTracking: String?,
    val mode: ScanActionMode,
    val outcomeSummary: String,
    val succeeded: Boolean,
    val timestampEpochMs: Long
)

data class ScanLookupResult(
    val scannedCode: String,
    val shipment: ShipmentEntity?,
    val pkg: PackageEntity?,
    val autoActionSummary: String? = null,
    val autoActionSucceeded: Boolean = true,
    val error: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class CargoFlowViewModel(application: Application) : AndroidViewModel(application) {

    private val database = CargoFlowDatabase.getInstance(application)
    val repository = CargoFlowRepository(database)

    // Initialization & Session
    private val _isBootstrapping = MutableStateFlow(true)
    val isBootstrapping: StateFlow<Boolean> = _isBootstrapping.asStateFlow()

    private val _session = MutableStateFlow<OperatorSession?>(null)
    val session: StateFlow<OperatorSession?> = _session.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    // Public Tracking
    private val _publicTrackingState = MutableStateFlow<UiState<PublicTrackingSnapshot>>(UiState.Idle)
    val publicTrackingState: StateFlow<UiState<PublicTrackingSnapshot>> = _publicTrackingState.asStateFlow()

    // Dashboard & Benchmark
    private val _dashboardState = MutableStateFlow<UiState<DashboardMetrics>>(UiState.Loading)
    val dashboardState: StateFlow<UiState<DashboardMetrics>> = _dashboardState.asStateFlow()

    private val _benchmarkState = MutableStateFlow<UiState<BenchmarkReport>>(UiState.Idle)
    val benchmarkState: StateFlow<UiState<BenchmarkReport>> = _benchmarkState.asStateFlow()

    // Audit integrity & feedback snackbar/banner
    private val _auditChainValid = MutableStateFlow<Boolean?>(null)
    val auditChainValid: StateFlow<Boolean?> = _auditChainValid.asStateFlow()

    private val _actionBanner = MutableStateFlow<Pair<Boolean, String>?>(null)
    val actionBanner: StateFlow<Pair<Boolean, String>?> = _actionBanner.asStateFlow()

    // Filters
    private val _shipmentStatusFilter = MutableStateFlow<CargoStatus?>(null)
    val shipmentStatusFilter: StateFlow<CargoStatus?> = _shipmentStatusFilter.asStateFlow()

    private val _shipmentSearchQuery = MutableStateFlow("")
    val shipmentSearchQuery: StateFlow<String> = _shipmentSearchQuery.asStateFlow()

    private val _inventoryZoneFilter = MutableStateFlow("")
    val inventoryZoneFilter: StateFlow<String> = _inventoryZoneFilter.asStateFlow()

    private val _inventorySearchQuery = MutableStateFlow("")
    val inventorySearchQuery: StateFlow<String> = _inventorySearchQuery.asStateFlow()

    private val _selectedShipmentId = MutableStateFlow<String?>(null)
    val selectedShipmentId: StateFlow<String?> = _selectedShipmentId.asStateFlow()

    private val _selectedShipment = MutableStateFlow<ShipmentEntity?>(null)
    val selectedShipment: StateFlow<ShipmentEntity?> = _selectedShipment.asStateFlow()

    private val _scanResult = MutableStateFlow<ScanLookupResult?>(null)
    val scanResult: StateFlow<ScanLookupResult?> = _scanResult.asStateFlow()

    private val _scanActionMode = MutableStateFlow(ScanActionMode.AUTO_LOOKUP)
    val scanActionMode: StateFlow<ScanActionMode> = _scanActionMode.asStateFlow()

    private val _scanTargetCheckpoint = MutableStateFlow(CargoStatus.RECEIVED)
    val scanTargetCheckpoint: StateFlow<CargoStatus> = _scanTargetCheckpoint.asStateFlow()

    private val _scanHistory = MutableStateFlow<List<ScanEventLog>>(emptyList())
    val scanHistory: StateFlow<List<ScanEventLog>> = _scanHistory.asStateFlow()

    private val _scannedManifestItems = MutableStateFlow<List<ScannedManifestItem>>(emptyList())
    val scannedManifestItems: StateFlow<List<ScannedManifestItem>> = _scannedManifestItems.asStateFlow()

    private val _manifestPdfState = MutableStateFlow<UiState<GeneratedManifestPdf>>(UiState.Idle)
    val manifestPdfState: StateFlow<UiState<GeneratedManifestPdf>> = _manifestPdfState.asStateFlow()

    // Reactive streams
    val shipments: StateFlow<List<ShipmentSummaryRow>> = combine(
        _shipmentStatusFilter,
        _shipmentSearchQuery
    ) { status, query -> status to query }
        .flatMapLatest { (status, query) -> repository.observeShipments(status, query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val inventoryPackages: StateFlow<List<PackageEntity>> = combine(
        _session,
        _inventoryZoneFilter,
        _inventorySearchQuery
    ) { sess, zone, query -> Triple(sess, zone, query) }
        .flatMapLatest { (sess, zone, query) -> repository.observeInventoryForSession(sess, zone, query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedShipmentHistory: StateFlow<List<StatusHistoryEntity>> = _selectedShipmentId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.observeStatusHistory(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedShipmentPackages: StateFlow<List<PackageEntity>> = _selectedShipmentId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.observePackagesForShipment(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<CustomerEntity>> = _session
        .flatMapLatest { sess -> repository.observeCustomersForSession(sess) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val employees: StateFlow<List<EmployeeEntity>> = _session
        .flatMapLatest { sess -> repository.observeEmployeesForSession(sess) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks: StateFlow<List<TaskDetailRow>> = _session
        .flatMapLatest { sess -> repository.observeTasksForSession(sess) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = _session
        .flatMapLatest { sess -> repository.observeAuditLogsForSession(sess) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.initializeIfEmpty()
            _isBootstrapping.value = false
        }
    }

    fun clearBanner() {
        _actionBanner.value = null
    }

    fun clearAuthError() {
        _authError.value = null
    }

    // ---- Public Tracking ----
    fun trackPublicShipment(trackingInput: String) {
        viewModelScope.launch {
            _publicTrackingState.value = UiState.Loading
            if (_isBootstrapping.value) {
                repository.initializeIfEmpty()
                _isBootstrapping.value = false
            }
            when (val res = repository.trackShipmentPublic(trackingInput)) {
                is DomainResult.Success -> _publicTrackingState.value = UiState.Success(res.data)
                is DomainResult.Failure -> _publicTrackingState.value = UiState.Error(res.message)
            }
        }
    }

    fun resetPublicTracking() {
        _publicTrackingState.value = UiState.Idle
    }

    // ---- Operator Authentication ----
    fun signInOperator(email: String, password: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            _authError.value = null
            if (_isBootstrapping.value) {
                repository.initializeIfEmpty()
                _isBootstrapping.value = false
            }
            when (val res = repository.authenticateOperator(email, password)) {
                is DomainResult.Success -> {
                    val op = res.data
                    _session.value = op
                    _isAuthenticating.value = false
                    _selectedShipmentId.value = null
                    _selectedShipment.value = null
                    _scanResult.value = null
                    _scanHistory.value = emptyList()
                    _scannedManifestItems.value = emptyList()
                    _manifestPdfState.value = UiState.Idle
                    _benchmarkState.value = UiState.Idle
                    _actionBanner.value = null
                    _scanTargetCheckpoint.value = RbacPolicyEngine
                        .allowedScannerCheckpoints(op.role)
                        .firstOrNull() ?: CargoStatus.RECEIVED
                    if (RbacPolicyEngine.hasPermission(op.role, Permission.VIEW_OPERATIONS_DASHBOARD)) {
                        refreshDashboard()
                    } else {
                        _dashboardState.value = UiState.Idle
                    }
                    if (RbacPolicyEngine.hasPermission(op.role, Permission.VIEW_AUDIT_LOGS)) {
                        verifyAuditChain()
                    } else {
                        _auditChainValid.value = null
                    }
                    onSuccess()
                }
                is DomainResult.Failure -> {
                    _authError.value = res.message
                    _isAuthenticating.value = false
                }
            }
        }
    }

    fun signOutOperator(onSignedOut: () -> Unit = {}) {
        val current = _session.value
        viewModelScope.launch {
            if (current != null) {
                repository.recordSignOut(current)
            }
            _session.value = null
            _selectedShipmentId.value = null
            _selectedShipment.value = null
            _scanResult.value = null
            _scanHistory.value = emptyList()
            _scannedManifestItems.value = emptyList()
            _manifestPdfState.value = UiState.Idle
            _dashboardState.value = UiState.Idle
            _benchmarkState.value = UiState.Idle
            _auditChainValid.value = null
            _actionBanner.value = null
            onSignedOut()
        }
    }

    // ---- Dashboard & 10,000+ Benchmark ----
    fun refreshDashboard() {
        val current = _session.value
        if (current == null || !RbacPolicyEngine.hasPermission(current.role, Permission.VIEW_OPERATIONS_DASHBOARD)) {
            _dashboardState.value = UiState.Idle
            return
        }
        viewModelScope.launch {
            _dashboardState.value = UiState.Loading
            when (val res = repository.loadDashboardMetrics(current)) {
                is DomainResult.Success -> _dashboardState.value = UiState.Success(res.data)
                is DomainResult.Failure -> _dashboardState.value = UiState.Error(res.message)
            }
        }
    }

    fun runTenThousandRecordBenchmark() {
        viewModelScope.launch {
            _benchmarkState.value = UiState.Loading
            when (val res = repository.runLargeScaleSeedAndBenchmark(_session.value)) {
                is DomainResult.Success -> {
                    _benchmarkState.value = UiState.Success(res.data)
                    _actionBanner.value = true to "Seeded & benchmarked ${res.data.totalSeededRecords} records in ${res.data.seedDurationMs}ms."
                    refreshDashboard()
                    verifyAuditChain()
                }
                is DomainResult.Failure -> {
                    _benchmarkState.value = UiState.Error(res.message)
                    _actionBanner.value = false to res.message
                }
            }
        }
    }

    fun verifyAuditChain() {
        val current = _session.value
        if (current == null || !RbacPolicyEngine.hasPermission(current.role, Permission.VIEW_AUDIT_LOGS)) {
            _auditChainValid.value = null
            return
        }
        viewModelScope.launch {
            when (val res = repository.verifyAuditChainIntegrityForSession(current)) {
                is DomainResult.Success -> _auditChainValid.value = res.data
                is DomainResult.Failure -> {
                    _auditChainValid.value = null
                    _actionBanner.value = false to res.message
                }
            }
        }
    }

    // ---- Shipments & State Transitions ----
    fun setShipmentStatusFilter(status: CargoStatus?) {
        _shipmentStatusFilter.value = status
    }

    fun setShipmentSearchQuery(query: String) {
        _shipmentSearchQuery.value = query
    }

    fun selectShipment(shipmentId: String?) {
        _selectedShipmentId.value = shipmentId
        if (shipmentId == null) {
            _selectedShipment.value = null
            return
        }
        viewModelScope.launch {
            _selectedShipment.value = repository.getShipmentById(shipmentId)
        }
    }

    fun createShipment(
        customerId: String,
        originHub: String,
        destinationCity: String,
        destinationCountry: String,
        serviceTier: ServiceTier,
        weightKg: Double,
        declaredValueUsd: Double,
        internalNotes: String,
        packageDescription: String,
        warehouseZone: String,
        onCreated: (ShipmentEntity) -> Unit = {}
    ) {
        viewModelScope.launch {
            when (val res = repository.createShipment(
                session = _session.value,
                customerId = customerId,
                originHub = originHub,
                destinationCity = destinationCity,
                destinationCountry = destinationCountry,
                serviceTier = serviceTier,
                weightKg = weightKg,
                declaredValueUsd = declaredValueUsd,
                internalNotes = internalNotes,
                initialPackageDescription = packageDescription,
                initialWarehouseZone = warehouseZone
            )) {
                is DomainResult.Success -> {
                    _actionBanner.value = true to "Registered shipment ${res.data.trackingNumber} with QR & Code-128 label."
                    refreshDashboard()
                    onCreated(res.data)
                }
                is DomainResult.Failure -> {
                    _actionBanner.value = false to res.message
                }
            }
        }
    }

    fun transitionShipment(
        shipmentId: String,
        targetStatus: CargoStatus,
        facilityLocation: String,
        notes: String
    ) {
        viewModelScope.launch {
            when (val res = repository.transitionShipmentStatus(
                session = _session.value,
                shipmentId = shipmentId,
                targetStatus = targetStatus,
                facilityLocation = facilityLocation,
                notes = notes
            )) {
                is DomainResult.Success -> {
                    if (_selectedShipmentId.value == shipmentId) {
                        _selectedShipment.value = res.data
                    }
                    syncScannedManifestStatus(res.data)
                    _actionBanner.value = true to "${res.data.trackingNumber} moved to ${targetStatus.displayLabel}."
                    refreshDashboard()
                }
                is DomainResult.Failure -> {
                    _actionBanner.value = false to res.message
                }
            }
        }
    }

    // ---- Inventory / Packages ----
    fun setInventoryZoneFilter(zone: String) {
        _inventoryZoneFilter.value = zone
    }

    fun setInventorySearchQuery(query: String) {
        _inventorySearchQuery.value = query
    }

    fun addPackage(
        shipmentId: String,
        sku: String,
        description: String,
        weightKg: Double,
        dimensionsCm: String,
        warehouseZone: String,
        binLocation: String,
        fragile: Boolean,
        onAdded: () -> Unit = {}
    ) {
        viewModelScope.launch {
            when (val res = repository.addPackageToShipment(
                session = _session.value,
                shipmentId = shipmentId,
                sku = sku,
                description = description,
                weightKg = weightKg,
                dimensionsCm = dimensionsCm,
                warehouseZone = warehouseZone,
                binLocation = binLocation,
                fragile = fragile
            )) {
                is DomainResult.Success -> {
                    _actionBanner.value = true to "Added package ${res.data.packageCode} in ${res.data.binLocation}."
                    if (_selectedShipmentId.value == shipmentId) {
                        _selectedShipment.value = repository.getShipmentById(shipmentId)
                    }
                    refreshDashboard()
                    onAdded()
                }
                is DomainResult.Failure -> {
                    _actionBanner.value = false to res.message
                }
            }
        }
    }

    // ---- Customers & Tasks ----
    fun createCustomer(
        companyName: String,
        contactName: String,
        email: String,
        phone: String,
        tier: CustomerTier,
        city: String,
        country: String,
        onCreated: () -> Unit = {}
    ) {
        viewModelScope.launch {
            when (val res = repository.createCustomer(
                session = _session.value,
                companyName = companyName,
                contactName = contactName,
                email = email,
                phone = phone,
                tier = tier,
                city = city,
                country = country
            )) {
                is DomainResult.Success -> {
                    _actionBanner.value = true to "Added customer ${res.data.companyName} (${res.data.accountCode})."
                    refreshDashboard()
                    onCreated()
                }
                is DomainResult.Failure -> {
                    _actionBanner.value = false to res.message
                }
            }
        }
    }

    fun assignTask(
        shipmentId: String,
        assigneeId: String,
        title: String,
        instructions: String,
        priority: TaskPriority,
        onAssigned: () -> Unit = {}
    ) {
        viewModelScope.launch {
            when (val res = repository.assignTask(
                session = _session.value,
                shipmentId = shipmentId,
                assigneeId = assigneeId,
                title = title,
                instructions = instructions,
                priority = priority
            )) {
                is DomainResult.Success -> {
                    _actionBanner.value = true to "Assigned task '${res.data.title}'."
                    refreshDashboard()
                    onAssigned()
                }
                is DomainResult.Failure -> {
                    _actionBanner.value = false to res.message
                }
            }
        }
    }

    fun updateTaskStatus(taskId: String, newStatus: TaskStatus) {
        viewModelScope.launch {
            when (val res = repository.updateTaskStatus(_session.value, taskId, newStatus)) {
                is DomainResult.Success -> {
                    _actionBanner.value = true to "Task marked as ${newStatus.label}."
                    refreshDashboard()
                }
                is DomainResult.Failure -> {
                    _actionBanner.value = false to res.message
                }
            }
        }
    }

    // ---- Scanner & Automated Lookup / Status Update Pipeline ----
    fun setScanActionMode(mode: ScanActionMode) {
        _scanActionMode.value = mode
    }

    fun setScanTargetCheckpoint(status: CargoStatus) {
        _scanTargetCheckpoint.value = status
    }

    fun lookupScannedCode(rawCode: String) {
        handleBarcodeScan(rawCode)
    }

    fun handleBarcodeScan(rawCode: String) {
        viewModelScope.launch {
            val cleaned = rawCode.trim()
            if (cleaned.isBlank()) return@launch

            val mode = _scanActionMode.value
            val now = System.currentTimeMillis()
            val lookupRes = repository.lookupByScannedCodeForSession(_session.value, cleaned)
            if (lookupRes is DomainResult.Failure) {
                _scanResult.value = ScanLookupResult(
                    scannedCode = cleaned,
                    shipment = null,
                    pkg = null,
                    autoActionSucceeded = false,
                    error = lookupRes.message
                )
                _actionBanner.value = false to lookupRes.message
                appendScanHistory(cleaned, null, mode, lookupRes.message, false, now)
                return@launch
            }
            val (shipment, pkg) = (lookupRes as DomainResult.Success).data

            if (shipment == null && pkg == null) {
                val errMsg = "No shipment or package matches '$cleaned'."
                _scanResult.value = ScanLookupResult(
                    scannedCode = cleaned,
                    shipment = null,
                    pkg = null,
                    autoActionSucceeded = false,
                    error = errMsg
                )
                appendScanHistory(cleaned, null, mode, errMsg, false, now)
                return@launch
            }

            if (shipment == null || mode == ScanActionMode.AUTO_LOOKUP) {
                val summary = "Manifest ${shipment?.trackingNumber ?: cleaned} decoded (${shipment?.status ?: "PKG"})."
                if (shipment != null) {
                    enqueueScannedManifestItem(cleaned, shipment, pkg, now)
                }
                _scanResult.value = ScanLookupResult(
                    scannedCode = cleaned,
                    shipment = shipment,
                    pkg = pkg,
                    autoActionSummary = summary,
                    autoActionSucceeded = true
                )
                appendScanHistory(cleaned, shipment?.trackingNumber, mode, summary, true, now)
                return@launch
            }

            // Automated Status Update Modes (enforcing strict FSM + RBAC + Audit Chain)
            val currentStatus = CargoStatus.fromNameSafe(shipment.status)
            val targetStatus = when (mode) {
                ScanActionMode.AUTO_ADVANCE_NEXT -> CargoStateMachine.nextCanonicalStatus(currentStatus)
                ScanActionMode.AUTO_SET_CHECKPOINT -> _scanTargetCheckpoint.value
                ScanActionMode.AUTO_LOOKUP -> null
            }

            if (targetStatus == null) {
                val msg = "${shipment.trackingNumber} is in terminal state '${currentStatus.displayLabel}' — no next step."
                enqueueScannedManifestItem(cleaned, shipment, pkg, now)
                _scanResult.value = ScanLookupResult(
                    scannedCode = cleaned,
                    shipment = shipment,
                    pkg = pkg,
                    autoActionSummary = msg,
                    autoActionSucceeded = false
                )
                _actionBanner.value = false to msg
                appendScanHistory(cleaned, shipment.trackingNumber, mode, msg, false, now)
                return@launch
            }

            val hub = _session.value?.hubLocation ?: shipment.originHub
            when (val res = repository.transitionShipmentStatus(
                session = _session.value,
                shipmentId = shipment.id,
                targetStatus = targetStatus,
                facilityLocation = hub,
                notes = "Auto-updated via CameraX barcode scan (${mode.label})"
            )) {
                is DomainResult.Success -> {
                    val updated = res.data
                    val msg = "Auto-updated ${updated.trackingNumber}: ${currentStatus.displayLabel} -> ${targetStatus.displayLabel}"
                    if (_selectedShipmentId.value == updated.id) {
                        _selectedShipment.value = updated
                    }
                    enqueueScannedManifestItem(cleaned, updated, pkg, now)
                    _scanResult.value = ScanLookupResult(
                        scannedCode = cleaned,
                        shipment = updated,
                        pkg = pkg,
                        autoActionSummary = msg,
                        autoActionSucceeded = true
                    )
                    _actionBanner.value = true to msg
                    refreshDashboard()
                    appendScanHistory(cleaned, updated.trackingNumber, mode, msg, true, now)
                }
                is DomainResult.Failure -> {
                    enqueueScannedManifestItem(cleaned, shipment, pkg, now)
                    _scanResult.value = ScanLookupResult(
                        scannedCode = cleaned,
                        shipment = shipment,
                        pkg = pkg,
                        autoActionSummary = res.message,
                        autoActionSucceeded = false
                    )
                    _actionBanner.value = false to res.message
                    appendScanHistory(cleaned, shipment.trackingNumber, mode, res.message, false, now)
                }
            }
        }
    }

    private fun enqueueScannedManifestItem(
        scannedCode: String,
        shipment: ShipmentEntity,
        pkg: PackageEntity?,
        timestampMs: Long
    ) {
        val itemKey = pkg?.packageCode ?: shipment.trackingNumber
        val item = ScannedManifestItem(
            key = itemKey,
            scannedCode = scannedCode,
            trackingNumber = shipment.trackingNumber,
            packageCode = pkg?.packageCode,
            sku = pkg?.sku,
            description = pkg?.description ?: shipment.internalNotes.ifBlank { "Consolidated freight unit" },
            originHub = shipment.originHub,
            destination = "${shipment.destinationCity}, ${shipment.destinationCountry}",
            status = shipment.status,
            serviceTier = ServiceTier.fromNameSafe(shipment.serviceTier).label,
            weightKg = pkg?.weightKg ?: shipment.totalWeightKg,
            binLocation = pkg?.let { "${it.warehouseZone}/${it.binLocation}" },
            fragile = pkg?.fragile ?: false,
            scannedAtEpochMs = timestampMs
        )
        _scannedManifestItems.update { existing ->
            val filtered = existing.filterNot { it.key == itemKey }
            listOf(item) + filtered
        }
        // Invalidate previously generated PDF when the scanned list changes
        if (_manifestPdfState.value is UiState.Success) {
            _manifestPdfState.value = UiState.Idle
        }
    }

    private fun syncScannedManifestStatus(updatedShipment: ShipmentEntity) {
        _scannedManifestItems.update { existing ->
            existing.map { item ->
                if (item.trackingNumber == updatedShipment.trackingNumber) {
                    item.copy(status = updatedShipment.status)
                } else {
                    item
                }
            }
        }
    }

    fun removeScannedManifestItem(itemKey: String) {
        _scannedManifestItems.update { existing -> existing.filterNot { it.key == itemKey } }
        if (_manifestPdfState.value is UiState.Success) {
            _manifestPdfState.value = UiState.Idle
        }
    }

    fun clearScannedManifestItems() {
        _scannedManifestItems.value = emptyList()
        _manifestPdfState.value = UiState.Idle
    }

    fun generateScannedManifestPdf(
        recipientEmail: String = "",
        notes: String = "",
        onGenerated: (GeneratedManifestPdf) -> Unit = {}
    ) {
        val currentItems = _scannedManifestItems.value
        if (currentItems.isEmpty()) {
            _actionBanner.value = false to "Scan at least one shipment or package before generating a manifest PDF."
            return
        }
        viewModelScope.launch {
            _manifestPdfState.value = UiState.Loading
            try {
                val operator = _session.value
                val pdf = withContext(Dispatchers.IO) {
                    ShipmentManifestPdfGenerator.generate(
                        context = getApplication(),
                        items = currentItems,
                        operator = operator,
                        recipientEmail = recipientEmail,
                        notes = notes
                    )
                }
                repository.recordManifestPdfExport(
                    session = operator,
                    manifestNumber = pdf.manifestNumber,
                    itemCount = pdf.itemCount,
                    totalWeightKg = pdf.totalWeightKg,
                    recipientEmail = recipientEmail
                )
                _manifestPdfState.value = UiState.Success(pdf)
                _actionBanner.value = true to "Digital manifest ${pdf.manifestNumber} generated (${pdf.itemCount} items)."
                onGenerated(pdf)
            } catch (e: Exception) {
                val msg = e.message ?: "Failed to generate digital shipment manifest PDF."
                _manifestPdfState.value = UiState.Error(msg)
                _actionBanner.value = false to msg
            }
        }
    }

    fun showActionMessage(isSuccess: Boolean, message: String) {
        _actionBanner.value = isSuccess to message
    }

    private fun appendScanHistory(
        scannedCode: String,
        resolvedTracking: String?,
        mode: ScanActionMode,
        summary: String,
        succeeded: Boolean,
        timestampMs: Long
    ) {
        _scanHistory.update { existing ->
            (listOf(
                ScanEventLog(
                    id = timestampMs + existing.size,
                    scannedCode = scannedCode,
                    resolvedTracking = resolvedTracking,
                    mode = mode,
                    outcomeSummary = summary,
                    succeeded = succeeded,
                    timestampEpochMs = timestampMs
                )
            ) + existing).take(20)
        }
    }

    fun clearScanResult() {
        _scanResult.value = null
    }
}
