package com.example.ui.publicportal

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.PublicTrackingSnapshot
import com.example.ui.components.CargoCameraScannerDialog
import com.example.ui.components.CargoStatusBadge
import com.example.ui.components.ErrorStatePanel
import com.example.ui.components.LoadingPanel
import com.example.ui.components.formatDateOnly
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.ClearedEmerald600
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LogisticsAmber500
import com.example.ui.theme.LogisticsAmber600
import com.example.ui.theme.MaritimeNavy950
import com.example.ui.theme.TelemetryBlue600
import com.example.ui.viewmodel.CargoFlowViewModel
import com.example.ui.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublicPortalScreen(
    viewModel: CargoFlowViewModel,
    onOpenOperationsPortal: () -> Unit
) {
    val trackingState by viewModel.publicTrackingState.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var showPublicScanner by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(LogisticsAmber500),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalShipping,
                                contentDescription = "CargoFlow Logo",
                                tint = MaritimeNavy950,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("CargoFlow", style = MaterialTheme.typography.titleLarge)
                            Text(
                                "GLOBAL FREIGHT NETWORK",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    OutlinedButton(
                        onClick = onOpenOperationsPortal,
                        modifier = Modifier
                            .padding(end = 10.dp)
                            .testTag("open_operations_portal_button"),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Secured Operations Portal",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text("Ops Portal", style = MaterialTheme.typography.labelLarge)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Hero Banner
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(168.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_hero_logistics_1795165394480),
                                contentDescription = "CargoFlow intermodal freight terminal at twilight",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                MaritimeNavy950.copy(alpha = 0.30f),
                                                MaritimeNavy950.copy(alpha = 0.88f)
                                            )
                                        )
                                    )
                            )
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(16.dp)
                            ) {
                                Surface(
                                    color = LogisticsAmber500,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "PUBLIC TRACKING & FREIGHT PORTAL",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaritimeNavy950,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = stringResource(R.string.public_portal_hero_headline),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "Track cargo in real time with privacy-hardened milestone visibility.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                        }
                    }
                }

                // Secure Public Tracking Card
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = "Privacy Protected Tracking",
                                    tint = ClearedEmerald600,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("Track Your Shipment", style = MaterialTheme.typography.titleLarge)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Enter a CargoFlow tracking or package ID. Internal operational metadata, pricing, and staff records are strictly redacted.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(
                                value = query,
                                onValueChange = { query = it },
                                label = { Text("Tracking ID (e.g., CF-2026-000001)") },
                                singleLine = true,
                                leadingIcon = {
                                    Icon(Icons.Default.Search, contentDescription = "Search tracking")
                                },
                                trailingIcon = {
                                    IconButton(
                                        onClick = { showPublicScanner = true },
                                        modifier = Modifier.testTag("public_scan_barcode_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.QrCodeScanner,
                                            contentDescription = "Scan shipping barcode with CameraX"
                                        )
                                    }
                                },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(
                                    onSearch = { viewModel.trackPublicShipment(query) }
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("public_tracking_input")
                            )
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.trackPublicShipment(query) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("public_track_submit_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Text("Track Shipment", fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "Quick-try sample manifests:",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(6.dp))
                            val samples = listOf(
                                "CF-2026-000001",
                                "CF-2026-000002",
                                "CF-2026-000003",
                                "CF-2026-000005"
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(samples) { code ->
                                    FilterChip(
                                        selected = query.equals(code, ignoreCase = true),
                                        onClick = {
                                            query = code
                                            viewModel.trackPublicShipment(code)
                                        },
                                        label = {
                                            Text(
                                                code,
                                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily)
                                            )
                                        }
                                    )
                                }
                            }

                            Spacer(Modifier.height(12.dp))
                            when (val state = trackingState) {
                                UiState.Idle -> Unit
                                UiState.Loading -> LoadingPanel("Querying redacted public milestone ledger...")
                                is UiState.Error -> ErrorStatePanel(state.message)
                                is UiState.Success -> PublicTrackingResultCard(state.data)
                            }
                        }
                    }
                }

                // Company Metrics Strip
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        PublicStatTile("99.4%", "On-Time SLA", Modifier.weight(1f))
                        PublicStatTile("6 Hubs", "Global Nodes", Modifier.weight(1f))
                        PublicStatTile("24/7", "Telemetry", Modifier.weight(1f))
                    }
                }

                // Freight Service Tiers
                item {
                    Text("Enterprise Logistics Services", style = MaterialTheme.typography.titleLarge)
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        ServiceTierRow(
                            icon = Icons.Default.FlightTakeoff,
                            title = "Express Air Cargo",
                            sla = "24h Door-to-Door SLA",
                            description = "Priority customs clearance and dedicated belly/freighter uplift between intercontinental air hubs."
                        )
                        ServiceTierRow(
                            icon = Icons.Default.LocalShipping,
                            title = "Priority Ground Freight",
                            sla = "72h Regional Corridor SLA",
                            description = "Linehaul palletized trucking with continuous checkpoint barcode verification."
                        )
                        ServiceTierRow(
                            icon = Icons.Default.AcUnit,
                            title = "Cold Chain Pharmaceuticals",
                            sla = "36h Thermal-Validated SLA",
                            description = "ISO-certified 2°C–8°C climate-controlled warehousing and chain-of-custody telemetry."
                        )
                        ServiceTierRow(
                            icon = Icons.Default.DirectionsBoat,
                            title = "Intermodal Ocean Freight",
                            sla = "10d Port-to-Port SLA",
                            description = "FCL/LCL container consolidation across Rotterdam, Singapore, and North American ports."
                        )
                    }
                }
            }
        }
    }

    if (showPublicScanner) {
        CargoCameraScannerDialog(
            title = "Scan CargoFlow Shipping Label",
            onDismiss = { showPublicScanner = false },
            onCodeScanned = { scannedCode ->
                query = scannedCode
                viewModel.trackPublicShipment(scannedCode)
            }
        )
    }
}

@Composable
private fun PublicTrackingResultCard(snapshot: PublicTrackingSnapshot) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("public_tracking_result_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = snapshot.trackingNumber,
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFamily)
                    )
                    Text(
                        text = "${snapshot.originRegion} -> ${snapshot.destinationCity}, ${snapshot.destinationCountry}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                CargoStatusBadge(status = snapshot.currentStatus, usePublicLabel = false)
            }
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Tier: ${snapshot.serviceTierLabel}", style = MaterialTheme.typography.labelMedium)
                Text("${snapshot.packageCount} pkg · ${snapshot.totalWeightKg} kg", style = MaterialTheme.typography.labelSmall)
                Text("ETA: ${formatDateOnly(snapshot.estimatedDeliveryEpochMs)}", style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(12.dp))
            HorizontalDivider()
            Spacer(Modifier.height(10.dp))
            Text("Verified Transit Milestones", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            snapshot.milestones.reversed().forEachIndexed { idx, milestone ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (idx == 0) LogisticsAmber600 else TelemetryBlue600)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(milestone.publicLabel, style = MaterialTheme.typography.labelLarge)
                        Text(
                            milestone.publicLocation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        formatTimestamp(milestone.timestampEpochMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun PublicStatTile(value: String, label: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                value,
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFamily),
                color = MaterialTheme.colorScheme.secondary
            )
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ServiceTierRow(
    icon: ImageVector,
    title: String,
    sla: String,
    description: String
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Surface(
                    color = LogisticsAmber500.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(5.dp)
                ) {
                    Text(
                        text = sla,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = LogisticsAmber500,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
