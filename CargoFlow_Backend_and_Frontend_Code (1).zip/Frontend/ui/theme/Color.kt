package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CargoFlow Industrial Precision Palette
val MaritimeNavy950 = Color(0xFF07101F)
val MaritimeNavy900 = Color(0xFF0B172A)
val MaritimeNavy800 = Color(0xFF13223A)
val MaritimeNavy700 = Color(0xFF1E3354)

val TelemetryBlue600 = Color(0xFF1D4ED8)
val TelemetryBlue500 = Color(0xFF2563EB)
val TelemetryBlue400 = Color(0xFF60A5FA)
val TelemetryBlue100 = Color(0xFFDBEAFE)

val LogisticsAmber600 = Color(0xFFD97706)
val LogisticsAmber500 = Color(0xFFF59E0B)
val LogisticsAmber100 = Color(0xFFFEF3C7)

val ClearedEmerald600 = Color(0xFF059669)
val ClearedEmerald100 = Color(0xFFD1FAE5)

val AlertCrimson600 = Color(0xFFDC2626)
val AlertCrimson100 = Color(0xFFFEE2E2)

val HoldViolet600 = Color(0xFF7C3AED)
val HoldViolet100 = Color(0xFFEDE9FE)

val SlateSurface50 = Color(0xFFF4F7FA)
val SlateSurface100 = Color(0xFFE9EFF5)
val SlateSurface200 = Color(0xFFD5DFEA)
val SlateInk900 = Color(0xFF0F172A)
val SlateInk600 = Color(0xFF475569)
val SlateInk400 = Color(0xFF94A3B8)
