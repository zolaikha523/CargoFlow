package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LogisticsAmber500,
    onPrimary = MaritimeNavy950,
    primaryContainer = MaritimeNavy700,
    onPrimaryContainer = LogisticsAmber100,
    secondary = TelemetryBlue400,
    onSecondary = MaritimeNavy950,
    secondaryContainer = MaritimeNavy800,
    onSecondaryContainer = TelemetryBlue100,
    tertiary = ClearedEmerald600,
    onTertiary = Color.White,
    error = AlertCrimson600,
    onError = Color.White,
    background = MaritimeNavy950,
    onBackground = Color(0xFFF1F5F9),
    surface = MaritimeNavy900,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = MaritimeNavy800,
    onSurfaceVariant = SlateInk400,
    outline = Color(0xFF2E4365)
)

private val LightColorScheme = lightColorScheme(
    primary = MaritimeNavy900,
    onPrimary = Color.White,
    primaryContainer = TelemetryBlue100,
    onPrimaryContainer = MaritimeNavy900,
    secondary = LogisticsAmber600,
    onSecondary = Color.White,
    secondaryContainer = LogisticsAmber100,
    onSecondaryContainer = MaritimeNavy900,
    tertiary = TelemetryBlue600,
    onTertiary = Color.White,
    error = AlertCrimson600,
    onError = Color.White,
    errorContainer = AlertCrimson100,
    onErrorContainer = Color(0xFF7F1D1D),
    background = SlateSurface50,
    onBackground = SlateInk900,
    surface = Color.White,
    onSurface = SlateInk900,
    surfaceVariant = SlateSurface100,
    onSurfaceVariant = SlateInk600,
    outline = SlateSurface200
)

@Composable
fun CargoFlowTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = CargoFlowTypography,
        content = content
    )
}
