package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.auth.OperationsAuthScreen
import com.example.ui.components.CargoFlowLaunchSplash
import com.example.ui.operations.OperationsShell
import com.example.ui.publicportal.PublicPortalScreen
import com.example.ui.theme.CargoFlowTheme
import com.example.ui.viewmodel.CargoFlowViewModel

object CargoFlowRoutes {
    const val OPS_AUTH = "ops_auth"
    const val PUBLIC_PORTAL = "public_portal"
    const val OPS_SHELL = "ops_shell"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CargoFlowTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CargoFlowApp()
                }
            }
        }
    }
}

@Composable
fun CargoFlowApp(viewModel: CargoFlowViewModel = viewModel()) {
    val session by viewModel.session.collectAsStateWithLifecycle()
    val isBootstrapping by viewModel.isBootstrapping.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    var showLaunchSplash by rememberSaveable { mutableStateOf(true) }

    Box(modifier = Modifier.fillMaxSize()) {
        NavHost(
            navController = navController,
            startDestination = CargoFlowRoutes.OPS_AUTH
        ) {
            composable(CargoFlowRoutes.OPS_AUTH) {
                OperationsAuthScreen(
                    viewModel = viewModel,
                    onOpenPublicPortal = {
                        navController.navigate(CargoFlowRoutes.PUBLIC_PORTAL) {
                            launchSingleTop = true
                        }
                    },
                    onAuthenticated = {
                        navController.navigate(CargoFlowRoutes.OPS_SHELL) {
                            popUpTo(CargoFlowRoutes.OPS_AUTH) { inclusive = true }
                        }
                    }
                )
            }

            composable(CargoFlowRoutes.PUBLIC_PORTAL) {
                PublicPortalScreen(
                    viewModel = viewModel,
                    onOpenOperationsPortal = {
                        val dest = if (session != null) CargoFlowRoutes.OPS_SHELL else CargoFlowRoutes.OPS_AUTH
                        navController.navigate(dest) {
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable(CargoFlowRoutes.OPS_SHELL) {
                if (session == null) {
                    LaunchedEffect(Unit) {
                        navController.navigate(CargoFlowRoutes.OPS_AUTH) {
                            popUpTo(CargoFlowRoutes.OPS_SHELL) { inclusive = true }
                        }
                    }
                } else {
                    OperationsShell(
                        viewModel = viewModel,
                        onSignedOut = {
                            navController.navigate(CargoFlowRoutes.OPS_AUTH) {
                                popUpTo(CargoFlowRoutes.OPS_SHELL) { inclusive = true }
                            }
                        }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = showLaunchSplash,
            exit = fadeOut(
                animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing)
            ) + scaleOut(
                targetScale = 1.05f,
                animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing)
            )
        ) {
            CargoFlowLaunchSplash(
                isBootstrapping = isBootstrapping,
                onSplashComplete = { showLaunchSplash = false }
            )
        }
    }
}
