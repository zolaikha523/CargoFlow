CargoFlow Android Application - Backend & Frontend Source Code Archive
======================================================================
Language: Kotlin (Jetpack Compose, Room SQLite, CameraX, Material 3)
Total Source & Config Files: 41

[Backend]
  - Backend/AndroidManifest.xml
  - Backend/res/xml/file_paths.xml
  - Backend/domain/CargoModels.kt
  - Backend/domain/CargoStateMachine.kt
  - Backend/domain/RbacPolicyEngine.kt
  - Backend/domain/SecurityHasher.kt
  - Backend/domain/ValidationEngine.kt
  - Backend/domain/BarcodeEngine.kt
  - Backend/domain/ShipmentManifestPdfGenerator.kt
  - Backend/data/local/CargoFlowEntities.kt
  - Backend/data/local/CargoFlowDao.kt
  - Backend/data/local/CargoFlowDatabase.kt
  - Backend/data/remote/CargoFlowApiService.kt
  - Backend/data/repository/CargoFlowRepository.kt
  - Backend/data/seed/SyntheticDataSeeder.kt
  - Backend/scanner/Code128LuminanceDecoder.kt
  - Backend/scanner/CargoBarcodeFrameAnalyzer.kt

[Frontend]
  - Frontend/MainActivity.kt
  - Frontend/ui/viewmodel/CargoFlowViewModel.kt
  - Frontend/ui/theme/Color.kt
  - Frontend/ui/theme/Type.kt
  - Frontend/ui/theme/Theme.kt
  - Frontend/ui/components/CargoFlowLaunchSplash.kt
  - Frontend/ui/components/LogisticsComponents.kt
  - Frontend/ui/components/CargoCameraScanner.kt
  - Frontend/ui/components/ScannedManifestPdfCard.kt
  - Frontend/ui/auth/OperationsAuthScreen.kt
  - Frontend/ui/publicportal/PublicPortalScreen.kt
  - Frontend/ui/operations/OperationsShell.kt
  - Frontend/ui/operations/DashboardScreen.kt
  - Frontend/ui/operations/ShipmentsScreen.kt
  - Frontend/ui/operations/InventoryScreen.kt
  - Frontend/ui/operations/WorkforceAndAuditScreen.kt
  - Frontend/ui/operations/ScannerScreen.kt
  - Frontend/res/values/strings.xml
  - Frontend/res/values/colors.xml
  - Frontend/res/values/themes.xml

[BuildConfig]
  - BuildConfig/settings.gradle.kts
  - BuildConfig/build.gradle.kts
  - BuildConfig/app/build.gradle.kts
  - BuildConfig/gradle/libs.versions.toml

